# EntityGraph — Contract Review Summary

**Reviewed:** `EntityGraph Web App Plan.md` and `ENTITYGRAPH_CONTRACTS.md` v0.1  
**Result:** v0.1 is a strong architectural baseline, but it was not a complete implementation contract. The expanded v0.2 file is the recommended implementation baseline.

## Overall assessment

The original direction is sound: PostgreSQL is the source of truth; one entity table provides real FKs; templates validate JSONB attributes; a shared service layer prevents UI/MCP logic divergence; workspace roles avoid premature per-entity ACLs; the UI uses lists and detail pages rather than graph visualization; and MCP is an adapter over the same services.

The review did not recommend replacing that architecture. It completed the missing contracts around it.

## Coverage review

| Area | v0.1 assessment | v0.2 action |
|---|---|---|
| Domain entities | Good | Added workspace ID and made status/version behavior explicit |
| Relations | Partial | Defined temporal behavior, `directed`, `symmetricHelper`, update concurrency |
| Templates | Partial | Added version precondition and impact validation before schema update |
| Predicate registry | Partial | Added workspace-scoped keys and safe update/delete behavior |
| Database integrity | Partial | Added workspace composite FKs, index requirements, registry locking |
| Search | Partial | Defined operator semantics, status defaults, ranking, cursor binding |
| Authorization | Partial | Converted role names into a complete action matrix and token intersection rules |
| Authentication | Incomplete | Added session/principal construction, workspace selection, invitation/token flow |
| Member administration | Missing | Added member/invitation/ownership service and tRPC contracts |
| API token administration | Partial | Added normalized token service, one-time secret handling, immediate revocation |
| Dashboard | Missing | Defined counts, orphans, stale-process meaning, freshness target |
| Bulk operations | Missing | Added bulk tag/archive contracts, limits, atomicity, per-entity auditing |
| Saved views | Mentioned only in milestone | Added DTO, visibility, service/API behavior |
| CSV import/export | Mentioned only in milestone | Added package format, dry-run preview, commit, limits, atomicity |
| tRPC | Partial | Expanded procedure map to cover the complete planned UI |
| MCP | Good core shape | Corrected SDK entry guidance and expanded all-request audit rule |
| Errors | Partial | Added stable error taxonomy and separate tRPC/MCP mappings |
| Concurrency | Partial | Added relation/template/saved-view preconditions and bulk locking |
| Acceptance tests | Useful but incomplete | Expanded to 86 testable outcomes |
| Operations | Partial | Added shared rate limiting, request audit, restore/security requirements |

## Important corrections

### 1. Workspace is a real isolation boundary

The product plan calls roles and registries workspace-scoped but the v0.1 draft had no workspace table or workspace foreign keys. v0.2 proposes explicit multi-workspace isolation, composite FKs, and workspace-bound MCP tokens. This is the most important database correction.

### 2. MCP audit requirement must include reads

The product plan says every MCP call creates an audit entry. v0.1 only guaranteed audit rows for successful mutations. v0.2 defines one audit event for each authenticated RPC, including tool calls, resource reads, `server/discover`, and list methods. Failed auth attempts are placed in a separate security log because no verified token identity exists.

### 3. M4 features need actual contracts

Saved views and CSV import/export appeared in the source milestones, and bulk tag/archive appeared in the committed UI list. v0.1 did not define their shapes or failure semantics. v0.2 supplies proposed DTOs, tRPC procedures, atomicity rules, and package format.

### 4. Admin UI requires member and token lifecycle contracts

The source screen set includes member management and token issue/revoke. v0.1 only described the table concept. v0.2 defines invitation, role management, ownership transfer, token issue/revoke, effective permissions, and token lifecycle.

### 5. MCP protocol details should be delegated to the official SDK

The 2026-07-28 MCP revision is real. The official TypeScript SDK v2 documents `createMcpHandler` as the modern HTTP entry point, a per-request stateless model, the modern discovery flow, and cache hints. v0.2 therefore requires the official SDK to own protocol framing and header/body checks instead of implementing a hand-rolled dispatcher.

## Proposed defaults requiring explicit product acceptance

These are not all specified by the source plan; v0.2 chooses defaults so engineers can proceed without inventing behavior:

1. Multi-workspace isolation from day one; exactly one owner per workspace.
2. A relation with `directed: false` is stored once and traversable in both directions; `symmetricHelper` never auto-creates an edge.
3. Archived entities cannot be restored in v1.
4. Templates cannot be changed if the new template would invalidate existing entities.
5. Stale processes are active processes not updated within a configurable threshold (90 days default).
6. Saved views can be personal or workspace-shared.
7. Import/export uses a ZIP package with entity and relation CSV files plus a manifest.
8. MCP runs modern-only unless legacy protocol compatibility is deliberately enabled.
9. `tools/list` receives a 30-second private cache hint; service validation remains authoritative.
10. The proposed MCP request body cap is 1 MiB; the source only specified that a payload cap must exist, not its number.
11. Invitation email provider and audit retention policy still require deployment/product decisions.

## MCP verification sources

- Official specification announcement (2026-07-28): https://blog.modelcontextprotocol.io/posts/2026-07-28/
- Official TypeScript SDK protocol versions: https://ts.sdk.modelcontextprotocol.io/v2/protocol-versions
- Official SDK migration/support guide: https://ts.sdk.modelcontextprotocol.io/v2/migration/support-2026-07-28
- Official `createMcpHandler` API: https://ts.sdk.modelcontextprotocol.io/v2/api/%40modelcontextprotocol/server/server/createMcpHandler.html

The official docs confirm the 2026-07-28 modern protocol, the `server/discover` flow, the stateless per-request model, modern HTTP header routing, and the SDK's `createMcpHandler` entry point. The SDK's current v2 documentation should be rechecked when the dependency is pinned, because implementation APIs can evolve independently of the protocol revision.

## Recommended next action

Treat `ENTITYGRAPH_CONTRACTS_v0.2.md` as the new implementation baseline. Before generating the Drizzle schema and service code, accept or amend the proposed defaults listed above—especially workspace isolation, relation symmetry semantics, template evolution, saved-view visibility, import format, and audit retention.
