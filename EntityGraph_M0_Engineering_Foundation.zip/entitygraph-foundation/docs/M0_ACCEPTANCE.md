# M0 — Engineering quality foundation acceptance

## Included

- npm scripts for format, lint, architecture boundaries, typechecking, unit coverage, PostgreSQL integration tests, dependency audit, and production build.
- ESLint + Next.js Core Web Vitals configuration and Prettier formatting rules.
- Vitest unit and integration configurations.
- 100% coverage gate on the current trusted-principal authorization helpers.
- Disposable PostgreSQL 16 integration-test database and migration/integrity tests.
- Static architecture-boundary checker.
- GitHub Actions CI, CodeQL, dependency review, secret scanning, and Dependabot.
- Pull-request template, bug/architecture issue templates, contribution policy, security policy, and engineering-gates policy.

## Acceptance gates

| Gate | Acceptance | Status in this package |
|---|---|---|
| Package metadata | Scripts and tooling dependencies declared | Implemented; resolution pending |
| Lockfile | Valid committed npm lockfile; CI installs with `npm ci` | Blocked by registry network access |
| Lint/format | ESLint and Prettier check pass on repository | Configured; not executed |
| Architecture | Import boundary checker passes | Passed using the globally installed TypeScript parser; project `tsx` command remains unverified until dependencies are installed |
| Typecheck | `tsc --noEmit` passes | Not executed because dependencies unavailable |
| Unit tests | Existing contracts and expanded authz tests pass | Added; not executed because dependencies unavailable |
| Coverage | 100% on authorization helpers | Configured; not executed because dependencies unavailable |
| PostgreSQL integration | PostgreSQL 16 migration/constraint tests pass | Added; not executed because Docker/PostgreSQL unavailable |
| CI | Required jobs defined for PR and main | Implemented; requires GitHub repository setup |
| Security | Dependency, secret, and CodeQL workflows defined | Implemented; requires GitHub execution |
| PR gates | Template, policy, and ruleset instructions documented | Implemented; repository rules must be applied by owner |

## Before M1 starts

M0 is ready for adoption only after these environment-dependent gates are closed:

1. Run `npm install`, review `package-lock.json`, and commit it.
2. Run `npm run check` and resolve every failure.
3. Run PostgreSQL tests using the disposable test database.
4. Push the repository to GitHub and verify every workflow completes successfully.
5. Configure the `main` branch ruleset with the required checks and independent approvals.

Do not start M1 on a green-looking local scaffold if the lockfile, typecheck, or PostgreSQL CI gates are still failing.
