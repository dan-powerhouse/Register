# Implementation traceability — v0.2 foundation

This file maps the v0.2 behavioral contract to the current source scaffold. “Adapter present” means transport wiring exists; it does **not** mean the underlying domain service has been implemented.

| Contract area | Implementation | State |
|---|---|---|
| Shared domain types and Zod v4 | `src/contracts/` | Present; dynamic template-value checks remain service work |
| Workspace, membership, invitations, token DTOs | `src/contracts/workspace.ts`, `token.ts`, `models.ts` | Present |
| Audit DTO/query schema | `src/contracts/audit.ts` | Present |
| PostgreSQL app schema | `src/db/schema.ts` | Present as Drizzle model; compare with canonical SQL migration before changes |
| PostgreSQL app migration | `src/db/migrations/0001_entitygraph.sql` | Present; expects Better Auth auth tables first |
| Better Auth schema/config | `src/db/auth-schema.ts`, `src/auth/index.ts` | Starter definition; must be regenerated/checked against installed Better Auth CLI/plugins |
| Entity/relation/template/predicate service ports | `src/services/ports.ts` | Interfaces only; implementations absent |
| Workspace/member/token service ports | `src/services/ports.ts` | Interfaces only; implementations absent |
| Search/traversal/path/dashboard/bulk/audit/saved-view/import/export ports | `src/services/ports.ts` | Interfaces only; implementations absent |
| Trusted principal and authorization guards | `src/auth/principal.ts`, `src/core/authorization.ts` | Present; DB-backed resolver not implemented |
| tRPC context, procedure map and Origin gate | `src/trpc/` | Adapter present; exact Origin allowlist protects cookie-authenticated POST mutations; runtime composition and services remain |
| MCP nine tools and three resources | `src/mcp/server.ts` | Adapter definitions present; conformance tests still required |
| MCP stateless HTTP route | `src/mcp/route.ts`, `src/app/api/mcp/route.ts` | Present; depends on token auth, limiter and runtime composition |
| Authenticated import upload | `src/app/api/imports/upload/route.ts` | Route present; package parser/stager is service work |
| Authenticated export download | `src/app/api/exports/[exportId]/route.ts` | Route present; ZIP builder/storage is service work |
| Email delivery | `src/services/email.ts` | Port/proxy only; provider not selected |
| UI screens | `src/app/page.tsx`, `layout.tsx`, `styles.css` | Developer placeholder only; contract-defined product UI remains outstanding |
| Repository/service composition root | `src/server/runtime.ts` | Injection boundary only; actual composition not implemented |
| Tests | `tests/` | Initial unit tests only; PostgreSQL and MCP integration suite outstanding |

## Required next implementation increment

1. Generate and validate Better Auth schema for the exact installed plugin configuration.
2. Implement PostgreSQL repositories and transaction-scoped audit writer.
3. Implement cursor signing, template-value validation, predicate compatibility, and optimistic locking.
4. Implement workspace bootstrap, owner invariants, invitation lifecycle, token auth/revocation and shared rate limiting.
5. Add PostgreSQL integration tests for isolation, relation constraints, mutations, imports, and auditing.
6. Build the Next.js UI and configure the email provider/deployment environment.

## Validation status

The dependency installation command was attempted in the creation environment but timed out. Therefore this artifact has **not** been successfully typechecked, built, or run against PostgreSQL/MCP Inspector here. Run `npm install`, commit the generated lockfile, then run `npm run typecheck` and `npm test` before treating it as a buildable baseline.
