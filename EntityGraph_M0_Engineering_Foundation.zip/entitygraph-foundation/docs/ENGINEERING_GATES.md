# EntityGraph engineering gates

This document defines the minimum controls for changes entering `main` and the quality targets required before production.

## 1. Pull-request policy

- `main` is protected; direct pushes and force pushes are disabled.
- Every change enters through a pull request.
- At least one independent maintainer approval is required. Security-sensitive changes and production migrations require a second qualified reviewer.
- Stale approvals are dismissed after new commits; the latest push must be approved by someone other than its author.
- All required CI checks must pass; unresolved review threads block merge.
- Administrators should not routinely bypass the ruleset. Any emergency bypass must be documented in an incident or follow-up issue.

## 2. Required GitHub status checks

After the workflows have run once, configure these checks as required on `main`:

| Workflow | Job/check name | Purpose |
|---|---|---|
| EntityGraph CI | `quality` | Format, lint, architecture, typecheck, unit coverage, audit, production build |
| EntityGraph CI | `postgres-integration` | PostgreSQL 16 migrations and database integrity |
| Dependency Review | `dependency-review` | Block newly introduced high/critical dependency vulnerabilities |
| Secret Scan | `gitleaks` | Scan full Git history for credentials and tokens |
| CodeQL | `codeql-analysis` | Static security analysis of TypeScript/JavaScript |

GitHub may display the workflow and job together (for example, `EntityGraph CI / quality`). Select the exact check names displayed by the repository after the first run.

## 3. Locally required commands

```bash
npm run format:check
npm run lint
npm run architecture:check
npm run typecheck
npm run test:coverage
npm run security:audit
npm run test:integration
npm run build
```

`npm run check` combines formatting, lint, architecture, typecheck, and unit coverage. `npm run check:all` adds PostgreSQL integration tests and a production build.

## 4. Coverage policy

Coverage is a regression detector, not proof of correctness.

- M0 enforces 100% statement, branch, function, and line coverage for `src/core/authorization.ts`.
- When each service is implemented, its security-sensitive/business-rule paths must have at least 90% branch coverage, with every authorization and workspace-isolation scenario tested explicitly.
- Before production, target at least 80% overall line coverage and 90% for critical business logic. Critical paths must not be excluded merely to improve the percentage.
- A coverage exception requires a written rationale, an owner, and an expiry/revisit milestone in the PR.

## 5. Security thresholds

- `npm audit --audit-level=high` blocks high and critical known advisories in the installed dependency tree.
- Dependency Review blocks high and critical vulnerabilities introduced by a PR.
- Secret scanning is required for every PR and the full repository history is scanned weekly. For an organization-owned repository, configure the `GITLEAKS_LICENSE` repository/organization secret required by the Gitleaks Action; personal-account repositories do not require it.
- CodeQL is required for PRs and runs weekly.
- No unresolved critical/high security finding may be waived silently. A temporary exception requires written risk acceptance, compensating controls, owner, and expiry date.
- No credentials or secrets are allowed in source, fixtures, logs, test reports, or artifacts.

## 6. Architecture boundaries

`scripts/check-architecture.ts` parses source imports and enforces these rules:

1. UI, tRPC, and MCP adapters cannot import database clients, schemas, or repositories directly.
2. UI modules cannot call service implementations directly; they use the typed API boundary.
3. Shared contracts cannot import application, adapter, repository, or database code.
4. Core/domain/service modules cannot import Next.js, React, tRPC, MCP, or delivery adapters.
5. Services cannot import the database client/schema directly; use repository abstractions.
6. Repositories cannot depend on services or delivery adapters.

New architecture layers must update the checker and its tests in the same PR.

## 7. Database integration requirements

Database behavior must be tested on PostgreSQL 16, including:

- Composite workspace foreign keys and cross-workspace access rejection.
- One-owner-per-workspace invariant.
- Immutable entity kind.
- Append-only audit rows.
- Relation uniqueness, self-link rejection, and validity constraints.
- Template/entity foreign-key integrity.
- Generated full-text search vector.
- Transaction rollback and mutation/audit atomicity once concrete services are implemented.

Use `TEST_DATABASE_URL` only with a database name ending in `_test`. CI uses a disposable PostgreSQL service. Local tests use `compose.test.yaml` on port 5433.

## 8. Branch ruleset setup

The source package cannot configure repository-hosted protection before the GitHub repository exists. The repository owner must:

1. Set `main` as the default branch.
2. Create a branch ruleset targeting `refs/heads/main`.
3. Require pull requests, one independent approval, dismissal of stale approvals, and approval of the most recent push.
4. Require all five status checks listed above.
5. Require branches to be up to date before merge.
6. Block force pushes and branch deletion.
7. Restrict bypass to a small administrator group and document each use.

If only one maintainer exists, a second maintainer must be added before enforcing the independent-approval rule; an author cannot satisfy their own approval requirement. Do not weaken the policy by treating an automated coding agent as an independent human reviewer.

## 9. M0 limitations

The project currently has no committed npm lockfile because the package registry was unreachable in the artifact environment. The CI workflows intentionally fail with an actionable message until `npm install` has generated a reviewed `package-lock.json` and it has been committed. CI uses `npm ci` after that point. Docker/PostgreSQL is also unavailable in the artifact environment, so the new real-PostgreSQL integration tests are provided but were not executed here.
