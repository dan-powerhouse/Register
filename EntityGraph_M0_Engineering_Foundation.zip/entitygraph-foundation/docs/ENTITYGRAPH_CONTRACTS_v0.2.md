# EntityGraph — Complete Technical Contracts

**Version:** 0.2  
**Status:** Implementation baseline; proposed defaults are identified and should be accepted before schema freeze.  
**Supersedes:** `ENTITYGRAPH_CONTRACTS.md` v0.1  
**Source of product requirements:** `EntityGraph Web App Plan.md`  
**Purpose:** Define the complete, testable contracts for the database, domain, services, authorization, tRPC/UI, MCP, imports/exports, audit, and operations.

---

## 0. Contract language and implementation rules

### 0.1 Requirement labels

- **Committed** — explicitly stated in the source plan.
- **Proposed default** — needed to make implementation deterministic; this document recommends a value, but it is an architectural refinement rather than a source-plan requirement.
- **Deferred** — explicitly outside v1 or assigned to a later milestone.
- **Decision required** — cannot safely be inferred; a recommendation is supplied where possible.

### 0.2 Non-negotiable architecture boundary

```text
Next.js UI ── tRPC adapter ──┐
                             ├── Core services ── Drizzle ── PostgreSQL 16
MCP HTTP ──── MCP adapter ───┘       │
                                     ├── Zod validation
                                     ├── workspace authorization
                                     ├── transaction management
                                     └── audit instrumentation
```

1. The web UI and MCP adapter call the same core services.
2. Adapters authenticate the caller, construct a trusted `Principal`, validate transport-level shape, and translate results/errors. They do not implement business rules.
3. Core services own business validation, authorization checks, and transactions.
4. PostgreSQL constraints enforce relational invariants that can be expressed in the database.
5. No UI component, tRPC procedure, MCP tool handler, import routine, or background job may write directly to domain tables outside the service/repository transaction boundary.
6. The application uses one PostgreSQL database. A graph database, graph visualization, microservices, and per-entity ACLs are out of scope for v1.

### 0.3 Locked stack from the source plan

Next.js 15+ App Router, TypeScript, PostgreSQL 16, Drizzle ORM, Zod v4, better-auth (email magic link + Google OAuth), tRPC, Tailwind CSS, shadcn/ui, TanStack Table/Query, and a single container deployment with managed PostgreSQL. The MCP TypeScript SDK is pinned to the 2026-07-28 protocol revision and isolated in `src/mcp/`.

### 0.4 Cross-cutting conventions

- IDs: UUID strings at API boundaries; PostgreSQL `uuid` internally.
- Timestamps: `timestamptz`; emit RFC 3339 UTC strings.
- Date-only template values: `YYYY-MM-DD`; do not convert them through a timezone.
- JSON attributes: JSON objects only; arrays/scalars are rejected at the top level.
- Nullability: omitted optional input means “leave unchanged” on PATCH; explicit `null` clears only fields whose contract permits null.
- Pagination: opaque cursor pagination; maximum list page size is 100 (proposed default).
- All list/search/traversal requests are workspace-scoped and bounded.
- Client-supplied `workspaceId`, actor IDs, roles, audit fields, and token scopes are never trusted as authorization facts.

---

# 1. Domain contracts

## 1.1 Shared types

```ts
export type UUID = string;
export type ISODateTime = string; // RFC 3339 UTC timestamp
export type DateOnly = string;    // YYYY-MM-DD

export type EntityKind = "person" | "object" | "process";
export type EntityStatus = "active" | "inactive" | "archived";
export type WorkspaceRole = "owner" | "admin" | "editor" | "viewer";
export type TokenScope = "read" | "write";
export type ActorType = "user" | "token" | "system";
export type RequestSource = "ui" | "trpc" | "mcp" | "import" | "system";
export type JsonPrimitive = string | number | boolean | null;
export type JsonValue = JsonPrimitive | JsonValue[] | { [key: string]: JsonValue };
export type JsonObject = Record<string, JsonValue>;
```

JSON numbers must be finite. `NaN`, positive/negative infinity, `undefined`, functions, dates, and class instances are not valid JSON values.

## 1.2 Workspace and membership

The source plan uses workspace roles and workspace-configurable registries but does not define their storage boundary. **Proposed default: implement explicit multi-workspace isolation from the first migration.**

```ts
export interface Workspace {
  id: UUID;
  name: string;
  slug: string;
  staleProcessDays: number;
  createdAt: ISODateTime;
  updatedAt: ISODateTime;
}

export interface WorkspaceMember {
  workspaceId: UUID;
  userId: UUID;
  role: WorkspaceRole;
  createdAt: ISODateTime;
  updatedAt: ISODateTime;
}
```

A user may belong to multiple workspaces. Every workspace has exactly one `owner` in v1; ownership transfer is an explicit operation. All entities, relations, templates, predicates, saved views, tokens, and audit queries are scoped to one workspace. An MCP token is bound to exactly one workspace.

## 1.3 Entity

```ts
export interface Entity {
  id: UUID;
  workspaceId: UUID;
  kind: EntityKind;
  type: string;
  title: string;
  status: EntityStatus;
  attributes: JsonObject;
  notes: string | null;
  tags: string[];
  createdBy: UUID;
  updatedBy: UUID;
  createdAt: ISODateTime;
  updatedAt: ISODateTime;
  version: number;
}
```

**Committed:** one `entity` table for all three kinds; `kind` is constrained to the three allowed values; `(kind,type)` uses a type template; attributes are JSONB; `version` supports optimistic locking; archive is a status, not physical deletion.

**Proposed defaults:**
- `kind` is immutable after creation.
- `type` can change only if the destination template exists and the complete resulting attributes validate against it.
- `version` starts at `1` and increments by exactly one for each successful entity mutation (including status and tag changes).
- `title` is trimmed and must not be empty. Proposed maximum: 300 Unicode characters.
- `type` and tag values are trimmed. Tags are case-insensitive for uniqueness and are stored in normalized lowercase form.
- `createdBy` and `updatedBy` always refer to the effective human user, including for token writes; token identity is retained separately in the audit record.
- `archived` is terminal in v1: no unarchive/restore operation is exposed.

## 1.4 Relation

```ts
export interface Relation {
  id: UUID;
  workspaceId: UUID;
  fromId: UUID;
  toId: UUID;
  predicate: string;
  attributes: JsonObject;
  validFrom: ISODateTime | null;
  validTo: ISODateTime | null;
  createdBy: UUID;
  updatedBy: UUID;
  createdAt: ISODateTime;
  updatedAt: ISODateTime;
  version: number;
}
```

**Committed:** both endpoints are real foreign keys to `entity`; self-links are forbidden; predicate legality is registry-validated transactionally; `(from_id,predicate,to_id)` is unique; relation validity is temporal metadata.

**Proposed defaults:**
- One stored row per `(workspaceId, fromId, predicate, toId)` triple. A validity period is updated on that row; repeated historical episodes for the same triple are not represented as multiple rows in v1.
- `validTo > validFrom` when both are present.
- `directed: false` means the relationship is semantically traversable in either direction while remaining one stored row. The stored `fromId`/`toId` orientation remains the canonical display orientation.
- `symmetricHelper` is vocabulary/UX metadata only; it does not automatically create a reciprocal relation.
- Relation `version` and `updatedAt/updatedBy` are proposed refinements to make relation updates auditable and safe under concurrent editing.
- Relation endpoint and predicate changes are not supported by update; delete and recreate instead.

## 1.5 Type templates

```ts
export type TemplateFieldType =
  | "text" | "number" | "date" | "select" | "multiselect" | "entity_ref";

export interface TemplateField {
  name: string;
  dataType: TemplateFieldType;
  required?: boolean;
  options?: string[];
  default?: JsonValue;
  entityRefKind?: EntityKind;
}

export interface TypeTemplate {
  workspaceId: UUID;
  kind: EntityKind;
  type: string;
  version: number;
  fields: TemplateField[];
  updatedBy: UUID;
  updatedAt: ISODateTime;
}
```

Validation rules:

| Field type | Stored JSON value | Rule |
|---|---|---|
| `text` | string | No implicit coercion. |
| `number` | finite number | No numeric strings. |
| `date` | string | Must parse as a real calendar date in `YYYY-MM-DD` form. |
| `select` | string | Exact match to one configured option. |
| `multiselect` | string array | Every value must be an option; duplicates are rejected. |
| `entity_ref` | UUID string | Referenced entity must exist in the same workspace; optional `entityRefKind` must match its kind. |

Further rules:
- Field names are unique within a template and use a stable key format such as `snake_case`.
- `options` are permitted only for `select`/`multiselect`, must be non-empty, and must contain unique values.
- `default`, when present, must pass the field's own data-type validation.
- Missing required fields fail validation. A field explicitly present with `null` fails unless null support is deliberately added later.
- Unknown attribute keys are rejected (strict object schema).
- Defaults are applied on entity creation before validation. Existing records are not silently rewritten when a template changes.
- Template changes increment `version` and are audited. A change is rejected if it would make any existing entity of that `(kind,type)` invalid. This avoids introducing a data-migration subsystem in v1 while preventing schema drift.

## 1.6 Predicate definition

```ts
export interface PredicateDefinition {
  workspaceId: UUID;
  name: string;
  fromKinds: EntityKind[];
  toKinds: EntityKind[];
  directed: boolean;
  symmetricHelper: string | null;
  description: string;
  version: number;
  createdBy: UUID;
  updatedBy: UUID;
  createdAt: ISODateTime;
  updatedAt: ISODateTime;
}
```

- Predicate `name` is unique within a workspace.
- `fromKinds` and `toKinds` must each contain at least one valid `EntityKind`.
- `description` is included in MCP tool/resource descriptions so agents learn the workspace vocabulary.
- Predicate creation/update is admin-only. New predicates start at version 1; updates require `expectedVersion` and increment version exactly once.
- A predicate referenced by existing relations cannot be deleted.
- Updating kind compatibility is rejected if it would make any existing relation illegal.
- `symmetricHelper` must refer to another predicate in the same workspace when non-null; it is descriptive metadata, not an automatic write rule.

## 1.7 API token

```ts
export interface ApiTokenSummary {
  id: UUID;
  workspaceId: UUID;
  userId: UUID;       // effective user represented by this token
  label: string;
  prefix: string;     // non-secret identifier shown in admin UI
  scopes: TokenScope[];
  createdBy: UUID;    // admin who issued it
  createdAt: ISODateTime;
  lastUsedAt: ISODateTime | null;
  expiresAt: ISODateTime | null;
  revokedAt: ISODateTime | null;
}
```

The raw token is returned exactly once at issuance and is never stored, logged, audited, or shown again. The token is bound to one user and one workspace.

## 1.8 Audit entry

```ts
export interface AuditEntry {
  id: UUID;
  workspaceId: UUID;
  at: ISODateTime;
  actorType: ActorType;
  actorId: UUID | null;
  effectiveUserId: UUID | null;
  source: RequestSource;
  requestId: string;
  action: string;
  targetType: string | null;
  targetId: UUID | null;
  outcome: "success" | "failure";
  before: JsonValue | null;
  after: JsonValue | null;
  metadata: JsonObject;
}
```

Successful data mutations include before/after snapshots and are written atomically with the mutation. The source plan additionally states that every MCP call is audited: authenticated MCP tool calls, resource reads, and protocol operations (including discovery/list operations) therefore create an audit event with token identity, action, outcome, and request ID. Read/protocol events have null before/after snapshots. Invalid-token attempts, where no actor can be established, go to a separate security-event log and never include the submitted token.

---

# 2. Persistence contract

## 2.1 Tables

The Drizzle schema must implement at least the following tables. Better-auth owns its standard user/session/account/verification tables; do not duplicate those tables in application code.

| Table | Purpose / key columns |
|---|---|
| `workspace` | `id`, `name`, unique `slug`, `stale_process_days`, timestamps |
| `workspace_member` | composite PK `(workspace_id,user_id)`, `role`, timestamps |
| `workspace_invitation` | workspace, email, role, hashed invite token, invited by, expiry, accepted/revoked timestamps |
| `entity` | all fields in §1.3; `UNIQUE(workspace_id,id)` for composite FKs |
| `relation` | all fields in §1.4; unique triple and `UNIQUE(workspace_id,id)` |
| `predicate_registry` | all fields in §1.6; PK `(workspace_id,name)` |
| `type_templates` | workspace, kind, type, version, fields JSONB, updated metadata; PK `(workspace_id,kind,type)` |
| `api_token` | token hash, prefix, workspace/user, scopes, issuer, last-used, expiry, revocation |
| `audit_log` | append-only audit events in §1.8 |
| `security_event_log` | unauthenticated/security events that cannot be attributed to a known actor |
| `saved_view` | workspace/user, name, visibility, entity kind, validated search query JSONB, timestamps |
| `import_job` | dry-run/commit staging, source hash, validation report, staged payload or durable staging reference, expiry, state |
| `api_rate_bucket` | shared per-token rate-limit bucket/counter if rate limiting is implemented in PostgreSQL |

## 2.2 Required relational constraints

- `entity.kind` CHECK: `person`, `object`, `process`.
- `entity.status` CHECK: `active`, `inactive`, `archived`.
- `entity.version >= 1`.
- `UNIQUE(entity.workspace_id, entity.id)`.
- `relation` has composite FKs `(workspace_id,from_id)` and `(workspace_id,to_id)` to `entity(workspace_id,id)`; this prevents cross-workspace edges.
- `relation` has composite FK `(workspace_id,predicate)` to `predicate_registry(workspace_id,name)`.
- `UNIQUE(relation.workspace_id, relation.from_id, relation.predicate, relation.to_id)`.
- `CHECK(relation.from_id <> relation.to_id)`.
- `CHECK(valid_from IS NULL OR valid_to IS NULL OR valid_to > valid_from)`.
- `UNIQUE(workspace_id,kind,type)` on the current template row.
- `predicate_registry.version >= 1`; update requires compare-and-swap against the current version.
- `api_token` references `(workspace_id,user_id)` in `workspace_member`; a removed member's tokens are revoked transactionally.
- `workspace_member.role` CHECK: `owner`, `admin`, `editor`, `viewer`.
- `api_token.scopes` contains only `read` and/or `write`; `read` is mandatory.
- `saved_view` visibility CHECK: `personal` or `workspace`; includes `version >= 1`.
- `workspace_invitation` stores only a hash of the single-use invitation secret and has a unique active invitation per workspace/email.
- `import_job` states are `uploaded`, `previewed`, `committed`, `failed`, or `expired`; upload/preview ownership is `(workspace_id,user_id)`.
- `security_event_log` records `at`, nullable workspace/user/token references, request ID, event type, outcome, and safe metadata (never raw secrets).
- Audit rows are append-only for application roles: no UPDATE/DELETE grants on `audit_log`.

Kind/predicate compatibility requires a transaction because it spans entity rows and registry arrays. During relation creation, lock the predicate row `FOR SHARE` and read both endpoints in the same transaction. Predicate updates lock the predicate row `FOR UPDATE` and validate existing relations before commit. Since entity kind is immutable, endpoint-kind races are eliminated.

## 2.3 Index contract

At minimum:
- B-tree `(workspace_id, kind, status, updated_at DESC, id)` for entity lists.
- Partial indexes by `kind` for people, objects, and processes as specified by the source plan.
- B-tree `(workspace_id, type)` and `(workspace_id, status)` where query plans justify them.
- GIN on `entity.search_vector` for full-text search.
- GIN on `entity.attributes` (JSONB) for structured JSONB filters.
- GIN on `entity.tags` for tag filtering.
- B-tree `(workspace_id, from_id, predicate)` and `(workspace_id, to_id, predicate)` for relation panels/traversal.
- B-tree on `audit_log(workspace_id, target_type, target_id, at DESC)` and `(workspace_id, at DESC)`.
- Unique index on `api_token.token_hash`; indexes for workspace/user/revocation lookup.
- Rate-bucket index on `(token_id, window_start)`.

The source plan calls for SQL views `people`, `objects`, and `processes`; create workspace-aware views exposing only the corresponding kind, but continue to route application queries through the shared repositories/services.

## 2.4 Search vector

**Committed:** full-text search over title, notes, and attributes using a stored `tsvector` and GIN index; all list views and global search share one `searchService`.

**Proposed default:** use PostgreSQL `simple` text configuration for mixed-language content without assuming a single language's stemming rules. Weight title above notes above string values extracted from JSONB attributes. Keep the expression dependent only on the entity row (for example, title + notes + `jsonb_to_tsvector` over string values); do not query templates from a generated column. Also maintain a separate GIN JSONB index for structured filters.

---

# 3. Validation contract (Zod v4)

## 3.1 Shared schema modules

```text
src/contracts/
  common.ts          // UUID, ISODateTime, JsonObject, pagination
  workspace.ts       // workspace/member/invitation inputs
  entity.ts          // Entity, create/update/bulk inputs
  relation.ts        // Relation inputs and validity
  template.ts        // template fields and attributes
  predicate.ts       // predicate definitions
  search.ts          // EntityListQuery, filters, sort, cursor
  traversal.ts       // traversal and path reports
  token.ts           // token issue/revoke inputs; never raw token persistence
  audit.ts           // read-only audit DTOs
  saved-view.ts      // saved query DTOs
  import-export.ts   // import/export contracts
  errors.ts          // ServiceError and ErrorEnvelope
```

The exact same Zod schemas are imported by UI forms, tRPC procedures, and MCP handlers where the shape is shared. Dynamic template validation is built from the stored template but is repeated by the core service at write time.

## 3.2 Input normalization

- Trim title, type, predicate name, template field names, tag values, and user-facing labels.
- Reject blank strings after trimming.
- Normalize tags to lowercase, deduplicate them, and preserve deterministic sort order.
- Reject unknown object keys except where a schema explicitly uses passthrough metadata.
- Validate UUIDs and ISO timestamps strictly.
- Do not silently coerce strings to numbers, date strings to timestamps, or booleans to strings.
- Apply template defaults only on entity creation; on update, omitted fields retain existing values.

## 3.3 Validation order for writes

1. Authenticate and resolve workspace-scoped principal.
2. Check operation permission.
3. Parse transport input with static Zod schema.
4. Load the current template/predicate and current entity state.
5. Build the complete resulting entity/relation state.
6. Validate dynamic template/predicate rules and cross-record references.
7. Check expected version and relational uniqueness.
8. Persist mutation and audit event in one transaction.

No adapter may skip steps 4–8.

---

# 4. Principal, errors, and result contracts

## 4.1 Principal

```ts
export interface Principal {
  workspaceId: UUID;
  actorType: "user" | "token";
  actorId: UUID;           // user ID for UI; token ID for MCP
  userId: UUID;            // effective user represented by the request
  role: WorkspaceRole;
  tokenScopes?: TokenScope[]; // only present for token principals
  requestId: string;
  source: RequestSource;
}
```

The principal is created by trusted auth middleware. Clients cannot provide their own role, scopes, `userId`, or actor ID.

## 4.2 Page and result types

```ts
export interface Page<T> {
  items: T[];
  nextCursor: string | null;
}

export type ServiceResult<T> = T; // service failures throw ServiceError
```

Cursor tokens are opaque, signed or otherwise integrity-protected, bound to the workspace and normalized query, and include a deterministic tie-breaker. They expire after a configurable period (proposed default: 30 minutes).

## 4.3 Error codes

```ts
export type ServiceErrorCode =
  | "VALIDATION_ERROR"
  | "UNAUTHENTICATED"
  | "FORBIDDEN"
  | "NOT_FOUND"
  | "CONFLICT"
  | "VERSION_CONFLICT"
  | "ARCHIVED_ENTITY"
  | "TEMPLATE_NOT_FOUND"
  | "TEMPLATE_IN_USE"
  | "INVALID_PREDICATE"
  | "RELATION_KIND_MISMATCH"
  | "RELATION_ALREADY_EXISTS"
  | "INVALID_VALIDITY_RANGE"
  | "LAST_OWNER"
  | "INVITATION_EXPIRED"
  | "TOKEN_REVOKED"
  | "RATE_LIMITED"
  | "PAYLOAD_TOO_LARGE"
  | "IMPORT_VALIDATION_FAILED"
  | "CURSOR_INVALID"
  | "INTERNAL_ERROR";

export interface ServiceError {
  code: ServiceErrorCode;
  message: string;
  details?: JsonObject;
  retryable?: boolean;
}

export interface ErrorEnvelope {
  error: {
    code: ServiceErrorCode;
    message: string;
    details?: JsonObject;
    retryable?: boolean;
    requestId: string;
  };
}
```

Do not expose stack traces, SQL, token material, raw invitation values, secrets, or internal host/config details. `NOT_FOUND` should be used for both nonexistent and out-of-workspace records to avoid cross-workspace existence disclosure.

---

# 5. Core service contracts

All service methods take a trusted `Principal` except authentication/bootstrap methods. Domain return types do not expose Drizzle rows.

## 5.1 Entity service

```ts
export interface CreateEntityInput {
  kind: EntityKind;
  type: string;
  title: string;
  status?: "active" | "inactive"; // defaults to active
  attributes?: JsonObject;
  notes?: string | null;
  tags?: string[];
}

export interface UpdateEntityInput {
  id: UUID;
  expectedVersion: number;
  type?: string;
  title?: string;
  status?: "active" | "inactive";
  attributes?: JsonObject; // complete replacement of attributes when supplied
  notes?: string | null;
  tags?: string[];
}

export interface EntityService {
  create(p: Principal, input: CreateEntityInput): Promise<Entity>;
  getById(p: Principal, id: UUID): Promise<Entity>;
  update(p: Principal, input: UpdateEntityInput): Promise<Entity>;
  archive(p: Principal, id: UUID, expectedVersion: number): Promise<Entity>;
}
```

Behavior:
- `create`: require registered template; apply defaults; validate attributes and entity refs; create version 1; set creator/updater; audit in same transaction.
- `getById`: return only a record in the principal's workspace; archived entities remain retrievable.
- `update`: PATCH semantics for top-level fields; when `attributes` is present it replaces the attributes object as a whole; validate the complete resulting record against its current template; require `expectedVersion`; increment version exactly once.
- `archive`: transition any non-archived entity to archived; reject stale version; keep relations intact; do not physically delete; audit in same transaction.
- Ordinary update cannot change `kind` or transition to `archived`; use `archive` for that transition.
- Archived entities cannot be edited. V1 has no restore operation.

## 5.2 Relation service

```ts
export interface CreateRelationInput {
  fromId: UUID;
  toId: UUID;
  predicate: string;
  attributes?: JsonObject;
  validFrom?: ISODateTime | null;
  validTo?: ISODateTime | null;
}

export interface UpdateRelationInput {
  id: UUID;
  expectedVersion: number;
  attributes?: JsonObject;
  validFrom?: ISODateTime | null;
  validTo?: ISODateTime | null;
}

export interface RelationService {
  create(p: Principal, input: CreateRelationInput): Promise<Relation>;
  update(p: Principal, input: UpdateRelationInput): Promise<Relation>;
  delete(p: Principal, id: UUID): Promise<void>;
  listForEntity(p: Principal, entityId: UUID): Promise<{
    outgoing: Relation[];
    incoming: Relation[];
  }>;
}
```

Behavior:
- Create requires both endpoints in the same workspace, rejects self-links, validates the predicate's allowed kinds in the same transaction, rejects archived endpoints, validates validity range, and enforces the unique triple.
- `directed:false` does not create a second row. Traversal treats the edge as traversable in both directions.
- Update permits only attributes and validity changes; it requires `expectedVersion` and increments relation version.
- Delete physically removes only the relation row, but writes a deletion audit event with the deleted row in `before`.
- Listing returns distinct incoming and outgoing rows without collapsing predicate/direction. A symmetric predicate may be surfaced as traversable from either side by traversal, but list orientation remains the persisted orientation.

## 5.3 Template service

```ts
export interface UpsertTemplateInput {
  kind: EntityKind;
  type: string;
  expectedVersion?: number; // absent only when creating the first version
  fields: TemplateField[];
}

export interface TemplateService {
  list(p: Principal, kind?: EntityKind): Promise<TypeTemplate[]>;
  get(p: Principal, kind: EntityKind, type: string): Promise<TypeTemplate>;
  upsert(p: Principal, input: UpsertTemplateInput): Promise<TypeTemplate>;
}
```

`upsert` is owner/admin only. Existing template updates require `expectedVersion`; it validates all existing entities of that `(kind,type)` against the candidate template before activation. Any invalidation fails with `CONFLICT` and a bounded list of entity IDs/field errors. Template deletion is not offered in v1; unused templates can be retained or marked deprecated in a later addition.

## 5.4 Predicate service

```ts
export interface UpsertPredicateInput {
  name: string;
  expectedVersion?: number; // absent only when creating the first version
  fromKinds: EntityKind[];
  toKinds: EntityKind[];
  directed: boolean;
  symmetricHelper?: string | null;
  description: string;
}

export interface PredicateService {
  list(p: Principal): Promise<PredicateDefinition[]>;
  get(p: Principal, name: string): Promise<PredicateDefinition>;
  upsert(p: Principal, input: UpsertPredicateInput): Promise<PredicateDefinition>;
  delete(p: Principal, name: string): Promise<void>;
}
```

`upsert` and `delete` are owner/admin only. New predicates start at version 1; every update requires `expectedVersion` and increments the version. An update that invalidates an existing edge is rejected. Delete is rejected while any relation uses the predicate. No implicit reciprocal edge creation is permitted.

## 5.5 Search/list service

```ts
export type AttributeOperator = "eq" | "contains" | "gt" | "gte" | "lt" | "lte";

export interface AttributeFilter {
  key: string;
  operator: AttributeOperator;
  value: JsonValue;
}

export interface EntityListQuery {
  q?: string;
  kind?: EntityKind;
  type?: string;
  status?: EntityStatus[];
  tagsAny?: string[];
  attributeFilters?: AttributeFilter[];
  limit?: number;
  cursor?: string;
  sort?: { field: "title" | "createdAt" | "updatedAt"; direction: "asc" | "desc" };
}

export interface SearchService {
  search(p: Principal, query: EntityListQuery): Promise<Page<Entity>>;
}
```

Search semantics:
- All filters are combined with AND, except `tagsAny`, whose values are ORed with each other.
- `q` performs PostgreSQL full-text search over title, notes, and string values in attributes.
- `eq` performs JSONB equality against the attribute value.
- `contains` means case-insensitive substring for string attributes, or element containment for JSON array attributes. It is invalid for numbers/objects.
- `gt/gte/lt/lte` require numeric JSON values on both sides.
- Unsupported attribute key/operator/value combinations return `VALIDATION_ERROR`, not a silent empty result.
- The default status set is `active` and `inactive`; archived records are included only when explicitly requested.
- Without `q`, default order is `updatedAt DESC, id DESC`. With `q`, default order is relevance DESC, then `updatedAt DESC, id DESC`.
- Cursors encode the final sort tuple and are invalid if reused with a different workspace/query/sort.
- Default limit 25, maximum 100. Counts are omitted from regular pages to avoid forcing expensive count queries.

## 5.6 Traversal and path reports

```ts
export interface TraverseInput {
  startId: UUID;
  predicates?: string[];
  direction?: "outgoing" | "incoming" | "both";
  depth: 1 | 2 | 3;
  maxNodes?: number;
}

export interface TraversalResult {
  start: Entity;
  nodes: Array<{ entity: Entity; depth: number }>;
  relations: Relation[];
  truncated: boolean;
}

export interface TraversalService {
  traverse(p: Principal, input: TraverseInput): Promise<TraversalResult>;
}
```

- Depth is 1–3; MCP cannot exceed 3. UI path panels use 1–2.
- The start entity is returned separately and is not counted against the node cap.
- Nodes are unique by entity ID and retain their minimum discovered depth. Relations include the traversed edges; duplicate edges are removed by relation ID.
- `maxNodes` is clamped to 500. Reaching the limit sets `truncated: true`.
- `directed:false` predicates may be followed from either endpoint. Directed predicates respect the requested direction.
- Archived entities are not traversed by default; the start entity may be archived for inspection, but archived adjacent nodes are excluded.
- Every query is workspace-scoped and subject to read authorization.

The UI's three named path panels are query presets over this traversal contract, not a separate graph engine: “Processes requiring this object”, “People owning objects used by this process”, and “Everything this person manages”. Their actual path pattern is resolved from the workspace's predicate definitions; if the necessary predicate is absent, the panel reports that it is not configured rather than guessing.

For ordered multi-hop reports, use a path-pattern query rather than treating the `predicates` filter as an ordered sequence:

```ts
export interface PathStep {
  predicate: string;
  direction: "outgoing" | "incoming" | "either";
}
export interface PathPatternInput {
  startId: UUID;
  steps: PathStep[]; // 1 or 2 steps for the UI path panel
  maxResults?: number;
}
export interface PathReportService {
  run(p: Principal, input: PathPatternInput): Promise<Array<{ entities: Entity[]; relations: Relation[] }>>;
}
```

The report preset defines an ordered sequence of predicate+direction steps. The service verifies that every predicate exists and that each step's endpoint kinds are legal. This preserves the exact examples in the source plan without introducing a visual graph editor.

## 5.7 Audit service

```ts
export interface AuditQuery {
  targetType?: string;
  targetId?: UUID;
  actorUserId?: UUID;
  source?: RequestSource;
  actionPrefix?: string;
  limit?: number;
  cursor?: string;
}

export interface AuditService {
  listForEntity(p: Principal, entityId: UUID, query?: Omit<AuditQuery, "targetId">): Promise<Page<AuditEntry>>;
  listRecent(p: Principal, query: AuditQuery): Promise<Page<AuditEntry>>;
}
```

Audit insertion is an internal repository operation that receives the active transaction from the mutation/request coordinator; it is not exposed as an arbitrary public service method. `listForEntity` powers History; `listRecent` powers dashboard activity. Audit rows are immutable.

## 5.8 Workspace and member services

```ts
export interface InvitationDeliveryPort {
  sendInvitation(input: { email: string; workspaceName: string; invitationUrl: string; expiresAt: ISODateTime }): Promise<void>;
}

export interface MemberService {
  list(p: Principal): Promise<WorkspaceMember[]>;
  invite(p: Principal, input: { email: string; role: "admin" | "editor" | "viewer" }): Promise<{ invitationId: UUID; expiresAt: ISODateTime }>;
  updateRole(p: Principal, input: { userId: UUID; role: Exclude<WorkspaceRole, "owner"> }): Promise<WorkspaceMember>;
  remove(p: Principal, userId: UUID): Promise<void>;
  transferOwnership(p: Principal, newOwnerUserId: UUID): Promise<void>;
  acceptInvitation(userId: UUID, invitationToken: string): Promise<WorkspaceMember>;
}

export interface WorkspaceService {
  createForUser(userId: UUID, input: { name: string; slug: string }): Promise<Workspace>;
  listForUser(userId: UUID): Promise<Workspace[]>;
  get(p: Principal): Promise<Workspace>;
  update(p: Principal, input: { name?: string; slug?: string; staleProcessDays?: number }): Promise<Workspace>;
}
```

- Only owner/admin may invite, change non-owner roles, or remove non-owner members.
- Only owner may transfer ownership. The existing owner becomes admin after successful transfer.
- An owner cannot be removed/demoted except through transfer; the workspace must always retain exactly one owner.
- Admin cannot assign the owner role.
- Removing a member revokes all their workspace tokens in the same transaction.
- Invitations are email-bound, single-use, stored hashed, expire after 7 days (proposed default), and are accepted only by an authenticated account with the matching email.
- The email delivery provider is not selected in the source plan; implement an `InvitationDeliveryPort` and choose its concrete provider during deployment setup.

`WorkspaceService.get/update` supports workspace name, slug, and `staleProcessDays`. Owner/admin may update workspace settings. `staleProcessDays` defaults to 90 days (proposed default) and must be a positive integer. `createForUser` is the first-workspace bootstrap operation: it creates the workspace and its first `owner` membership atomically. Slugs are globally unique.

## 5.9 API token service

```ts
export interface TokenService {
  list(p: Principal, userId?: UUID): Promise<ApiTokenSummary[]>;
  issue(p: Principal, input: { userId: UUID; label: string; scopes: TokenScope[]; expiresAt?: ISODateTime | null }): Promise<{ token: string; summary: ApiTokenSummary }>;
  revoke(p: Principal, tokenId: UUID): Promise<void>;
}
```

- Only owner/admin may issue/revoke workspace tokens. An issued token belongs to a workspace member and represents that member's role.
- Every token includes `read`; `write` is optional. Effective permission is the intersection of member role and token scopes.
- Token value is generated with at least 256 bits of cryptographic randomness and shown once. Store only a one-way hash and a short public prefix.
- Authentication checks revoked/expiry state on each request so revocation is immediate. Do not rely on a long-lived token-auth cache.
- `lastUsedAt` updates on authenticated requests, throttled to at most once per minute per token.
- Revocation is idempotent.

## 5.10 Dashboard service

```ts
export interface DashboardSummary {
  countsByKind: Record<EntityKind, number>;
  recentActivity: AuditEntry[];
  orphanCountsByKind: Record<EntityKind, number>;
  staleProcesses: Entity[]; // oldest 20 by updatedAt; list is separately pageable if needed
  staleProcessDays: number;
}

export interface DashboardService {
  getSummary(p: Principal): Promise<DashboardSummary>;
}
```

Definitions:
- Counts include active and inactive entities, excluding archived.
- An orphan is a non-archived entity with no incoming or outgoing relations.
- A stale process is an active `process` entity whose `updatedAt` is older than workspace `staleProcessDays`.
- Recent activity is successful data mutations plus any MCP events shown in the activity feed; UI may default-filter reads from the visible feed.
- Queries must be bounded and indexed; counts may be cached briefly only if freshness is documented. Default freshness target: 60 seconds.

## 5.11 Bulk entity operations

The source plan commits to bulk tag and archive from entity lists. These operations are UI/tRPC capabilities only; the MCP tool set remains exactly nine tools.

```ts
export interface BulkTagInput {
  items: Array<{ id: UUID; expectedVersion: number }>;
  mode: "add" | "remove" | "replace";
  tags: string[];
}

export interface BulkArchiveInput {
  items: Array<{ id: UUID; expectedVersion: number }>;
}

export interface BulkMutationResult {
  updated: Entity[];
}

export interface BulkEntityService {
  updateTags(p: Principal, input: BulkTagInput): Promise<BulkMutationResult>;
  archive(p: Principal, input: BulkArchiveInput): Promise<BulkMutationResult>;
}
```

Proposed limits/behavior: maximum 100 entities per request; operation is all-or-nothing; every item must be in the workspace and match its expected version for both tag and archive operations; lock rows in stable ID order; one audit row per entity changed. A stale/missing item fails the entire transaction and returns item-level error details.

## 5.12 Saved views (M4)

```ts
export interface SavedView {
  id: UUID;
  version: number;
  workspaceId: UUID;
  ownerUserId: UUID;
  name: string;
  visibility: "personal" | "workspace";
  kind: EntityKind | null;
  query: EntityListQuery;
  createdAt: ISODateTime;
  updatedAt: ISODateTime;
}
```

A saved view stores only a validated `EntityListQuery`; it never stores raw SQL. Personal views are visible to their owner. Workspace views are visible to all members. For personal views, only the ownerUserId may read/update/delete. For workspace views, all members may read; the creator may update/delete their own view, and owner/admin may manage any workspace view. Saved-view query execution always re-applies the caller's workspace and permissions. Updates require `expectedVersion` and increment `version`.

```ts
export interface SavedViewService {
  list(p: Principal, kind?: EntityKind): Promise<SavedView[]>;
  create(p: Principal, input: { name: string; visibility: "personal" | "workspace"; kind: EntityKind | null; query: EntityListQuery }): Promise<SavedView>;
  update(p: Principal, input: { id: UUID; expectedVersion: number; name?: string; visibility?: "personal" | "workspace"; query?: EntityListQuery }): Promise<SavedView>;
  delete(p: Principal, id: UUID): Promise<void>;
}
```

## 5.13 CSV import/export (M4)

**Proposed format:** a ZIP package containing `entities.csv`, `relations.csv`, and `manifest.json`. The manifest contains `formatVersion`, `exportedAt`, source workspace ID (informational only), row counts, and SHA-256 checksums.

`entities.csv` columns: `id,kind,type,title,status,attributes_json,notes,tags_json`. `relations.csv` columns: `id,from_id,to_id,predicate,attributes_json,valid_from,valid_to`. JSON-valued cells contain compact JSON. Actor IDs and timestamps are not imported; new rows are attributed to the importing user and server time. Templates and predicates are not included: they must already exist and be compatible in the destination workspace. Import never silently overwrites a same-ID record; an existing ID is a conflict, even if its payload appears identical. If users later require a single-file CSV, define a separate format version rather than overloading this one.

```ts
export interface ImportPreview {
  previewId: UUID;
  sourceHash: string;
  expiresAt: ISODateTime;
  entityRows: number;
  relationRows: number;
  validRows: number;
  errors: Array<{ file: string; row: number; field?: string; code: string; message: string }>;
  warnings: Array<{ file: string; row: number; message: string }>;
}

export interface UploadService {
  stageImportPackage(p: Principal, file: Uint8Array): Promise<{ uploadId: UUID; sha256: string; sizeBytes: number }>;
}

export interface ImportService {
  preview(p: Principal, uploadId: UUID): Promise<ImportPreview>;
  commit(p: Principal, previewId: UUID): Promise<{ entitiesCreated: number; relationsCreated: number }>;
}

export interface ExportService {
  create(p: Principal, input: { kinds?: EntityKind[]; includeArchived?: boolean }): Promise<{ exportId: UUID; expiresAt: ISODateTime }>;
  readDownload(p: Principal, exportId: UUID): Promise<Uint8Array>;
}
```

Because tRPC is JSON-oriented, binary transfer uses authenticated Next.js route handlers rather than putting file bytes in JSON procedure inputs/outputs:

| Route | Contract |
|---|---|
| `POST /api/imports/upload` | Authenticated multipart upload; workspace membership + editor role required; returns `{ uploadId, sha256, sizeBytes }`; enforces file cap before parsing. |
| `GET /api/exports/{exportId}` | Authenticated download; export ID is workspace-bound and expires; streams the ZIP package. |

The upload route delegates to `UploadService.stageImportPackage`; tRPC then calls `ImportService.preview` with the returned `uploadId`. `export.create` delegates to `ExportService.create`; the browser downloads the resulting export through the GET route. The tRPC map therefore exposes metadata/control operations only and never base64-encodes large uploads or exports.

- Preview is side-effect free with respect to domain tables; it parses, validates templates, validates references, checks predicate compatibility, and reports duplicate/conflicting IDs.
- Commit accepts only a valid, unexpired preview created by the same workspace/user. It revalidates immediately before writing and is atomic in v1. Upload/preview records are single-use, expire after 30 minutes (proposed default), and are removed by a scheduled cleanup job.
- Import-created entities/relations use source `import` and are audited individually.
- Export includes only the caller's workspace. Archived entities are excluded by default.
- Proposed upload limit: 20 MiB; proposed row limit: 10,000 combined. Both are configurable and tested.

---

# 6. Authorization contract

## 6.1 Role matrix

The source plan commits to workspace roles only (no per-entity ACL). The following action matrix makes those roles executable.

| Capability | Owner | Admin | Editor | Viewer |
|---|---:|---:|---:|---:|
| Read entities, relations, templates, predicates, audit | Yes | Yes | Yes | Yes |
| Create/update/archive entities | Yes | Yes | Yes | No |
| Create/update/delete relations | Yes | Yes | Yes | No |
| Bulk tag/archive | Yes | Yes | Yes | No |
| Manage templates and predicates | Yes | Yes | No | No |
| Invite/manage non-owner members | Yes | Yes | No | No |
| Transfer ownership | Yes | No | No | No |
| Issue/revoke API tokens | Yes | Yes | No | No |
| Update workspace settings | Yes | Yes | No | No |
| Manage workspace-shared saved views | Yes | Yes | Yes (create/update own) | Read |
| View personal saved views | Own | Own | Own | Own |

## 6.2 Token permission intersection

- Human UI request: effective permission is workspace membership role.
- Token request: effective permission is membership role AND token scopes.
- `read` scope permits reads only.
- `write` scope permits mutation only if the represented user's role is owner/admin/editor for that action.
- A viewer's `write` token remains read-only.
- Token permissions cannot exceed the represented user's current membership role. Role changes and member removal take effect on the next request.

## 6.3 Workspace isolation

Every repository query includes `workspace_id = principal.workspaceId`. Composite foreign keys prevent cross-workspace relations. Service tests must verify that guessing another workspace's UUID never reveals record existence. No per-entity ACL is implemented in v1.

---

# 7. Authentication and session contracts

- better-auth handles human account creation/login, email magic links, Google OAuth, and session lifecycle.
- The application auth adapter obtains the verified session user ID; it does not accept a user ID from request payload as proof of identity.
- Workspace context is selected by workspace slug/route or explicit active-workspace selection; membership and current role are revalidated on each request. Do not use an uninvalidated role cache.
- tRPC middleware resolves `Principal` from the authenticated session and selected workspace.
- MCP authentication uses a bearer API token. Tokens are workspace-bound; no workspace selection is accepted from tool arguments.
- OAuth/CIMD for external MCP clients remains deferred as specified in the source plan.
- Account deletion, account merge, Google identity conflict resolution, and email-provider choice beyond better-auth's adapter requirements are deployment/product decisions not specified by the source plan.

---

# 8. tRPC and UI API contracts

Procedure names below are the proposed stable API namespace. All input schemas are Zod v4 schemas from `src/contracts/`. Every mutation calls a service in §5.

## 8.1 Procedure map

| Procedure | Input | Output | Permission / service |
|---|---|---|---|
| `workspace.create` | `{ name, slug }` | `Workspace` | Authenticated user; creates first owner membership |
| `workspace.listMine` | `{}` | `Workspace[]` | Authenticated; membership lookup |
| `workspace.getCurrent` | `{}` | `Workspace` | Any member |
| `workspace.update` | `{ name?, slug?, staleProcessDays? }` | `Workspace` | Owner/admin; workspace service |
| `member.list` | `{}` | `WorkspaceMember[]` | Owner/admin |
| `member.invite` | `{ email, role }` | `{ invitationId, expiresAt }` | Owner/admin |
| `member.updateRole` | `{ userId, role }` | `WorkspaceMember` | Owner/admin; cannot assign owner |
| `member.remove` | `{ userId }` | `{ success: true }` | Owner/admin; cannot remove owner |
| `member.transferOwnership` | `{ newOwnerUserId }` | `WorkspaceMember[]` | Owner only |
| `member.acceptInvitation` | `{ token }` | `WorkspaceMember` | Authenticated matching email |
| `token.list` | `{ userId? }` | `ApiTokenSummary[]` | Owner/admin |
| `token.issue` | `{ userId, label, scopes, expiresAt? }` | `{ token, summary }` | Owner/admin; token shown once |
| `token.revoke` | `{ tokenId }` | `{ success: true }` | Owner/admin |
| `entity.search` | `EntityListQuery` | `Page<Entity>` | Any member; search service |
| `entity.get` | `{ id }` | `{ entity, relations:{incoming,outgoing} }` | Any member |
| `entity.create` | `CreateEntityInput` | `Entity` | Owner/admin/editor |
| `entity.update` | `UpdateEntityInput` | `Entity` | Owner/admin/editor |
| `entity.archive` | `{ id, expectedVersion }` | `Entity` | Owner/admin/editor |
| `entity.bulkTag` | `BulkTagInput` | `BulkMutationResult` | Owner/admin/editor |
| `entity.bulkArchive` | `BulkArchiveInput` | `BulkMutationResult` | Owner/admin/editor |
| `relation.create` | `CreateRelationInput` | `Relation` | Owner/admin/editor |
| `relation.update` | `UpdateRelationInput` | `Relation` | Owner/admin/editor |
| `relation.delete` | `{ id }` | `{ success:true }` | Owner/admin/editor |
| `relation.listForEntity` | `{ entityId }` | `{ incoming, outgoing }` | Any member |
| `template.list` | `{ kind? }` | `TypeTemplate[]` | Any member |
| `template.get` | `{ kind, type }` | `TypeTemplate` | Any member |
| `template.upsert` | `UpsertTemplateInput` | `TypeTemplate` | Owner/admin |
| `predicate.list` | `{}` | `PredicateDefinition[]` | Any member |
| `predicate.get` | `{ name }` | `PredicateDefinition` | Any member |
| `predicate.upsert` | `UpsertPredicateInput` | `PredicateDefinition` | Owner/admin |
| `predicate.delete` | `{ name }` | `{ success:true }` | Owner/admin; only if unused |
| `traversal.run` | `TraverseInput` | `TraversalResult` | Any member |
| `dashboard.getSummary` | `{}` | `DashboardSummary` | Any member |
| `audit.forEntity` | `{ id, limit?, cursor? }` | `Page<AuditEntry>` | Any member |
| `audit.recent` | `AuditQuery` | `Page<AuditEntry>` | Any member for workspace activity; owner/admin for broader administrative filters |
| `savedView.list` | `{ kind? }` | `SavedView[]` | Any member |
| `savedView.create` | `{ name, visibility, kind, query }` | `SavedView` | Any member; ownerUserId is set from Principal |
| `savedView.update` | `{ id, expectedVersion, ...changes }` | `SavedView` | Creator or owner/admin |
| `savedView.delete` | `{ id }` | `{ success:true }` | Creator or owner/admin |
| `import.preview` | `{ uploadId }` | `ImportPreview` | Owner/admin/editor; M4; upload bytes arrive via route |
| `import.commit` | `{ previewId }` | import counts | Owner/admin/editor; M4 |
| `export.create` | `{ kinds?, includeArchived? }` | `{ exportId, expiresAt }` | Any member; M4; download via route |

Implementation note: the exact tRPC file/router nesting may differ, but public procedure names and behavior must remain consistent. Use tRPC's native error shape mapped from `ServiceError`; do not create a second business error model.

## 8.2 UI screens and behavior

### Dashboard
- Counts per kind.
- Recent activity from audit log.
- Orphan detection count/list.
- Stale active process flags using workspace `staleProcessDays`.

### Entity lists (People / Objects / Processes)
- TanStack Table; columns derive from templates.
- Sort, full-text search, status/type/tag/attribute filters.
- Bulk tag and archive with selection count and per-item confirmation/version handling.
- All list and global search results use `searchService`.

### Entity detail
- Header: title, kind/type badge, status, edit/archive actions.
- Overview: template-driven form and Markdown notes.
- Relations: incoming/outgoing tables; predicate picker filtered to compatible kinds; counterpart entity autocomplete; relation attributes and validity display/edit.
- History: immutable audit events with human-readable before/after diffs.
- Paths: named 1–2 hop report presets from §5.6; no graph visualization.

### Admin
- Template editor with field validation and impact check against existing entities.
- Predicate registry editor with impact check against existing relations.
- Member/invitation management.
- Token issue/revoke, one-time token display, last-used display.
- Workspace settings including stale process threshold.

### Global search
- `⌘K` across all kinds; same filters and full-text service as entity lists.

### Saved views and import/export (M4)
- Save/reopen filtered list views.
- CSV package preview, row/field errors, explicit commit.
- Export current workspace data according to selected kinds/archive option.

---

# 9. MCP contract

## 9.1 Protocol and transport

**Committed:** stateless HTTP endpoint at `/api/mcp`; MCP protocol revision `2026-07-28`; `server/discover`; cacheable `tools/list`; nine tools and three resources; bearer tokens; per-token rate limit default 60 requests/minute; payload caps; no session state.

Implementation contract:
- Use the official MCP TypeScript SDK v2 modern HTTP entry point (`createMcpHandler`) rather than hand-writing JSON-RPC/header dispatch.
- Pin the SDK version that supports `2026-07-28` and lock it in the package manager.
- Use modern-only mode (`legacy: "reject"`) unless backward compatibility with 2025-era clients is explicitly approved.
- SDK handles protocol framing and validation of the `MCP-Protocol-Version`, `Mcp-Method`, and `Mcp-Name` headers against the request body. Do not duplicate that parser in the route handler.
- Modern requests are self-describing; no `initialize` handshake and no `Mcp-Session-Id` state. The request envelope is per-request `_meta`; client identity metadata is a SHOULD in the current SDK documentation, not an application authentication credential.
- Implement `server/discover` and advertise only capabilities actually implemented.
- `tools/list` and other cacheable list responses include `ttlMs` and `cacheScope`. Proposed `tools/list` cache hint: `ttlMs: 30000`, `cacheScope: "private"`. Backend services always revalidate; cached tool schemas are never authorization or data-validation boundaries.
- Apply Host/Origin validation at the HTTP edge when using a fetch-native handler. Never rely on CORS as authentication.
- Authenticate with `Authorization: Bearer <token>` on every MCP request, including list/discovery/resource requests, according to the source plan's “every request” rule.
- Do not use sticky sessions or protocol-level session storage.

## 9.2 Authentication and request flow

```text
HTTP request
  -> Host/Origin + body-size checks
  -> SDK protocol/header validation
  -> bearer token lookup + hash verification + expiry/revocation check
  -> resolve workspace member + current role + token scopes
  -> shared rate limit
  -> dispatch to core service / resource reader
  -> audit MCP request (including reads and protocol operations)
  -> SDK response
```

Invalid/missing/revoked/expired token: reject before service dispatch; write a security event without token value. No write is attempted.

## 9.3 Exactly nine tools

No additional MCP tools are in v1.

| Tool | Input contract | Output contract | Core service |
|---|---|---|---|
| `search_entities` | `EntityListQuery` | `Page<Entity>` | `SearchService.search` |
| `get_entity` | `{ id: UUID }` | `{ entity, relations:{incoming,outgoing} }` | entity + relation services |
| `create_entity` | `CreateEntityInput` | `{ entity: Entity }` | `EntityService.create` |
| `update_entity` | `UpdateEntityInput` incl. `expectedVersion` | `{ entity: Entity }` | `EntityService.update` |
| `archive_entity` | `{ id, expectedVersion }` | `{ entity: Entity }` | `EntityService.archive` |
| `create_relation` | `CreateRelationInput` | `{ relation: Relation }` | `RelationService.create` |
| `update_relation` | `UpdateRelationInput` incl. `expectedVersion` | `{ relation: Relation }` | `RelationService.update` |
| `delete_relation` | `{ id: UUID }` | `{ success: true }` | `RelationService.delete` |
| `traverse` | `TraverseInput` | `TraversalResult` | `TraversalService.traverse` |

Tool rules:
- `create_entity`/`update_entity` tool schemas may be enriched from current templates, but service-side validation remains authoritative.
- `update_entity` version conflict returns `VERSION_CONFLICT` and explicitly tells the agent to call `get_entity` again; never auto-retry or overwrite.
- `update_relation` uses `expectedVersion` (proposed consistency refinement).
- `traverse` rejects depth >3 and clamps node count to 500.
- No batch mutation tool; agent writes remain sequential through the nine tools.
- A token with `read` only cannot call mutating tools; role and token scopes are intersected.

## 9.4 Three resources

| URI | Content | Authorization/audit |
|---|---|---|
| `entitygraph://entities/{id}` | Entity plus incoming/outgoing relations, same DTO as `get_entity` | Workspace read access; audited resource read |
| `entitygraph://predicates` | Current workspace predicate registry | Workspace read access; audited resource read |
| `entitygraph://templates/{kind}/{type}` | Current template fields/version | Workspace read access; audited resource read |

## 9.5 MCP audit rule

Every authenticated MCP RPC request creates exactly one audit event, including tool calls, resource reads, `server/discover`, `tools/list`, resource listing, and other implemented protocol methods. The event records the token ID as `actorId`, its owner as `effectiveUserId`, workspace ID, action/method, tool/resource name where relevant, request ID, outcome, and before/after snapshots for successful mutations. For a successful mutating tool call, the service's mutation audit row is the one request audit event; the adapter must not add a duplicate request-only event. Read/protocol requests are audited by the adapter. A failed tool call is audited as an outcome=`failure` event after any mutation transaction rolls back. Invalid authentication attempts are recorded in `security_event_log` because no verified token actor exists.

## 9.6 MCP security/rate limits

- Default: 60 requests per token per rolling minute (source plan).
- Rate limiting must be shared across application instances; do not use process-local counters in production. PostgreSQL atomic buckets are acceptable for v1; a managed shared limiter may replace them later.
- Proposed default maximum request body: 1 MiB, environment-configurable.
- `last_used_at` is updated at most once per minute.
- No raw tokens or Authorization headers in logs/traces/errors.
- Resource and tool results are workspace-scoped and permission-checked on every request.

## 9.7 Explicit MCP non-goals

Agent proposal/approval workflows, external-party OAuth/CIMD authorization, batch-write bypass, Roots, Sampling, protocol-level Logging, Dynamic Client Registration, legacy HTTP+SSE, Tasks, and MCP Apps are deferred/out of scope for v1, consistent with the source plan.

---

# 10. Transaction, concurrency, and idempotency contracts

## 10.1 Entity transaction

In one PostgreSQL transaction:
1. Confirm the principal is still a workspace member and has permission.
2. Load/lock the relevant entity/template rows.
3. Validate input and resulting full entity state.
4. Compare `expectedVersion` when updating/archiving.
5. Insert/update entity and increment version.
6. Insert the audit event with before/after snapshots.
7. Commit.

If any step fails, neither entity nor successful-mutation audit row commits. For an authenticated MCP request that fails after token authentication, the adapter records the required `outcome: "failure"` MCP request audit event in a separate transaction after the mutation transaction has rolled back; this does not create a false successful mutation event.

## 10.2 Relation creation transaction

In one transaction:
1. Verify workspace permission.
2. Load both endpoints and predicate using workspace-qualified keys.
3. Lock predicate row for share and validate endpoint kinds.
4. Reject self-link, archived endpoints, invalid validity range, duplicate triple.
5. Insert relation and audit event.
6. Commit.

## 10.3 Relation update/delete transaction

- Update locks relation, compares `expectedVersion`, applies permitted fields, validates interval, increments version, and audits before/after atomically.
- Delete locks relation, deletes it, and audits the deleted record as `before` in the same transaction.

## 10.4 Bulk transaction

Bulk tag/archive is capped at 100 items, locks rows in deterministic ID order, validates every item, and is all-or-nothing. Each changed entity gets one audit record. No partial success response is permitted in v1.

## 10.5 Template/predicate administration transaction

Template upsert validates all current entities against the proposed field definition before activation. Predicate update validates all existing relations against the proposed allowed-kind arrays before activation. Registry changes and their audit entries commit atomically.

## 10.6 Optimistic concurrency

- Entity mutations require `expectedVersion`.
- Relation mutations require `expectedVersion` (proposed refinement).
- A mismatch returns `VERSION_CONFLICT` and leaves rows/audit unchanged.
- Saved-view update also uses a version or `updatedAt` precondition; use `version` in the Drizzle schema for consistency.
- Template and predicate updates use `expectedVersion`.

## 10.7 Idempotency

- Create operations are not inherently idempotent. The unique relation triple prevents duplicate edges; entity creation can accept an optional idempotency key through tRPC/import if retry duplication becomes a concern.
- MCP tools do not expose batch writes. A network retry after an uncertain `create_entity` outcome may create a duplicate entity; document this behavior and consider an optional idempotency key only if client retry patterns require it.
- Token revocation and relation deletion are idempotent where possible (`NOT_FOUND`/success semantics must be consistent; recommended: deletion of an already absent relation returns `NOT_FOUND`).

---

# 11. Logging, security, and operations contracts

- Application logs contain request IDs, action names, workspace IDs, durations, and outcome; never include tokens, credentials, full Authorization headers, or secret invitation URLs.
- `audit_log` is append-only; ordinary application DB roles have INSERT/SELECT only, with restricted access to snapshots.
- Security-event logs cover invalid-token attempts, rate-limit violations, suspicious cross-workspace access, and authorization failures that need operational monitoring.
- All database connections use TLS in production; managed Postgres encryption-at-rest settings must be enabled.
- Validate Host/Origin for MCP endpoint requests; apply CSRF protections to cookie-authenticated tRPC mutations.
- Use secure, HttpOnly, SameSite cookies as appropriate to better-auth's supported configuration.
- Tokens are high-entropy random secrets, hash-only at rest, workspace-bound, scope-limited, expirable, and instantly revocable.
- Backups must have a tested restore drill. The app must have a documented migration rollback/forward strategy.
- All destructive changes (member removal, token revocation, relation deletion, bulk archive) require explicit UI confirmation.
- Audit retention, privacy erasure obligations, and retention of archived entity data require a product/legal policy; the source plan does not define it. Do not silently purge audit data.

---

# 12. Error mapping

| Service error | tRPC behavior | MCP behavior |
|---|---|---|
| `VALIDATION_ERROR` | BAD_REQUEST with field details | Tool-level error with stable code/details |
| `UNAUTHENTICATED` | UNAUTHORIZED | HTTP/auth rejection according to SDK/server integration |
| `FORBIDDEN` | FORBIDDEN | Tool-level error; no data disclosure |
| `NOT_FOUND` | NOT_FOUND | Tool/resource error; do not reveal cross-workspace existence |
| `VERSION_CONFLICT` | CONFLICT | Tool error instructing caller to re-read |
| `ARCHIVED_ENTITY` | CONFLICT | Tool error; archived records are read-only |
| `TEMPLATE_NOT_FOUND` | BAD_REQUEST/NOT_FOUND | Tool error; fetch templates |
| `TEMPLATE_IN_USE` | CONFLICT | Tool error; preserve referenced template |
| `INVALID_VALIDITY_RANGE` | BAD_REQUEST | Tool error; correct validity interval |
| `LAST_OWNER` | FORBIDDEN/CONFLICT | Tool error; transfer ownership first |
| `INVITATION_EXPIRED` | BAD_REQUEST | Not exposed through MCP |
| `TOKEN_REVOKED` | UNAUTHORIZED | Authentication rejection |
| `CURSOR_INVALID` | BAD_REQUEST | Tool error; restart search without cursor |
| `INVALID_PREDICATE` | BAD_REQUEST | Tool error; fetch predicate resource |
| `RELATION_KIND_MISMATCH` | BAD_REQUEST | Tool error; choose compatible endpoints/predicate |
| `RELATION_ALREADY_EXISTS` | CONFLICT | Tool error; fetch existing edge/update it |
| `RATE_LIMITED` | TOO_MANY_REQUESTS | Protocol/HTTP rate-limit response with retry hint where supported |
| `PAYLOAD_TOO_LARGE` | PAYLOAD_TOO_LARGE | HTTP payload rejection |
| `IMPORT_VALIDATION_FAILED` | BAD_REQUEST with preview report | Not exposed through MCP |
| `INTERNAL_ERROR` | INTERNAL_SERVER_ERROR | Internal error; stable request ID, no stack trace |

MCP adapter uses SDK-supported tool result/error conventions. Do not leak the tRPC error object or internal exception into MCP content.

---

# 13. Acceptance test contract

Tests must exist at three levels: unit tests for schemas/pure logic, service integration tests against PostgreSQL, and adapter contract tests proving that tRPC and MCP call the same service behavior.

## 13.1 Database and workspace isolation

1. Entity kind/status/version CHECK constraints reject invalid values.
2. Cross-workspace relation endpoint FK is rejected.
3. Relation predicate FK must belong to the same workspace.
4. Duplicate relation triple is rejected by the unique constraint.
5. Self-link is rejected by the database.
6. Invalid validity range is rejected by the database.
7. Every repository search/list/traversal query is workspace-filtered.
8. A user cannot read/write another workspace's entity by guessing its UUID.
9. A removed workspace member's tokens are revoked in the removal transaction.

## 13.2 Entity and template

10. Valid entity create applies defaults, stores version 1, and writes audit atomically.
11. Missing `(kind,type)` template returns `TEMPLATE_NOT_FOUND`.
12. Required field missing or wrong type returns `VALIDATION_ERROR`.
13. Unknown attribute key is rejected.
14. `entity_ref` must point to an existing same-workspace entity and match configured kind.
15. Entity update with current version succeeds and increments once.
16. Stale entity version returns `VERSION_CONFLICT` and writes no mutation audit row.
17. Kind change is rejected.
18. Type change validates against the destination template.
19. Archived entity update is rejected.
20. Archive is soft, keeps relations, increments version, and is audited.
21. Archived entity cannot be restored through v1 APIs.
22. Template update that would invalidate existing entities is rejected atomically.
23. Template update requires expected version and increments template version.

## 13.3 Relations and predicates

24. Allowed predicate/kind combination creates relation successfully.
25. Disallowed endpoint kinds return `RELATION_KIND_MISMATCH`.
26. Predicate validation is transactionally protected against concurrent registry edits.
27. Relation create rejects archived endpoints.
28. Relation create rejects duplicate triple.
29. `validTo <= validFrom` fails.
30. `directed:false` creates one stored edge but traversal can follow it both ways.
31. `symmetricHelper` does not create an implicit reciprocal edge.
32. Relation update requires matching version and increments it.
33. Relation delete removes only edge and stores before snapshot in audit.
34. Predicate update that invalidates existing edges is rejected.
35. Predicate update requires expected version and increments predicate version.
36. Predicate delete while in use is rejected.

## 13.4 Authorization, members, and tokens

37. Viewer can read but cannot mutate through tRPC.
38. Read-only token cannot write even when owned by editor/admin.
39. Write token owned by viewer cannot write.
40. Token cannot access a workspace other than its bound workspace.
41. Revoked/expired token is rejected on its next request.
42. Token action records both token actor and effective user.
43. Removing a member revokes their tokens.
44. Admin cannot assign or transfer owner role.
45. Last/only workspace owner cannot be removed/demoted.
46. Ownership transfer leaves exactly one owner.
47. Invitation is single-use, email-bound, expires, and cannot be accepted by a different email.

## 13.5 Search, traversal, dashboard, and saved views

48. UI lists and global search use identical search semantics.
49. Search correctly combines kind/type/status/tag/attribute filters.
50. Search cursor cannot be reused with a different query or workspace.
51. Attribute operators reject incompatible JSON types.
52. Search excludes archived by default and includes them only when requested.
53. Traversal depth 1/2/3 returns expected entities/edges.
54. Traversal rejects depth >3 and never returns more than 500 nodes.
55. Traversal excludes archived adjacent nodes by default.
56. Orphan count matches entities with no incoming/outgoing relations.
57. Stale process threshold uses workspace setting and active status.
58. Saved view is private/shared according to visibility and still enforces caller access.

## 13.6 Bulk and import/export

59. Bulk tag supports add/remove/replace, checks every expected version, and normalizes tags.
60. Bulk archive checks every expected version.
61. Bulk operation over 100 items is rejected.
62. Bulk failure rolls back all rows and audit entries.
63. Import preview creates no domain mutations.
64. Import preview reports row/field validation failures.
65. Import commit rejects expired/foreign-user/foreign-workspace previews.
66. Import commit revalidates and is atomic.
67. Export never includes another workspace's records.
68. Export/import round trip preserves entity and relation UUIDs without silent overwrite.

## 13.7 MCP

69. MCP endpoint accepts only the pinned 2026-07-28 modern protocol when modern-only mode is configured.
70. `server/discover` advertises only implemented capabilities.
71. Exactly nine tools are discoverable; no extra tools appear.
72. Exactly three resource URI templates are registered.
73. All tools delegate to core services; no MCP-specific write path exists.
74. Every authenticated MCP RPC (tool, resource, list, discover) produces exactly one audit event.
75. Invalid-token attempts write a security event but never persist the submitted token.
76. MCP update version conflict instructs agent to re-read and does not overwrite.
77. `tools/list` cache hints include `ttlMs` and `cacheScope`; backend validation remains authoritative.
78. Rate limit is shared across application instances and enforces 60 req/min/token by default.
79. Payload cap is enforced.
80. Endpoint works behind round-robin load balancing without session affinity.
81. MCP Inspector and at least one real MCP client pass conformance tests for the pinned SDK/spec.

## 13.8 Audit and operations

82. Entity/relation mutation and audit row commit or rollback together.
83. Audit rows cannot be updated/deleted by the app role.
84. No secrets appear in application logs or error responses.
85. Backup restore drill succeeds in a clean environment.
86. Concurrent entity updates produce one winner and one `VERSION_CONFLICT`.
87. Concurrent relation updates produce one winner and one `VERSION_CONFLICT`.

---

# 14. Decision register (baseline recommendations)

These are the only material choices not explicitly resolved by the source plan. The recommended values below are the implementation baseline for this contract version. The acceptance-test numbering is sequential within §13.

| ID | Decision | Recommended v1 baseline | Status |
|---|---|---|---|
| ADR-01 | Workspace model | Explicit multi-workspace isolation; one owner per workspace; tokens bound to one workspace | Proposed default |
| ADR-02 | Role matrix | Use §6.1; owner-only ownership transfer | Proposed default |
| ADR-03 | Relation temporal model | One row per triple; validity is mutable metadata; repeated periods not modelled | Source uniqueness preserved |
| ADR-04 | `directed` / `symmetricHelper` | No reciprocal auto-write; undirected predicates traverse both ways; helper is metadata | Proposed default |
| ADR-05 | Template evolution | Versioned updates; reject changes invalidating current entities; no automatic data rewrite | Proposed default |
| ADR-06 | Relation attributes | JSON object only; no per-predicate attribute schema in v1 | Proposed default |
| ADR-07 | Search language/ranking | PostgreSQL `simple`; title > notes > attribute strings; deterministic cursor sorting | Proposed default |
| ADR-08 | Archived entity restore | No restore in v1; archive is terminal | Proposed default |
| ADR-09 | Rate/body limits | 60 req/min/token (source); 1 MiB default body cap (configurable) | Mixed |
| ADR-10 | Member invitation delivery | Use an adapter port; select concrete email provider during deployment | Decision required for deployment |
| ADR-11 | Stale process meaning | Active process with `updatedAt` older than configurable workspace threshold; default 90 days | Proposed default |
| ADR-12 | Saved-view visibility | Personal or workspace-shared; rules in §5.12 | Proposed default |
| ADR-13 | Import package format | ZIP with `entities.csv`, `relations.csv`, and `manifest.json`; dry-run + atomic commit | Proposed default |
| ADR-14 | Audit retention | Retain until an explicit privacy/legal retention policy is set; no automatic purge in v1 | Decision required before production |
| ADR-15 | MCP compatibility mode | Modern-only (`legacy: reject`) unless legacy support is explicitly requested | Proposed default |
| ADR-16 | MCP request auditing | Every authenticated RPC, including reads and discovery/list operations, one audit event | Source requirement clarified |
| ADR-17 | Initial template/predicate catalog | Workspace begins with empty registries; owner/admin creates templates and predicates during setup; examples from the plan are suggestions, not silently seeded semantics | Proposed default |

---

# 15. Implementation order and completion gates

### Gate 1 — Schema and auth foundation
- Drizzle tables, migrations, composite workspace FKs, indexes, views.
- better-auth setup and workspace membership/principal middleware.
- Token issue/verify/revoke and role/scope intersection.
- Audit infrastructure and transactional repository helpers.

**Exit condition:** workspace-isolation, role, token, entity, relation, template, predicate, and audit integration tests pass.

### Gate 2 — Core services
- Entity, relation, template, predicate, search, traversal, audit, workspace/member/token services.
- Zod v4 contract modules.
- Optimistic locking and transaction behavior.

**Exit condition:** service-level tests pass; no service imports UI/tRPC/MCP modules.

### Gate 3 — tRPC and UI
- Router contracts in §8.1.
- Dashboard, lists, detail pages, admin, global search, history, path presets.
- Bulk tag/archive.

**Exit condition:** UI workflows call only tRPC; adapter tests verify authorization and service reuse.

### Gate 4 — MCP
- Pinned official SDK, `createMcpHandler`, modern protocol, token auth, rate limiting.
- Exactly nine tools and three resources.
- Audit every authenticated RPC.

**Exit condition:** MCP Inspector + real-client protocol tests pass; endpoint works without sticky sessions.

### Gate 5 — M4 power features and production hardening
- Saved views, CSV import/export, dry-run and atomic commit.
- Backup restore drill, load/concurrency tests, audit review, security review, monitoring/alerts.

**Exit condition:** all acceptance tests in §13 pass; deployment runbook and restore procedure are reviewed.

---

# 16. Source alignment and review notes

This v0.2 specification preserves the source plan's defining decisions: one entity table; real relational FKs; PostgreSQL as source of truth; JSONB/template-driven attributes; workspace roles without per-entity ACLs; shared core services; list/detail UI rather than graph visualization; one tRPC API; one stateless MCP endpoint; exactly nine MCP tools and three resources; read/write token scopes; 60 requests/minute per token; traversal depth 3 / 500 nodes; bulk tag/archive; dashboard, paths, global search, saved views, and CSV import/export.

The following refinements were added because the source plan uses workspace terminology or describes UI features without defining the necessary contract: concrete workspace/membership tables and cross-workspace FKs; normalized API token records; member invitation/ownership rules; dashboard definitions; bulk operation atomicity; saved-view format; CSV import package/preview semantics; relation update concurrency; and explicit search/pagination semantics. They are labelled as proposed defaults above.

The prior v0.1 draft also had these issues, corrected here:
- It did not define a workspace isolation schema despite workspace-scoped roles/registries.
- It left member/token administration as UI labels rather than implementable service/procedure contracts.
- It omitted dashboard, bulk operations, saved views, and CSV import/export contracts.
- It narrowed “every MCP call = one audit entry” to mutations only; v0.2 audits authenticated read/protocol RPCs too.
- It did not define complete incoming/outgoing relation update concurrency, search operator semantics, cursor behavior, or stale-process/orphan definitions.
- It described API errors generically without separating tRPC mapping from MCP tool-result behavior.
- It did not fully specify cross-workspace composite FKs, template/predicate mutation impact checks, or token revocation behavior.

---

# 17. Official MCP references used for the protocol boundary

The MCP-specific transport rules are based on the official 2026-07-28 specification announcement and the official TypeScript SDK v2 documentation:

- Specification release: https://blog.modelcontextprotocol.io/posts/2026-07-28/
- TypeScript SDK protocol versions: https://ts.sdk.modelcontextprotocol.io/v2/protocol-versions
- SDK support/migration guide: https://ts.sdk.modelcontextprotocol.io/v2/migration/support-2026-07-28
- `createMcpHandler` API: https://ts.sdk.modelcontextprotocol.io/v2/api/%40modelcontextprotocol/server/server/createMcpHandler.html

The SDK should own protocol framing, per-request envelope handling, and header/body consistency checks. The application contract should remain at the adapter/service boundary described above.
