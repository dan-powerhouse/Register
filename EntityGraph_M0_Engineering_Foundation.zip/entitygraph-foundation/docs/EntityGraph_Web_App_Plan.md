# EntityGraph — Web App Plan

A TypeScript full-stack web app for a small team to store **People, Objects, and Processes** as entities with rich, typed relations — managed in regular list/detail views (no graph visualization) — with AI agents reading and writing the graph through an **MCP server implementing the 2026-07-28 specification**.

This version records the **committed architecture**. Choices marked ✅ are final; alternatives were evaluated and rejected for stated reasons.

---

## 1. Locked Technology Stack

| Layer | Choice | Why this and not the alternative |
|---|---|---|
| Framework | **Next.js 15+ (App Router, TypeScript)** | One deployable for UI + API + MCP endpoint; route handlers are a natural home for a stateless MCP transport |
| Database | **PostgreSQL 16** (Neon or Supabase managed) | Recursive CTEs, GIN indexes on JSONB, full-text search — a graph DB (Neo4j etc.) was rejected: our graph is shallow (mostly ≤2 hops), fully relational-FK-able, and Postgres removes an entire system to operate |
| ORM | **Drizzle ORM** | Typed SQL with first-class recursive CTE support; Prisma rejected for weak raw-SQL/CTE ergonomics |
| Validation | **Zod v4** | One schema set shared by UI forms, REST API, and MCP tools |
| Auth (humans) | **better-auth** — email magic link + Google OAuth | Small-team friendly, workspace roles built-in; Auth.js rejected: more assembly required for role scoping |
| Auth (agents) | **Per-user long-lived API tokens** (admin-issued, instantly revocable) | Token = principal with that user's role; every call audited. Full MCP OAuth/CIMD flows deferred until external-party access exists |
| UI | **Tailwind CSS + shadcn/ui**, TanStack Table, TanStack Query | Fast to build dense list/table UIs; no component library lock-in |
| Hosting | **Single container** (Fly.io or Railway) + managed Postgres | Keeps MCP + UI + jobs in one runtime; Vercel fine too, container chosen for predictable MCP streaming behavior |
| SDK pinning | MCP TypeScript SDK pinned to the **2026-07-28** revision; transport/auth isolated in `src/mcp/` so future spec bumps touch one module | 2026-07-28 has a formal 12-month deprecation lifecycle — we track the changelog and migrate deliberately |

---

## 2. Data Model — Committed

### 2.1 Decision: ONE entity table for all three kinds ✅

People, Objects, and Processes share one `entity` table. **Rejected: three separate tables.** Reasons:

- Relations constantly cross kinds ("Alice *owns* laptop-42"); one table means `relation.from_id`/`to_id` are real foreign keys with DB-enforced integrity — three tables would force polymorphic references and lose FK constraints entirely.
- Attributes are flexible and template-driven by design, so three tables would just duplicate the same JSONB + template machinery three times.
- Adding a fourth kind later ("Location", "Event") becomes an enum value, not a migration plus a new relation scheme.

Guardrails that recover what separate tables would have given us:

- `CHECK (kind IN ('person','object','process'))` constraint.
- **Partial indexes** per kind for fast list views.
- SQL **views** (`people`, `objects`, `processes`) for ergonomic per-kind queries.
- The **predicate registry** (2.3) enforces legal from-kind → to-kind pairs transactionally.

### 2.2 Tables

```
entity
├── id: UUID PK
├── kind: enum('person'|'object'|'process')   -- CHECK-constrained
├── type: text                                 -- subtype key, e.g. 'laptop', 'onboarding'
├── title: text NOT NULL
├── status: enum('active'|'inactive'|'archived')
├── attributes: JSONB NOT NULL DEFAULT '{}'    -- validated against type template
├── notes: text (markdown)
├── tags: text[] 
├── search_vector: tsvector                    -- generated from title + notes + attributes
├── created_by / updated_by: UUID FK app_user
├── created_at / updated_at: timestamptz
└── version: int                               -- optimistic locking

relation
├── id: UUID PK
├── from_id / to_id: UUID FK entity            -- real FK constraints
├── predicate: text FK → predicate_registry    -- e.g. 'owns', 'requires', 'reports_to'
├── attributes: JSONB DEFAULT '{}'             -- link properties: {since, share, role…}
├── valid_from / valid_to: timestamptz NULL    -- temporal validity
├── created_by: UUID FK app_user
└── created_at: timestamptz
    UNIQUE (from_id, predicate, to_id)         -- no duplicate edges
    CHECK (from_id <> to_id)                   -- no self-links

predicate_registry (workspace-configurable, admin-managed)
├── name: text PK                              -- 'owns', 'manages', 'part_of', 'uses',
│                                              -- 'requires', 'reports_to', 'precedes',
│                                              -- 'maintains', 'assigned_to', 'member_of'
├── from_kinds / to_kinds: kind[]              -- legality, e.g. owns: [person]→[object]
├── directed: boolean
├── symmetric_helper: text NULL                -- e.g. reports_to ⇄ has_report
└── description: text                          -- fed to MCP tool descriptions so agents
                                               -- learn the vocabulary

type_templates
├── kind + type: composite PK                  -- e.g. (object, 'laptop')
├── fields: JSONB                              -- [{name, dataType, required, options, default}]
└── updated_by, updated_at
    -- dataTypes: text | number | date | select | multiselect | entity_ref(kind?)

app_user
├── id, email, name, role: enum('owner'|'admin'|'editor'|'viewer')
├── mcp_tokens[]                               -- hashed token, label, last_used_at,
│                                              -- revoked_at; actor identity for the audit log

audit_log (append-only)
├── id, at, actor_type: enum('user'|'token'), actor_id
├── action: text                               -- 'entity.update', 'relation.create', …
├── target_table, target_id
└── before / after: JSONB diff snapshots
```

Attribute-level `NOT NULL` guarantees live in Zod + template validation at every write path (UI, REST, MCP) rather than DB columns — accepted trade-off of the single-table decision; the audit log and template validation make drift detectable and fixable.

---

## 3. Application Architecture

```
┌────────────────────────────────────────────────────┐
│                 Next.js (App Router)               │
│  Web UI (React + shadcn/ui + TanStack)             │
│  ├── List views (TanStack Table per kind)          │
│  ├── Detail views (Overview / Relations / History) │
│  └── Admin (templates, predicates, members, tokens)│
├────────────────────────────────────────────────────┤
│           Core service layer (src/services/)       │
│  entityService · relationService · searchService   │
│  authService · auditService — ALL writes funnel    │
│  through here; Zod-validated; audit-instrumented   │
├───────────────────────┬────────────────────────────┤
│   tRPC API (UI)       │  MCP server (src/mcp/)     │
│                       │  Stateless HTTP transport  │
│                       │  per spec 2026-07-28       │
└───────────────────────┴────────────────────────────┘
                          │
                   PostgreSQL 16
```

### 3.1 Permissions ✅ (final: workspace roles only)

Owner > Admin > Editor > Viewer as in §2.2. **Rejected: per-entity ACL for v1** — overkill for a small team; the service layer keeps a single choke point so row-level rules can be added later without restructuring.

---

## 4. UI — Committed Screen Set

1. **Dashboard** — recent activity feed (from audit log), counts per kind, orphan detection ("3 objects have no relations"), stale-process flags.
2. **Entity list** (×3 kinds) — TanStack Table: sortable, column set derived from the kind's type templates, full-text search, filters on status/tags/type/attributes, bulk tag & archive.
3. **Entity detail** —
   - Header: title, kind/type badge, status, edit & archive actions.
   - **Overview tab**: auto-generated form from the type template; markdown notes.
   - **Relations tab**: outgoing and incoming link tables (predicate, counterpart, link attributes, validity); "add relation" with predicate picker filtered by registry legality + entity autocomplete.
   - **History tab**: audit entries for this entity, human-readable diffs.
   - **Paths panel**: built-in 1–2 hop reports — "Processes requiring this object", "People owning objects used by this process", "Everything this person manages". This replaces graph visualization with numbers and lists.
4. **Admin** — type template editor, predicate registry editor, member management, MCP token issue/revoke (with last-used display).
5. **⌘K global search** across all kinds.

Every list and the ⌘K palette hit the same `searchService` backed by the generated `tsvector` column + GIN index on attributes.

---

## 5. MCP Server — Committed Design (spec 2026-07-28)

### 5.1 Architecture consequence of the 2026-07-28 spec ✅

The spec removed the `initialize`/`initialized` handshake and `Mcp-Session-Id` — protocol version, client info, and capabilities now ride in `_meta` on **every request**. The server therefore:

- Is a **pure request→response function**: parse → authenticate token → execute against the service layer → respond. Zero server-side protocol state.
- Runs in a standard Next.js route handler at `/api/mcp` using **Streamable HTTP**; dispatches on the `Mcp-Method` header. Horizontally scalable, no sticky sessions.
- Implements **`server/discover`** to report capabilities up front.
- Serves `tools/list` with the spec's `ttlMs` so clients cache tool definitions.
- Avoids everything deprecated in this spec: Roots, Sampling, protocol-level Logging, Dynamic Client Registration, legacy HTTP+SSE. Uses no extensions at v1 (Tasks/Apps not needed for a data toolset).

### 5.2 Tool set ✅ (final — nine tools, no more)

| Tool | Notes |
|---|---|
| `search_entities` | text/kind/type/tag/attribute filters; primary discovery tool |
| `get_entity` | entity + all relations by id |
| `create_entity` | Zod schema generated from type templates |
| `update_entity` | partial update, requires matching `version` (optimistic lock) |
| `archive_entity` | soft delete |
| `create_relation` | predicate registry-validated, transactional |
| `update_relation` | link attributes / validity |
| `delete_relation` | hard delete of an edge (entities are only archived) |
| `traverse` | from entity X, follow predicates P to depth N (hard cap 3) |

**Resources** (read-heavy access): `entitygraph://entities/{id}`, `entitygraph://predicates` (the registry — agents learn the linking vocabulary in one fetch), `entitygraph://templates/{kind}/{type}`.

### 5.3 Agent write-integrity rules ✅ (final)

- Every MCP call = one audit entry with token identity.
- Optimistic locking on `update_entity`: version mismatch → explicit error telling the agent to re-read.
- Writes to archived entities rejected; `traverse` capped at depth 3 and 500 nodes.
- Per-token rate limits (default 60 req/min) and payload caps.
- Per-user token scopes: `read`, `write` — a viewer's token can never mutate, regardless of what the agent attempts.
- Bulk work by agents goes through `create_entity`/`create_relation` calls sequentially — no batch bypass of validation.

Deferred explicitly (not forgotten, deliberately postponed): agent-proposal/approval workflow, and OAuth/CIMD authorization flows for parties outside the team. Both have clean insertion points in `src/mcp/` and the service layer.

---

## 6. Milestones

**M1 — Foundation (~1 wk):** schema + migrations + views + indexes, better-auth integration, service layer with full test coverage, audit instrumentation.

**M2 — UI (~1–2 wks):** lists, detail pages, relation editing, admin screens, ⌘K search, dashboard.

**M3 — MCP (~1 wk):** stateless transport, `server/discover`, cacheable `tools/list`, token auth + scopes, the nine tools + resources, audit wiring. Validate with MCP Inspector against the 2026-07-28 spec, then with a real client.

**M4 — Power features (~1 wk):** paths panel, saved views, CSV import/export with dry-run validation.

**M5 — Hardening:** audit viewer UX, rate-limit tuning, backups drill, load test of `/api/mcp` under concurrent agents.

Solo-build total: **~4–5 weeks** to production.

---

## 7. Standing Risks & Mitigations

- **Spec evolution:** MCP 2026-07-28 is the newest major revision. All protocol concerns live in `src/mcp/` only; SDK is pinned; monthly changelog check.
- **Agent data quality:** handled structurally — template-driven Zod schemas, predicate legality, audit trail, scoped tokens. If quality issues emerge in practice, the approval workflow is the designated remedy.
- **Feature creep toward visualization:** explicitly out of scope; the paths panel is the sanctioned answer to "show me the graph" questions.
- **Token leakage:** hashed at rest, instant revocation, last-used tracking, scope-limited. Tokens act as their user — treat issuance like password sharing in the admin UI guidance.
