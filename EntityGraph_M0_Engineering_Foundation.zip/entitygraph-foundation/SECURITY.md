# Security policy

## Supported version

Security fixes are applied to the active development branch. Until a release policy is adopted, use the latest commit on `main`.

## Reporting a vulnerability

Please do not open a public issue for an exploitable vulnerability. Use GitHub's private vulnerability reporting / security advisory feature for this repository, or contact the repository maintainers through a private channel configured by the project owner.

Include the affected component, impact, reproduction steps, and a suggested mitigation where possible. Do not include live credentials, real personal data, or production database contents in the report.

## Response expectations

The maintainers should acknowledge a report within five business days, triage severity, and coordinate a fix and disclosure timeline with the reporter. These are project targets, not a guaranteed service-level agreement.

## Secret exposure

If a credential is committed or exposed, revoke or rotate it immediately. Removing it in a later commit does not make the exposed credential safe. Review the full git history and follow the provider's incident-response process.
