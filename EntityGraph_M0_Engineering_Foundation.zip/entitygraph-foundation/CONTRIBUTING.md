# Contributing to EntityGraph

EntityGraph is contract-first. Code changes must implement the approved contracts in `docs/ENTITYGRAPH_CONTRACTS_v0.2.md` or explicitly propose an amendment before changing behavior.

## Branch and pull-request policy

- Do not commit directly to `main`.
- Create one short-lived branch per task: `feature/<slug>`, `fix/<slug>`, `test/<slug>`, `docs/<slug>`, or `chore/<slug>`.
- Open a pull request for every change, including changes authored by coding agents.
- Link the task and affected contract sections in the PR description.
- Keep PRs focused and reviewable. Separate mechanical formatting from behavior changes where practical.
- Require at least one approval from another maintainer for ordinary changes. Require a second qualified review for authentication, authorization, workspace isolation, token handling, audit semantics, and production migrations.
- A contributor must not approve their own PR. A coding agent's self-review is not an independent approval.
- Resolve review threads and rerun all relevant checks after the final code change.

## Local setup

Requirements: Node.js 22+, npm 10+, and PostgreSQL 16+ for integration tests.

```bash
npm install
# Review and commit package-lock.json. CI uses npm ci.
cp .env.example .env.local
npm run check
```

For PostgreSQL integration tests, start the isolated disposable test database:

```bash
docker compose -f compose.test.yaml up -d --wait
TEST_DATABASE_URL=postgresql://entitygraph_test:entitygraph_test_only@localhost:5433/entitygraph_test npm run test:integration
docker compose -f compose.test.yaml down -v
```

The integration test runner refuses to connect to a database whose name does not end in `_test`. Never point it at development, staging, or production data.

## Required checks

Run before requesting review:

```bash
npm run format:check
npm run lint
npm run architecture:check
npm run typecheck
npm run test:coverage
npm run security:audit
npm run build
```

For database changes, also run `npm run test:integration`. CI runs all required checks on PRs to `main`.

## Database and migration policy

- Never use `drizzle-kit push` against a shared or production database.
- Commit reviewed SQL migrations and update the Drizzle model in the same PR.
- Test migrations against the same PostgreSQL major version used in production.
- Migrations must be safe to retry only where explicitly designed to be idempotent; do not silently edit an applied migration.
- Include a forward-recovery plan for destructive or data-transforming changes.
- Preserve workspace-composite foreign keys, audit append-only behavior, and immutable entity-kind enforcement.

## Security rules

- Never commit `.env` files, credentials, API tokens, real user data, or production database dumps.
- Derive workspace, user, role, actor, and token scope from a trusted server-side Principal; never trust client-supplied authorization facts.
- UI/tRPC/MCP adapters must not access the database or repositories directly.
- All domain mutations must pass through the shared transactional service boundary and write their audit event atomically.
- Do not log raw API tokens, invitation secrets, session cookies, or authentication headers.
- Use generic not-found behavior across workspace boundaries to prevent record-existence disclosure.
- Security issues must be reported privately using the process in `SECURITY.md`.

## Tests

Every behavior change must include tests at the narrowest meaningful layer. Tests must not depend on shared developer data or order-sensitive global fixtures. Database constraints and transaction behavior require real PostgreSQL integration tests; mocks alone are insufficient.
