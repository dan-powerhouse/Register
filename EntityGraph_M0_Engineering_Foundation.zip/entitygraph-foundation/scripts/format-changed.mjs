import { execFileSync } from "node:child_process";
import { existsSync } from "node:fs";
import path from "node:path";

const supportedExtensions = new Set([
  ".cjs",
  ".css",
  ".html",
  ".js",
  ".json",
  ".md",
  ".mdx",
  ".mjs",
  ".sql",
  ".ts",
  ".tsx",
  ".yaml",
  ".yml",
]);
const mode = process.argv.includes("--write") ? "--write" : "--check";
const root = process.cwd();

function gitFiles(args) {
  return execFileSync("git", args, { cwd: root, encoding: "utf8" })
    .split(/\r?\n/)
    .map((file) => file.trim())
    .filter(Boolean);
}

function fallbackFiles() {
  return [
    ".github/dependabot.yml",
    ".github/workflows/ci.yml",
    ".github/workflows/codeql.yml",
    ".github/workflows/dependency-review.yml",
    ".github/workflows/secret-scan.yml",
    "eslint.config.mjs",
    "package.json",
    "scripts/check-architecture.ts",
    "scripts/format-changed.mjs",
    "tests/authorization.test.ts",
    "tests/integration/migration.test.ts",
    "vitest.config.ts",
    "vitest.integration.config.ts",
  ];
}

let files;
const baseSha = process.env.FORMAT_BASE_SHA;
const fullCheck = process.env.FORMAT_FULL_CHECK === "true";
try {
  if (fullCheck) {
    files = gitFiles(["ls-files"]);
    files.push(...gitFiles(["ls-files", "--others", "--exclude-standard"]));
  } else if (baseSha && !/^0+$/.test(baseSha)) {
    files = gitFiles(["diff", "--name-only", "--diff-filter=ACMR", `${baseSha}...HEAD`]);
    files.push(...gitFiles(["diff", "--name-only", "--diff-filter=ACMR", "HEAD"]));
  } else {
    files = gitFiles(["diff", "--name-only", "--diff-filter=ACMR", "HEAD"]);
    files.push(...gitFiles(["ls-files", "--others", "--exclude-standard"]));
  }
} catch {
  files = fallbackFiles();
}

const uniqueFiles = [...new Set(files)]
  .filter((file) => supportedExtensions.has(path.extname(file)))
  .filter((file) => existsSync(path.resolve(root, file)));

if (uniqueFiles.length === 0) {
  process.stdout.write("No changed supported files require formatting.\n");
  process.exit(0);
}

process.stdout.write(`Prettier ${mode === "--write" ? "writing" : "checking"} ${uniqueFiles.length} changed file(s).\n`);
execFileSync("prettier", [mode, ...uniqueFiles], { cwd: root, stdio: "inherit" });
