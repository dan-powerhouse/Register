import { readFile } from "node:fs/promises";
import { Client } from "pg";
import { loadEnvConfig } from "@next/env";

loadEnvConfig(process.cwd());

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error("DATABASE_URL is required");

const migrationName = "0001_entitygraph.sql";
const migrationUrl = new URL(`../src/db/migrations/${migrationName}`, import.meta.url);
const rawSql = await readFile(migrationUrl, "utf8");
const sql = rawSql.replace(/^\s*BEGIN;\s*/i, "").replace(/\s*COMMIT;\s*$/i, "");

const client = new Client({ connectionString: databaseUrl });
await client.connect();
try {
  await client.query(`
    CREATE TABLE IF NOT EXISTS entitygraph_migration_log (
      name text PRIMARY KEY,
      applied_at timestamptz NOT NULL DEFAULT now()
    )
  `);
  const prior = await client.query("SELECT 1 FROM entitygraph_migration_log WHERE name = $1", [migrationName]);
  if (prior.rowCount) {
    process.stdout.write(`${migrationName} is already applied.\n`);
  } else {
    await client.query("BEGIN");
    try {
      await client.query(sql);
      await client.query("INSERT INTO entitygraph_migration_log(name) VALUES ($1)", [migrationName]);
      await client.query("COMMIT");
      process.stdout.write(`Applied ${migrationName}.\n`);
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    }
  }
} finally {
  await client.end();
}
