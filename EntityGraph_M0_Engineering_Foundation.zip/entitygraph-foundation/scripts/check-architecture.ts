import { access, readdir, readFile } from "node:fs/promises";
import path from "node:path";
import ts from "typescript";

const ROOT = process.cwd();
const SRC = path.join(ROOT, "src");
const SOURCE_EXTENSIONS = new Set([".ts", ".tsx", ".js", ".jsx"]);

type Violation = { importer: string; specifier: string; rule: string };

async function walk(directory: string): Promise<string[]> {
  const entries = await readdir(directory, { withFileTypes: true });
  const nested = await Promise.all(
    entries.map(async (entry) => {
      const fullPath = path.join(directory, entry.name);
      if (entry.isDirectory()) return walk(fullPath);
      if (entry.isFile() && SOURCE_EXTENSIONS.has(path.extname(entry.name))) return [fullPath];
      return [];
    }),
  );
  return nested.flat();
}

function toSourceRelative(filePath: string): string {
  return path.relative(SRC, filePath).split(path.sep).join("/");
}

async function resolveImport(importer: string, specifier: string): Promise<string | null> {
  let candidate: string;
  if (specifier.startsWith("@/")) {
    candidate = path.join(SRC, specifier.slice(2));
  } else if (specifier.startsWith(".")) {
    candidate = path.resolve(path.dirname(importer), specifier);
  } else {
    return null;
  }

  const options = [
    candidate,
    ...[...SOURCE_EXTENSIONS].map((extension) => `${candidate}${extension}`),
    ...[...SOURCE_EXTENSIONS].map((extension) => path.join(candidate, `index${extension}`)),
  ];
  for (const option of options) {
    if (!SOURCE_EXTENSIONS.has(path.extname(option))) continue;
    try {
      await access(option);
      return option;
    } catch {
      // Continue through extension and index candidates.
    }
  }
  return null;
}

function importedModules(sourceFile: ts.SourceFile): string[] {
  const found: string[] = [];
  const visit = (node: ts.Node): void => {
    if (
      (ts.isImportDeclaration(node) || ts.isExportDeclaration(node)) &&
      node.moduleSpecifier &&
      ts.isStringLiteral(node.moduleSpecifier)
    ) {
      found.push(node.moduleSpecifier.text);
    }
    if (
      ts.isCallExpression(node) &&
      ((node.expression.kind === ts.SyntaxKind.ImportKeyword) ||
        (ts.isIdentifier(node.expression) && node.expression.text === "require")) &&
      node.arguments.length === 1 &&
      ts.isStringLiteral(node.arguments[0])
    ) {
      found.push(node.arguments[0].text);
    }
    ts.forEachChild(node, visit);
  };
  visit(sourceFile);
  return found;
}

function hasPathPrefix(file: string, prefix: string): boolean {
  return file === prefix || file.startsWith(`${prefix}/`);
}

function violationsFor(importer: string, specifier: string, resolvedTarget: string | null): string[] {
  const from = toSourceRelative(importer);
  const to = resolvedTarget ? toSourceRelative(resolvedTarget) : null;
  const rules: string[] = [];

  const isAdapter =
    hasPathPrefix(from, "app") || hasPathPrefix(from, "trpc") || hasPathPrefix(from, "mcp");
  const isFrameworkPackage = /^(next|react|react-dom|@trpc\/|@modelcontextprotocol\/|better-auth|@better-auth\/)/.test(specifier);
  const isDatabasePackage = /^(drizzle-orm(?:\/|$)|pg(?:\/|$))/.test(specifier);

  if (
    (hasPathPrefix(from, "app") && to && ["db", "repositories", "services"].some((p) => hasPathPrefix(to, p))) ||
    ((hasPathPrefix(from, "trpc") || hasPathPrefix(from, "mcp")) &&
      to &&
      ["db", "repositories"].some((p) => hasPathPrefix(to, p)))
  ) {
    rules.push("Transport/UI adapters must call core services, never repositories or the database directly.");
  }

  if (hasPathPrefix(from, "contracts") && to && !hasPathPrefix(to, "contracts")) {
    rules.push("Shared contracts must not depend on application, adapter, repository, or database modules.");
  }

  if (
    ["core", "services", "repositories"].some((p) => hasPathPrefix(from, p)) &&
    to &&
    ["app", "trpc", "mcp"].some((p) => hasPathPrefix(to, p))
  ) {
    rules.push("Core/domain layers must not depend on delivery adapters.");
  }

  if (
    (hasPathPrefix(from, "core") || hasPathPrefix(from, "services")) &&
    isFrameworkPackage
  ) {
    rules.push("Core/domain services must remain framework- and transport-independent.");
  }

  if (hasPathPrefix(from, "services") && to && hasPathPrefix(to, "db")) {
    rules.push("Services must use repository ports/implementations, not the database client or schema directly.");
  }

  if (
    hasPathPrefix(from, "repositories") &&
    to &&
    ["app", "trpc", "mcp", "services"].some((p) => hasPathPrefix(to, p))
  ) {
    rules.push("Repositories may depend on database/domain code, never on services or delivery adapters.");
  }

  if (
    (isAdapter || hasPathPrefix(from, "core") || hasPathPrefix(from, "services")) &&
    isDatabasePackage
  ) {
    rules.push("Only repository implementations may import database driver/ORM packages.");
  }

  return rules;
}

const files = await walk(SRC);
const violations: Violation[] = [];

for (const file of files) {
  const text = await readFile(file, "utf8");
  const scriptKind = file.endsWith(".tsx") ? ts.ScriptKind.TSX : ts.ScriptKind.TS;
  const source = ts.createSourceFile(file, text, ts.ScriptTarget.Latest, true, scriptKind);
  for (const specifier of importedModules(source)) {
    const resolved = await resolveImport(file, specifier);
    for (const rule of violationsFor(file, specifier, resolved)) {
      violations.push({ importer: toSourceRelative(file), specifier, rule });
    }
  }
}

if (violations.length > 0) {
  process.stderr.write("Architecture boundary violations found:\n\n");
  for (const violation of violations) {
    process.stderr.write(`- ${violation.importer} -> ${violation.specifier}\n  ${violation.rule}\n`);
  }
  process.exitCode = 1;
} else {
  process.stdout.write(`Architecture boundaries passed (${files.length} source files scanned).\n`);
}
