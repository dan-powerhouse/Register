export interface EmailDeliveryPort {
  sendMagicLink(input: { email: string; url: string; expiresAt: Date }): Promise<void>;
  sendInvitation(input: { email: string; workspaceName: string; invitationUrl: string; expiresAt: Date }): Promise<void>;
}

const unconfigured: EmailDeliveryPort = {
  async sendMagicLink() { throw new Error("EmailDeliveryPort.sendMagicLink has not been configured"); },
  async sendInvitation() { throw new Error("EmailDeliveryPort.sendInvitation has not been configured"); },
};
let activeDelivery: EmailDeliveryPort = unconfigured;

export function configureEmailDelivery(delivery: EmailDeliveryPort): void {
  activeDelivery = delivery;
}

/** Proxy keeps Better Auth configuration static while allowing runtime injection. */
export const emailDelivery: EmailDeliveryPort = {
  sendMagicLink: (input) => activeDelivery.sendMagicLink(input),
  sendInvitation: (input) => activeDelivery.sendInvitation(input),
};
