import type { Principal } from "@/auth/principal";
import type {
  ApiTokenSummary, AuditEntry, BulkArchiveInput, BulkMutationResult, BulkTagInput, DashboardSummary,
  Entity, ImportPreview, Page, PathReport, PathStep, PredicateDefinition, Relation, SavedView,
  TraversalResult, TypeTemplate, Workspace, WorkspaceMember,
} from "@/contracts/models";
import type { EntityKind, ISODateTime, JsonObject, RequestSource, TokenScope, UUID } from "@/contracts/domain";
import type { CreateEntityInput, UpdateEntityInput } from "@/contracts/entity";
import type { CreateRelationInput, UpdateRelationInput } from "@/contracts/relation";
import type { EntityListQuery } from "@/contracts/search";
import type { TraverseInput } from "@/contracts/traversal";
import type { UpsertTemplateInput } from "@/contracts/template";
import type { UpsertPredicateInput } from "@/contracts/predicate";

export interface EntityService {
  create(p: Principal, input: CreateEntityInput): Promise<Entity>;
  getById(p: Principal, id: UUID): Promise<Entity>;
  update(p: Principal, input: UpdateEntityInput): Promise<Entity>;
  archive(p: Principal, id: UUID, expectedVersion: number): Promise<Entity>;
}
export interface RelationService {
  create(p: Principal, input: CreateRelationInput): Promise<Relation>;
  update(p: Principal, input: UpdateRelationInput): Promise<Relation>;
  delete(p: Principal, id: UUID): Promise<void>;
  listForEntity(p: Principal, entityId: UUID): Promise<{ outgoing: Relation[]; incoming: Relation[] }>;
}
export interface TemplateService {
  list(p: Principal, kind?: EntityKind): Promise<TypeTemplate[]>;
  get(p: Principal, kind: EntityKind, type: string): Promise<TypeTemplate>;
  upsert(p: Principal, input: UpsertTemplateInput): Promise<TypeTemplate>;
}
export interface PredicateService {
  list(p: Principal): Promise<PredicateDefinition[]>;
  get(p: Principal, name: string): Promise<PredicateDefinition>;
  upsert(p: Principal, input: UpsertPredicateInput): Promise<PredicateDefinition>;
  delete(p: Principal, name: string): Promise<void>;
}
export interface SearchService { search(p: Principal, query: EntityListQuery): Promise<Page<Entity>>; }
export interface TraversalService { traverse(p: Principal, input: TraverseInput): Promise<TraversalResult>; }
export interface PathReportService { run(p: Principal, input: { startId: UUID; steps: PathStep[]; maxResults?: number }): Promise<PathReport[]>; }
export interface AuditQuery { targetType?: string; targetId?: UUID; actorUserId?: UUID; source?: RequestSource; actionPrefix?: string; limit?: number; cursor?: string; }
export interface AuditService {
  listForEntity(p: Principal, entityId: UUID, query?: Omit<AuditQuery, "targetId">): Promise<Page<AuditEntry>>;
  listRecent(p: Principal, query: AuditQuery): Promise<Page<AuditEntry>>;
}
export interface WorkspaceService {
  createForUser(userId: UUID, input: { name: string; slug: string }): Promise<Workspace>;
  listForUser(userId: UUID): Promise<Workspace[]>;
  get(p: Principal): Promise<Workspace>;
  update(p: Principal, input: { name?: string; slug?: string; staleProcessDays?: number }): Promise<Workspace>;
}
export interface InvitationDeliveryPort {
  sendInvitation(input: { email: string; workspaceName: string; invitationUrl: string; expiresAt: ISODateTime }): Promise<void>;
}
export interface MemberService {
  list(p: Principal): Promise<WorkspaceMember[]>;
  invite(p: Principal, input: { email: string; role: "admin" | "editor" | "viewer" }): Promise<{ invitationId: UUID; expiresAt: ISODateTime }>;
  updateRole(p: Principal, input: { userId: UUID; role: "admin" | "editor" | "viewer" }): Promise<WorkspaceMember>;
  remove(p: Principal, userId: UUID): Promise<void>;
  transferOwnership(p: Principal, newOwnerUserId: UUID): Promise<void>;
  acceptInvitation(userId: UUID, invitationToken: string): Promise<WorkspaceMember>;
}
export interface TokenService {
  list(p: Principal, userId?: UUID): Promise<ApiTokenSummary[]>;
  issue(p: Principal, input: { userId: UUID; label: string; scopes: TokenScope[]; expiresAt?: ISODateTime | null }): Promise<{ token: string; summary: ApiTokenSummary }>;
  revoke(p: Principal, tokenId: UUID): Promise<void>;
}
export interface DashboardService { getSummary(p: Principal): Promise<DashboardSummary>; }
export interface BulkEntityService {
  updateTags(p: Principal, input: BulkTagInput): Promise<BulkMutationResult>;
  archive(p: Principal, input: BulkArchiveInput): Promise<BulkMutationResult>;
}
export interface SavedViewService {
  list(p: Principal, kind?: EntityKind): Promise<SavedView[]>;
  create(p: Principal, input: { name: string; visibility: "personal" | "workspace"; kind: EntityKind | null; query: EntityListQuery }): Promise<SavedView>;
  update(p: Principal, input: { id: UUID; expectedVersion: number; name?: string; visibility?: "personal" | "workspace"; query?: EntityListQuery }): Promise<SavedView>;
  delete(p: Principal, id: UUID): Promise<void>;
}
export interface UploadService { stageImportPackage(p: Principal, file: Uint8Array): Promise<{ uploadId: UUID; sha256: string; sizeBytes: number }>; }
export interface ImportService {
  preview(p: Principal, uploadId: UUID): Promise<ImportPreview>;
  commit(p: Principal, previewId: UUID): Promise<{ entitiesCreated: number; relationsCreated: number }>;
}
export interface ExportService {
  create(p: Principal, input: { kinds?: EntityKind[]; includeArchived?: boolean }): Promise<{ exportId: UUID; expiresAt: ISODateTime }>;
  readDownload(p: Principal, exportId: UUID): Promise<Uint8Array>;
}

export interface AuditRequestInput {
  principal: Principal;
  action: string;
  outcome: "success" | "failure";
  targetType?: string | null;
  targetId?: UUID | null;
  before?: unknown;
  after?: unknown;
  metadata?: JsonObject;
}
export interface AuditWritePort {
  writeRequestEvent(input: AuditRequestInput): Promise<void>;
}
export interface McpTokenAuthenticator {
  authenticate(rawToken: string, requestId: string): Promise<Principal | null>;
}
export interface SharedRateLimiter {
  consume(tokenId: UUID, limit: number, windowSeconds: number): Promise<{ allowed: boolean; retryAfterSeconds?: number }>;
}

export interface AppServices {
  workspace: WorkspaceService;
  member: MemberService;
  token: TokenService;
  entity: EntityService;
  bulkEntity: BulkEntityService;
  relation: RelationService;
  template: TemplateService;
  predicate: PredicateService;
  search: SearchService;
  traversal: TraversalService;
  pathReports: PathReportService;
  audit: AuditService;
  dashboard: DashboardService;
  savedView: SavedViewService;
  upload: UploadService;
  import: ImportService;
  export: ExportService;
  auditWriter: AuditWritePort;
}

export interface McpDependencies {
  services: AppServices;
  authenticateToken: McpTokenAuthenticator;
  rateLimiter: SharedRateLimiter;
}

export interface SecurityEventWritePort {
  write(input: {
    requestId: string;
    eventType: string;
    outcome: "success" | "failure";
    workspaceId?: UUID | null;
    userId?: UUID | null;
    tokenId?: UUID | null;
    metadata?: JsonObject;
  }): Promise<void>;
}
