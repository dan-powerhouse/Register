export default function HomePage() {
  return (
    <main className="shell">
      <header className="brand-row">
        <div className="brand-mark" aria-hidden="true">EG</div>
        <span className="brand-name">EntityGraph</span>
        <span className="status-pill">Foundation scaffold</span>
      </header>

      <section className="hero" aria-labelledby="page-title">
        <p className="eyebrow">Knowledge, connected</p>
        <h1 id="page-title">A shared foundation for your workspace knowledge.</h1>
        <p className="intro">
          The application contracts and transport boundaries are in place. The next build increment
          implements the database-backed services and the product experience on top of them.
        </p>
      </section>

      <section className="status-grid" aria-label="Foundation status">
        <article className="status-card">
          <span className="card-label">Defined</span>
          <h2>Domain contracts</h2>
          <p>Shared Zod schemas, DTOs, validation boundaries and authorization rules.</p>
        </article>
        <article className="status-card">
          <span className="card-label">Scaffolded</span>
          <h2>Adapters</h2>
          <p>Next.js route handlers, tRPC procedure map and modern MCP tool/resource adapter.</p>
        </article>
        <article className="status-card">
          <span className="card-label">Next increment</span>
          <h2>Core services</h2>
          <p>PostgreSQL repositories, transactional writes, audit events and integration tests.</p>
        </article>
      </section>

      <footer className="footer">
        This is a developer placeholder page, not the finished EntityGraph interface.
      </footer>
    </main>
  );
}
