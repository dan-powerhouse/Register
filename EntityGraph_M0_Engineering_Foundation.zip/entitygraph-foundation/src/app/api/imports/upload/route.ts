import { requireUploadPermission } from "@/server/http";
import { errorResponse, readRequestBodyBounded, requestId, resolveUiPrincipal } from "@/server/http";

export const runtime = "nodejs";

export async function POST(request: Request): Promise<Response> {
  const id = requestId(request);
  try {
    const { runtime: app, principal } = await resolveUiPrincipal(request);
    requireUploadPermission(principal);

    const contentType = request.headers.get("content-type") ?? "";
    if (!contentType.toLowerCase().startsWith("multipart/form-data;")) {
      return Response.json({ code: "VALIDATION_ERROR", message: "Expected multipart/form-data", requestId: id }, { status: 415 });
    }

    const maxFileBytes = Number(process.env.IMPORT_MAX_BYTES ?? 20 * 1024 * 1024);
    // Multipart boundaries and headers add overhead beyond the uploaded ZIP itself.
    const maxBodyBytes = maxFileBytes + 256 * 1024;
    const bytes = await readRequestBodyBounded(request, maxBodyBytes);
    const multipartRequest = new Request(request.url, {
      method: "POST",
      headers: request.headers,
      body: bytes,
    });
    const form = await multipartRequest.formData();
    const file = form.get("file");
    if (!(file instanceof File)) {
      return Response.json({ code: "VALIDATION_ERROR", message: "A file field is required", requestId: id }, { status: 400 });
    }
    if (file.size === 0 || file.size > maxFileBytes) {
      return Response.json({ code: "PAYLOAD_TOO_LARGE", message: "File is empty or exceeds the configured size limit", requestId: id }, { status: 413 });
    }
    const result = await app.services.upload.stageImportPackage(principal, new Uint8Array(await file.arrayBuffer()));
    return Response.json(result, { status: 201, headers: { "Cache-Control": "no-store", "X-Request-Id": id } });
  } catch (error) {
    return errorResponse(error, id);
  }
}
