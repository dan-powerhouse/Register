import { uuidSchema } from "@/contracts/domain";
import { requireDownloadPermission } from "@/server/http";
import { errorResponse, requestId, resolveUiPrincipal } from "@/server/http";

export const runtime = "nodejs";

export async function GET(
  request: Request,
  context: { params: Promise<{ exportId: string }> },
): Promise<Response> {
  const id = requestId(request);
  try {
    const { exportId } = await context.params;
    const parsed = uuidSchema.safeParse(exportId);
    if (!parsed.success) return Response.json({ code: "NOT_FOUND", message: "Export not found", requestId: id }, { status: 404 });

    const { runtime: app, principal } = await resolveUiPrincipal(request);
    requireDownloadPermission(principal);
    const bytes = await app.services.export.readDownload(principal, parsed.data);
    return new Response(bytes, {
      status: 200,
      headers: {
        "Content-Type": "application/zip",
        "Content-Disposition": `attachment; filename="entitygraph-export-${parsed.data}.zip"`,
        "Content-Length": String(bytes.byteLength),
        "Cache-Control": "private, no-store",
        "X-Request-Id": id,
      },
    });
  } catch (error) {
    return errorResponse(error, id);
  }
}
