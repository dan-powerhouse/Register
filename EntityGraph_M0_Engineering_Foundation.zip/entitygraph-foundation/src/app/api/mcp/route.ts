import { createMcpRoute } from "@/mcp/route";
import { getMcpRouteDependencies } from "@/server/runtime";

export const runtime = "nodejs";

async function handle(request: Request): Promise<Response> {
  return createMcpRoute(getMcpRouteDependencies())(request);
}

export { handle as GET, handle as POST };
