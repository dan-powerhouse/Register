import { auth } from "@/auth";
import { getEntityGraphRuntime } from "@/server/runtime";
import { createTRPCRouteHandler } from "@/trpc/route-handler";

async function getIdentity(request: Request) {
  const session = await auth.api.getSession({ headers: request.headers });
  if (!session?.user) return null;
  return { userId: session.user.id, email: session.user.email };
}

async function handler(request: Request) {
  const runtime = getEntityGraphRuntime();
  const route = createTRPCRouteHandler({
    services: runtime.services,
    principalResolver: runtime.principalResolver,
    getIdentity,
  });
  return route(request);
}

export { handler as GET, handler as POST };
