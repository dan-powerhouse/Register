import type { PrincipalResolver, AuthenticatedIdentity } from "@/auth/principal";
import type { AppServices, McpTokenAuthenticator, SharedRateLimiter, SecurityEventWritePort } from "@/services/ports";
import { configureEmailDelivery, type EmailDeliveryPort } from "@/services/email";
import type { McpRouteDependencies } from "@/mcp/route";

export interface EntityGraphRuntime {
  services: AppServices;
  principalResolver: PrincipalResolver;
  getIdentity(request: Request): Promise<AuthenticatedIdentity | null>;
  mcp: {
    authenticateToken: McpTokenAuthenticator;
    rateLimiter: SharedRateLimiter;
    securityEvents: SecurityEventWritePort;
    allowedHosts: string[];
    allowedOrigins: string[];
    maxBodyBytes?: number;
    requestsPerMinute?: number;
  };
  email: EmailDeliveryPort;
}

let runtime: EntityGraphRuntime | undefined;

/** Called once from the app's server bootstrap/composition root. */
export function configureEntityGraphRuntime(value: EntityGraphRuntime): void {
  if (runtime) throw new Error("EntityGraph runtime has already been configured");
  configureEmailDelivery(value.email);
  runtime = value;
}

export function getEntityGraphRuntime(): EntityGraphRuntime {
  if (!runtime) {
    throw new Error("EntityGraph runtime is not configured. Implement Drizzle repositories/services and call configureEntityGraphRuntime() from the server composition root.");
  }
  return runtime;
}

export function getMcpRouteDependencies(): McpRouteDependencies {
  const current = getEntityGraphRuntime();
  return { services: current.services, ...current.mcp };
}
