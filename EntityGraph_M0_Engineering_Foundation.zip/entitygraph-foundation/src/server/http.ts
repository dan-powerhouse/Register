import { randomUUID } from "node:crypto";
import { auth } from "@/auth";
import { ServiceError, toSafeError } from "@/core/errors";
import { requirePrincipal, requireRead, requireWrite } from "@/core/authorization";
import { getEntityGraphRuntime } from "@/server/runtime";
import type { Principal } from "@/auth/principal";

export function requestId(request: Request): string {
  return request.headers.get("x-request-id")?.slice(0, 128) || randomUUID();
}

export async function resolveUiPrincipal(request: Request): Promise<{ runtime: ReturnType<typeof getEntityGraphRuntime>; principal: Principal; requestId: string }> {
  const current = getEntityGraphRuntime();
  const id = requestId(request);
  const session = await auth.api.getSession({ headers: request.headers });
  if (!session?.user) throw new ServiceError("UNAUTHENTICATED", "Authentication is required");
  const workspaceSlug = request.headers.get("x-entitygraph-workspace");
  if (!workspaceSlug) throw new ServiceError("VALIDATION_ERROR", "Select a workspace before continuing");
  const principal = await current.principalResolver.resolveUiPrincipal({
    userId: session.user.id,
    workspaceSlug,
    requestId: id,
    source: "ui",
  });
  requirePrincipal(principal);
  return { runtime: current, principal, requestId: id };
}

export async function readRequestBodyBounded(request: Request, maxBytes: number): Promise<Uint8Array> {
  const declaredLength = Number(request.headers.get("content-length") ?? 0);
  if (declaredLength > maxBytes) throw new ServiceError("PAYLOAD_TOO_LARGE", "Upload exceeds the configured size limit");
  if (!request.body) return new Uint8Array();
  const reader = request.body.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > maxBytes) {
        await reader.cancel();
        throw new ServiceError("PAYLOAD_TOO_LARGE", "Upload exceeds the configured size limit");
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  const body = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) { body.set(chunk, offset); offset += chunk.byteLength; }
  return body;
}

export function errorResponse(error: unknown, id: string): Response {
  const safe = toSafeError(error, id);
  const status = error instanceof ServiceError
    ? error.code === "UNAUTHENTICATED" || error.code === "TOKEN_REVOKED" ? 401
      : error.code === "FORBIDDEN" ? 403
      : error.code === "NOT_FOUND" ? 404
      : error.code === "PAYLOAD_TOO_LARGE" ? 413
      : error.code === "RATE_LIMITED" ? 429
      : error.code === "CONFLICT" || error.code === "VERSION_CONFLICT" ? 409
      : 400
    : 500;
  return Response.json(safe, { status, headers: { "Cache-Control": "no-store", "X-Request-Id": id } });
}

export function requireUploadPermission(principal: Principal): void { requireWrite(principal); }
export function requireDownloadPermission(principal: Principal): void { requireRead(principal); }
