import { Pool } from "pg";
import { drizzle } from "drizzle-orm/node-postgres";
import { user, session, account, verification } from "./auth-schema";
import * as appSchema from "./schema";

const authSchema = { user, session, account, verification };

const connectionString = process.env.DATABASE_URL;
if (!connectionString) throw new Error("DATABASE_URL is required");

export const pool = new Pool({
  connectionString,
  max: 10,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: true } : undefined,
});
export const db = drizzle(pool, { schema: { ...authSchema, ...appSchema } });
export type Database = typeof db;
