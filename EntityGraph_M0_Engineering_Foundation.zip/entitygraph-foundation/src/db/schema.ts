import { sql } from "drizzle-orm";
import {
  bigint,
  boolean,
  bytea,
  check,
  customType,
  foreignKey,
  index,
  integer,
  jsonb,
  pgEnum,
  pgTable,
  primaryKey,
  text,
  timestamp,
  uniqueIndex,
  uuid,
  varchar,
} from "drizzle-orm/pg-core";
import { user } from "./auth-schema";

const time = (name: string) => timestamp(name, { withTimezone: true, mode: "date" });
const tsvector = customType<{ data: string }>({ dataType: () => "tsvector" });

export const workspaceRoleEnum = pgEnum("workspace_role", ["owner", "admin", "editor", "viewer"]);
export const entityKindEnum = pgEnum("entity_kind", ["person", "object", "process"]);
export const entityStatusEnum = pgEnum("entity_status", ["active", "inactive", "archived"]);
export const actorTypeEnum = pgEnum("actor_type", ["user", "token", "system"]);
export const requestSourceEnum = pgEnum("request_source", ["ui", "trpc", "mcp", "import", "system"]);
export const auditOutcomeEnum = pgEnum("audit_outcome", ["success", "failure"]);
export const importStateEnum = pgEnum("import_state", ["uploaded", "previewed", "committed", "failed", "expired"]);

export const workspace = pgTable("workspace", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: varchar("name", { length: 120 }).notNull(),
  slug: varchar("slug", { length: 80 }).notNull(),
  staleProcessDays: integer("stale_process_days").notNull().default(90),
  createdAt: time("created_at").notNull().defaultNow(),
  updatedAt: time("updated_at").notNull().defaultNow(),
}, (t) => [
  uniqueIndex("workspace_slug_uq").on(t.slug),
  check("workspace_stale_process_days_positive_ck", sql`${t.staleProcessDays} > 0`),
]);

export const workspaceMember = pgTable("workspace_member", {
  workspaceId: uuid("workspace_id").notNull().references(() => workspace.id, { onDelete: "cascade" }),
  userId: uuid("user_id").notNull().references(() => user.id, { onDelete: "cascade" }),
  role: workspaceRoleEnum("role").notNull(),
  createdAt: time("created_at").notNull().defaultNow(),
  updatedAt: time("updated_at").notNull().defaultNow(),
}, (t) => [
  primaryKey({ columns: [t.workspaceId, t.userId], name: "workspace_member_pk" }),
  index("workspace_member_user_idx").on(t.userId),
  uniqueIndex("workspace_one_owner_uq").on(t.workspaceId).where(sql`${t.role} = 'owner'`),
]);

export const workspaceInvitation = pgTable("workspace_invitation", {
  id: uuid("id").primaryKey().defaultRandom(),
  workspaceId: uuid("workspace_id").notNull().references(() => workspace.id, { onDelete: "cascade" }),
  email: varchar("email", { length: 254 }).notNull(),
  role: workspaceRoleEnum("role").notNull(),
  tokenHash: text("token_hash").notNull(),
  invitedBy: uuid("invited_by").notNull().references(() => user.id, { onDelete: "restrict" }),
  expiresAt: time("expires_at").notNull(),
  acceptedAt: time("accepted_at"),
  revokedAt: time("revoked_at"),
  createdAt: time("created_at").notNull().defaultNow(),
}, (t) => [
  uniqueIndex("workspace_invitation_token_hash_uq").on(t.tokenHash),
  uniqueIndex("workspace_invitation_active_email_uq").on(t.workspaceId, sql`lower(${t.email})`).where(sql`${t.acceptedAt} IS NULL AND ${t.revokedAt} IS NULL`),
  check("workspace_invitation_no_owner_role_ck", sql`${t.role} <> 'owner'`),
]);

export const predicateRegistry = pgTable("predicate_registry", {
  workspaceId: uuid("workspace_id").notNull().references(() => workspace.id, { onDelete: "cascade" }),
  name: varchar("name", { length: 100 }).notNull(),
  fromKinds: text("from_kinds").array().notNull(),
  toKinds: text("to_kinds").array().notNull(),
  directed: boolean("directed").notNull().default(true),
  symmetricHelper: varchar("symmetric_helper", { length: 100 }),
  description: varchar("description", { length: 1000 }).notNull(),
  version: integer("version").notNull().default(1),
  createdBy: uuid("created_by").notNull().references(() => user.id, { onDelete: "restrict" }),
  updatedBy: uuid("updated_by").notNull().references(() => user.id, { onDelete: "restrict" }),
  createdAt: time("created_at").notNull().defaultNow(),
  updatedAt: time("updated_at").notNull().defaultNow(),
}, (t) => [
  primaryKey({ columns: [t.workspaceId, t.name], name: "predicate_registry_pk" }),
  uniqueIndex("predicate_registry_workspace_name_uq").on(t.workspaceId, t.name),
  check("predicate_registry_version_positive_ck", sql`${t.version} >= 1`),
  check("predicate_registry_from_kinds_nonempty_ck", sql`cardinality(${t.fromKinds}) > 0`),
  check("predicate_registry_to_kinds_nonempty_ck", sql`cardinality(${t.toKinds}) > 0`),
  check("predicate_registry_from_kinds_allowed_ck", sql`${t.fromKinds} <@ ARRAY['person','object','process']::text[]`),
  check("predicate_registry_to_kinds_allowed_ck", sql`${t.toKinds} <@ ARRAY['person','object','process']::text[]`),
]);

export const typeTemplates = pgTable("type_templates", {
  workspaceId: uuid("workspace_id").notNull().references(() => workspace.id, { onDelete: "cascade" }),
  kind: entityKindEnum("kind").notNull(),
  type: varchar("type", { length: 100 }).notNull(),
  version: integer("version").notNull().default(1),
  fields: jsonb("fields").notNull().$type<Array<Record<string, unknown>>>(),
  updatedBy: uuid("updated_by").notNull().references(() => user.id, { onDelete: "restrict" }),
  updatedAt: time("updated_at").notNull().defaultNow(),
}, (t) => [
  primaryKey({ columns: [t.workspaceId, t.kind, t.type], name: "type_templates_pk" }),
  check("type_templates_version_positive_ck", sql`${t.version} >= 1`),
  check("type_templates_fields_array_ck", sql`jsonb_typeof(${t.fields}) = 'array'`),
]);

export const entity = pgTable("entity", {
  id: uuid("id").primaryKey().defaultRandom(),
  workspaceId: uuid("workspace_id").notNull().references(() => workspace.id, { onDelete: "cascade" }),
  kind: entityKindEnum("kind").notNull(),
  type: varchar("type", { length: 100 }).notNull(),
  title: varchar("title", { length: 300 }).notNull(),
  status: entityStatusEnum("status").notNull().default("active"),
  attributes: jsonb("attributes").notNull().default({}).$type<Record<string, unknown>>(),
  notes: text("notes"),
  tags: text("tags").array().notNull().default(sql`'{}'::text[]`),
  searchVector: tsvector("search_vector").notNull().generatedAlwaysAs(sql`setweight(to_tsvector('simple'::regconfig, coalesce(${sql.raw("title")}, '')), 'A') || setweight(to_tsvector('simple'::regconfig, coalesce(${sql.raw("notes")}, '')), 'B') || setweight(jsonb_to_tsvector('simple'::regconfig, ${sql.raw("attributes")}, '["string"]'::jsonb), 'C')`),
  createdBy: uuid("created_by").notNull().references(() => user.id, { onDelete: "restrict" }),
  updatedBy: uuid("updated_by").notNull().references(() => user.id, { onDelete: "restrict" }),
  createdAt: time("created_at").notNull().defaultNow(),
  updatedAt: time("updated_at").notNull().defaultNow(),
  version: integer("version").notNull().default(1),
}, (t) => [
  uniqueIndex("entity_workspace_id_uq").on(t.workspaceId, t.id),
  foreignKey({ name: "entity_type_template_fk", columns: [t.workspaceId, t.kind, t.type], foreignColumns: [typeTemplates.workspaceId, typeTemplates.kind, typeTemplates.type] }).onDelete("restrict"),
  index("entity_workspace_kind_status_updated_idx").on(t.workspaceId, t.kind, t.status, t.updatedAt, t.id),
  index("entity_workspace_type_idx").on(t.workspaceId, t.type),
  index("entity_workspace_status_idx").on(t.workspaceId, t.status),
  index("entity_search_vector_gin_idx").using("gin", t.searchVector),
  index("entity_attributes_gin_idx").using("gin", t.attributes),
  index("entity_tags_gin_idx").using("gin", t.tags),
  index("entity_people_partial_idx").on(t.workspaceId, t.status, t.updatedAt, t.id).where(sql`${t.kind} = 'person'`),
  index("entity_objects_partial_idx").on(t.workspaceId, t.status, t.updatedAt, t.id).where(sql`${t.kind} = 'object'`),
  index("entity_processes_partial_idx").on(t.workspaceId, t.status, t.updatedAt, t.id).where(sql`${t.kind} = 'process'`),
  check("entity_attributes_object_ck", sql`jsonb_typeof(${t.attributes}) = 'object'`),
  check("entity_version_positive_ck", sql`${t.version} >= 1`),
  check("entity_title_nonempty_ck", sql`length(btrim(${t.title})) > 0`),
]);

export const relation = pgTable("relation", {
  id: uuid("id").primaryKey().defaultRandom(),
  workspaceId: uuid("workspace_id").notNull(),
  fromId: uuid("from_id").notNull(),
  toId: uuid("to_id").notNull(),
  predicate: varchar("predicate", { length: 100 }).notNull(),
  attributes: jsonb("attributes").notNull().default({}).$type<Record<string, unknown>>(),
  validFrom: time("valid_from"),
  validTo: time("valid_to"),
  createdBy: uuid("created_by").notNull().references(() => user.id, { onDelete: "restrict" }),
  updatedBy: uuid("updated_by").notNull().references(() => user.id, { onDelete: "restrict" }),
  createdAt: time("created_at").notNull().defaultNow(),
  updatedAt: time("updated_at").notNull().defaultNow(),
  version: integer("version").notNull().default(1),
}, (t) => [
  uniqueIndex("relation_workspace_id_uq").on(t.workspaceId, t.id),
  uniqueIndex("relation_unique_triple_uq").on(t.workspaceId, t.fromId, t.predicate, t.toId),
  foreignKey({ name: "relation_from_entity_fk", columns: [t.workspaceId, t.fromId], foreignColumns: [entity.workspaceId, entity.id] }).onDelete("cascade"),
  foreignKey({ name: "relation_to_entity_fk", columns: [t.workspaceId, t.toId], foreignColumns: [entity.workspaceId, entity.id] }).onDelete("cascade"),
  foreignKey({ name: "relation_predicate_fk", columns: [t.workspaceId, t.predicate], foreignColumns: [predicateRegistry.workspaceId, predicateRegistry.name] }).onDelete("restrict"),
  index("relation_workspace_from_predicate_idx").on(t.workspaceId, t.fromId, t.predicate),
  index("relation_workspace_to_predicate_idx").on(t.workspaceId, t.toId, t.predicate),
  check("relation_attributes_object_ck", sql`jsonb_typeof(${t.attributes}) = 'object'`),
  check("relation_no_self_link_ck", sql`${t.fromId} <> ${t.toId}`),
  check("relation_validity_range_ck", sql`${t.validFrom} IS NULL OR ${t.validTo} IS NULL OR ${t.validTo} > ${t.validFrom}`),
  check("relation_version_positive_ck", sql`${t.version} >= 1`),
]);

export const apiToken = pgTable("api_token", {
  id: uuid("id").primaryKey().defaultRandom(),
  workspaceId: uuid("workspace_id").notNull(),
  userId: uuid("user_id").notNull(),
  tokenHash: text("token_hash").notNull(),
  prefix: varchar("prefix", { length: 24 }).notNull(),
  label: varchar("label", { length: 100 }).notNull(),
  scopes: text("scopes").array().notNull(),
  createdBy: uuid("created_by").notNull().references(() => user.id, { onDelete: "restrict" }),
  createdAt: time("created_at").notNull().defaultNow(),
  lastUsedAt: time("last_used_at"),
  lastUsedRecordedAt: time("last_used_recorded_at"),
  expiresAt: time("expires_at"),
  revokedAt: time("revoked_at"),
}, (t) => [
  uniqueIndex("api_token_hash_uq").on(t.tokenHash),
  foreignKey({ name: "api_token_workspace_member_fk", columns: [t.workspaceId, t.userId], foreignColumns: [workspaceMember.workspaceId, workspaceMember.userId] }).onDelete("cascade"),
  index("api_token_workspace_user_idx").on(t.workspaceId, t.userId),
  index("api_token_workspace_revoked_idx").on(t.workspaceId, t.revokedAt),
  check("api_token_read_scope_ck", sql`'read' = ANY(${t.scopes})`),
  check("api_token_scopes_allowed_ck", sql`${t.scopes} <@ ARRAY['read','write']::text[]`),
]);

export const auditLog = pgTable("audit_log", {
  id: uuid("id").primaryKey().defaultRandom(),
  workspaceId: uuid("workspace_id").notNull().references(() => workspace.id, { onDelete: "cascade" }),
  at: time("at").notNull().defaultNow(),
  actorType: actorTypeEnum("actor_type").notNull(),
  actorId: uuid("actor_id"),
  effectiveUserId: uuid("effective_user_id").references(() => user.id, { onDelete: "set null" }),
  source: requestSourceEnum("source").notNull(),
  requestId: varchar("request_id", { length: 128 }).notNull(),
  action: varchar("action", { length: 160 }).notNull(),
  targetType: varchar("target_type", { length: 80 }),
  targetId: uuid("target_id"),
  outcome: auditOutcomeEnum("outcome").notNull(),
  before: jsonb("before").$type<unknown>(),
  after: jsonb("after").$type<unknown>(),
  metadata: jsonb("metadata").notNull().default({}).$type<Record<string, unknown>>(),
}, (t) => [
  index("audit_log_workspace_target_at_idx").on(t.workspaceId, t.targetType, t.targetId, t.at),
  index("audit_log_workspace_at_idx").on(t.workspaceId, t.at),
  check("audit_log_metadata_object_ck", sql`jsonb_typeof(${t.metadata}) = 'object'`),
]);

export const securityEventLog = pgTable("security_event_log", {
  id: uuid("id").primaryKey().defaultRandom(),
  at: time("at").notNull().defaultNow(),
  workspaceId: uuid("workspace_id").references(() => workspace.id, { onDelete: "set null" }),
  userId: uuid("user_id").references(() => user.id, { onDelete: "set null" }),
  tokenId: uuid("token_id").references(() => apiToken.id, { onDelete: "set null" }),
  requestId: varchar("request_id", { length: 128 }).notNull(),
  eventType: varchar("event_type", { length: 120 }).notNull(),
  outcome: auditOutcomeEnum("outcome").notNull(),
  metadata: jsonb("metadata").notNull().default({}).$type<Record<string, unknown>>(),
}, (t) => [
  index("security_event_at_idx").on(t.at),
  index("security_event_workspace_at_idx").on(t.workspaceId, t.at),
  check("security_event_metadata_object_ck", sql`jsonb_typeof(${t.metadata}) = 'object'`),
]);

export const savedView = pgTable("saved_view", {
  id: uuid("id").primaryKey().defaultRandom(),
  workspaceId: uuid("workspace_id").notNull().references(() => workspace.id, { onDelete: "cascade" }),
  ownerUserId: uuid("owner_user_id").notNull().references(() => user.id, { onDelete: "cascade" }),
  name: varchar("name", { length: 120 }).notNull(),
  visibility: varchar("visibility", { length: 16 }).notNull(),
  kind: entityKindEnum("kind"),
  query: jsonb("query").notNull().$type<Record<string, unknown>>(),
  version: integer("version").notNull().default(1),
  createdAt: time("created_at").notNull().defaultNow(),
  updatedAt: time("updated_at").notNull().defaultNow(),
}, (t) => [
  index("saved_view_workspace_owner_idx").on(t.workspaceId, t.ownerUserId),
  check("saved_view_visibility_ck", sql`${t.visibility} IN ('personal','workspace')`),
  check("saved_view_query_object_ck", sql`jsonb_typeof(${t.query}) = 'object'`),
  check("saved_view_version_positive_ck", sql`${t.version} >= 1`),
]);

export const importJob = pgTable("import_job", {
  id: uuid("id").primaryKey().defaultRandom(),
  workspaceId: uuid("workspace_id").notNull().references(() => workspace.id, { onDelete: "cascade" }),
  userId: uuid("user_id").notNull(),
  state: importStateEnum("state").notNull().default("uploaded"),
  sourceHash: varchar("source_hash", { length: 64 }).notNull(),
  packageBytes: bytea("package_bytes"),
  preview: jsonb("preview").$type<Record<string, unknown>>(),
  expiresAt: time("expires_at").notNull(),
  committedAt: time("committed_at"),
  createdAt: time("created_at").notNull().defaultNow(),
}, (t) => [
  foreignKey({ name: "import_job_workspace_member_fk", columns: [t.workspaceId, t.userId], foreignColumns: [workspaceMember.workspaceId, workspaceMember.userId] }).onDelete("cascade"),
  index("import_job_owner_state_idx").on(t.workspaceId, t.userId, t.state),
  check("import_job_preview_object_ck", sql`${t.preview} IS NULL OR jsonb_typeof(${t.preview}) = 'object'`),
]);

export const apiRateBucket = pgTable("api_rate_bucket", {
  tokenId: uuid("token_id").notNull().references(() => apiToken.id, { onDelete: "cascade" }),
  windowStart: time("window_start").notNull(),
  requestCount: integer("request_count").notNull().default(0),
}, (t) => [
  primaryKey({ columns: [t.tokenId, t.windowStart], name: "api_rate_bucket_pk" }),
  check("api_rate_bucket_count_nonnegative_ck", sql`${t.requestCount} >= 0`),
]);

// SQL migration also installs search_vector as a STORED generated column and
// creates kind-filtered views. Those SQL details are documented in migration.
