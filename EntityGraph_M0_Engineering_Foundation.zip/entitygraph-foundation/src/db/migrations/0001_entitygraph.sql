-- EntityGraph v0.2 initial application schema.
-- Precondition: Better Auth's `user` table exists and `user.id` is uuid.
-- The Better Auth package owns its user/session/account/verification migrations.
BEGIN;

CREATE TYPE workspace_role AS ENUM ('owner', 'admin', 'editor', 'viewer');
CREATE TYPE entity_kind AS ENUM ('person', 'object', 'process');
CREATE TYPE entity_status AS ENUM ('active', 'inactive', 'archived');
CREATE TYPE actor_type AS ENUM ('user', 'token', 'system');
CREATE TYPE request_source AS ENUM ('ui', 'trpc', 'mcp', 'import', 'system');
CREATE TYPE audit_outcome AS ENUM ('success', 'failure');
CREATE TYPE import_state AS ENUM ('uploaded', 'previewed', 'committed', 'failed', 'expired');

CREATE TABLE workspace (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name varchar(120) NOT NULL,
  slug varchar(80) NOT NULL UNIQUE,
  stale_process_days integer NOT NULL DEFAULT 90 CHECK (stale_process_days > 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE workspace_member (
  workspace_id uuid NOT NULL REFERENCES workspace(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES "user"(id) ON DELETE CASCADE,
  role workspace_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT workspace_member_pk PRIMARY KEY (workspace_id, user_id)
);
CREATE INDEX workspace_member_user_idx ON workspace_member(user_id);
CREATE UNIQUE INDEX workspace_one_owner_uq ON workspace_member(workspace_id) WHERE role = 'owner';

CREATE TABLE workspace_invitation (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspace(id) ON DELETE CASCADE,
  email varchar(254) NOT NULL,
  role workspace_role NOT NULL CHECK (role <> 'owner'),
  token_hash text NOT NULL UNIQUE,
  invited_by uuid NOT NULL REFERENCES "user"(id) ON DELETE RESTRICT,
  expires_at timestamptz NOT NULL,
  accepted_at timestamptz,
  revoked_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX workspace_invitation_active_email_uq
  ON workspace_invitation(workspace_id, lower(email))
  WHERE accepted_at IS NULL AND revoked_at IS NULL;

CREATE TABLE predicate_registry (
  workspace_id uuid NOT NULL REFERENCES workspace(id) ON DELETE CASCADE,
  name varchar(100) NOT NULL,
  from_kinds text[] NOT NULL CHECK (cardinality(from_kinds) > 0),
  to_kinds text[] NOT NULL CHECK (cardinality(to_kinds) > 0),
  directed boolean NOT NULL DEFAULT true,
  symmetric_helper varchar(100),
  description varchar(1000) NOT NULL,
  version integer NOT NULL DEFAULT 1 CHECK (version >= 1),
  created_by uuid NOT NULL REFERENCES "user"(id) ON DELETE RESTRICT,
  updated_by uuid NOT NULL REFERENCES "user"(id) ON DELETE RESTRICT,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT predicate_registry_pk PRIMARY KEY (workspace_id, name),
  CONSTRAINT predicate_registry_from_kinds_ck CHECK (from_kinds <@ ARRAY['person','object','process']::text[]),
  CONSTRAINT predicate_registry_to_kinds_ck CHECK (to_kinds <@ ARRAY['person','object','process']::text[])
);

CREATE TABLE type_templates (
  workspace_id uuid NOT NULL REFERENCES workspace(id) ON DELETE CASCADE,
  kind entity_kind NOT NULL,
  type varchar(100) NOT NULL,
  version integer NOT NULL DEFAULT 1 CHECK (version >= 1),
  fields jsonb NOT NULL CHECK (jsonb_typeof(fields) = 'array'),
  updated_by uuid NOT NULL REFERENCES "user"(id) ON DELETE RESTRICT,
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT type_templates_pk PRIMARY KEY (workspace_id, kind, type)
);

CREATE TABLE entity (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspace(id) ON DELETE CASCADE,
  kind entity_kind NOT NULL,
  type varchar(100) NOT NULL,
  title varchar(300) NOT NULL CHECK (length(btrim(title)) > 0),
  status entity_status NOT NULL DEFAULT 'active',
  attributes jsonb NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(attributes) = 'object'),
  notes text,
  tags text[] NOT NULL DEFAULT '{}',
  search_vector tsvector GENERATED ALWAYS AS (
    setweight(to_tsvector('simple'::regconfig, coalesce(title, '')), 'A')
    || setweight(to_tsvector('simple'::regconfig, coalesce(notes, '')), 'B')
    || setweight(jsonb_to_tsvector('simple'::regconfig, attributes, '["string"]'::jsonb), 'C')
  ) STORED,
  created_by uuid NOT NULL REFERENCES "user"(id) ON DELETE RESTRICT,
  updated_by uuid NOT NULL REFERENCES "user"(id) ON DELETE RESTRICT,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1 CHECK (version >= 1),
  CONSTRAINT entity_workspace_id_uq UNIQUE (workspace_id, id),
  CONSTRAINT entity_type_template_fk FOREIGN KEY (workspace_id, kind, type)
    REFERENCES type_templates(workspace_id, kind, type) ON DELETE RESTRICT
);
CREATE INDEX entity_workspace_kind_status_updated_idx ON entity(workspace_id, kind, status, updated_at DESC, id DESC);
CREATE INDEX entity_workspace_type_idx ON entity(workspace_id, type);
CREATE INDEX entity_workspace_status_idx ON entity(workspace_id, status);
CREATE INDEX entity_search_vector_gin_idx ON entity USING gin(search_vector);
CREATE INDEX entity_attributes_gin_idx ON entity USING gin(attributes);
CREATE INDEX entity_tags_gin_idx ON entity USING gin(tags);
CREATE INDEX entity_people_partial_idx ON entity(workspace_id, status, updated_at DESC, id DESC) WHERE kind = 'person';
CREATE INDEX entity_objects_partial_idx ON entity(workspace_id, status, updated_at DESC, id DESC) WHERE kind = 'object';
CREATE INDEX entity_processes_partial_idx ON entity(workspace_id, status, updated_at DESC, id DESC) WHERE kind = 'process';

CREATE TABLE relation (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL,
  from_id uuid NOT NULL,
  to_id uuid NOT NULL,
  predicate varchar(100) NOT NULL,
  attributes jsonb NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(attributes) = 'object'),
  valid_from timestamptz,
  valid_to timestamptz,
  created_by uuid NOT NULL REFERENCES "user"(id) ON DELETE RESTRICT,
  updated_by uuid NOT NULL REFERENCES "user"(id) ON DELETE RESTRICT,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1 CHECK (version >= 1),
  CONSTRAINT relation_workspace_id_uq UNIQUE (workspace_id, id),
  CONSTRAINT relation_unique_triple_uq UNIQUE (workspace_id, from_id, predicate, to_id),
  CONSTRAINT relation_from_entity_fk FOREIGN KEY (workspace_id, from_id)
    REFERENCES entity(workspace_id, id) ON DELETE CASCADE,
  CONSTRAINT relation_to_entity_fk FOREIGN KEY (workspace_id, to_id)
    REFERENCES entity(workspace_id, id) ON DELETE CASCADE,
  CONSTRAINT relation_predicate_fk FOREIGN KEY (workspace_id, predicate)
    REFERENCES predicate_registry(workspace_id, name) ON DELETE RESTRICT,
  CONSTRAINT relation_no_self_link_ck CHECK (from_id <> to_id),
  CONSTRAINT relation_validity_range_ck CHECK (valid_from IS NULL OR valid_to IS NULL OR valid_to > valid_from)
);
CREATE INDEX relation_workspace_from_predicate_idx ON relation(workspace_id, from_id, predicate);
CREATE INDEX relation_workspace_to_predicate_idx ON relation(workspace_id, to_id, predicate);

CREATE TABLE api_token (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL,
  user_id uuid NOT NULL,
  token_hash text NOT NULL UNIQUE,
  prefix varchar(24) NOT NULL,
  label varchar(100) NOT NULL,
  scopes text[] NOT NULL CHECK ('read' = ANY(scopes) AND scopes <@ ARRAY['read','write']::text[]),
  created_by uuid NOT NULL REFERENCES "user"(id) ON DELETE RESTRICT,
  created_at timestamptz NOT NULL DEFAULT now(),
  last_used_at timestamptz,
  last_used_recorded_at timestamptz,
  expires_at timestamptz,
  revoked_at timestamptz,
  CONSTRAINT api_token_workspace_member_fk FOREIGN KEY (workspace_id, user_id)
    REFERENCES workspace_member(workspace_id, user_id) ON DELETE CASCADE
);
CREATE INDEX api_token_workspace_user_idx ON api_token(workspace_id, user_id);
CREATE INDEX api_token_workspace_revoked_idx ON api_token(workspace_id, revoked_at);

CREATE TABLE audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspace(id) ON DELETE CASCADE,
  at timestamptz NOT NULL DEFAULT now(),
  actor_type actor_type NOT NULL,
  actor_id uuid,
  effective_user_id uuid REFERENCES "user"(id) ON DELETE SET NULL,
  source request_source NOT NULL,
  request_id varchar(128) NOT NULL,
  action varchar(160) NOT NULL,
  target_type varchar(80),
  target_id uuid,
  outcome audit_outcome NOT NULL,
  before jsonb,
  after jsonb,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(metadata) = 'object')
);
CREATE INDEX audit_log_workspace_target_at_idx ON audit_log(workspace_id, target_type, target_id, at DESC);
CREATE INDEX audit_log_workspace_at_idx ON audit_log(workspace_id, at DESC);
REVOKE UPDATE, DELETE ON audit_log FROM PUBLIC;
CREATE FUNCTION entitygraph_reject_audit_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'audit_log is append-only';
END;
$$;
CREATE TRIGGER audit_log_append_only_trg
  BEFORE UPDATE OR DELETE ON audit_log
  FOR EACH ROW EXECUTE FUNCTION entitygraph_reject_audit_mutation();

CREATE FUNCTION entitygraph_reject_entity_kind_change() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.kind IS DISTINCT FROM OLD.kind THEN
    RAISE EXCEPTION 'entity.kind is immutable';
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER entity_kind_immutable_trg
  BEFORE UPDATE ON entity
  FOR EACH ROW EXECUTE FUNCTION entitygraph_reject_entity_kind_change();

CREATE TABLE security_event_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  at timestamptz NOT NULL DEFAULT now(),
  workspace_id uuid REFERENCES workspace(id) ON DELETE SET NULL,
  user_id uuid REFERENCES "user"(id) ON DELETE SET NULL,
  token_id uuid REFERENCES api_token(id) ON DELETE SET NULL,
  request_id varchar(128) NOT NULL,
  event_type varchar(120) NOT NULL,
  outcome audit_outcome NOT NULL,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(metadata) = 'object')
);
CREATE INDEX security_event_at_idx ON security_event_log(at DESC);
CREATE INDEX security_event_workspace_at_idx ON security_event_log(workspace_id, at DESC);

CREATE TABLE saved_view (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspace(id) ON DELETE CASCADE,
  owner_user_id uuid NOT NULL REFERENCES "user"(id) ON DELETE CASCADE,
  name varchar(120) NOT NULL,
  visibility varchar(16) NOT NULL CHECK (visibility IN ('personal','workspace')),
  kind entity_kind,
  query jsonb NOT NULL CHECK (jsonb_typeof(query) = 'object'),
  version integer NOT NULL DEFAULT 1 CHECK (version >= 1),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX saved_view_workspace_owner_idx ON saved_view(workspace_id, owner_user_id);

CREATE TABLE import_job (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id uuid NOT NULL REFERENCES workspace(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  state import_state NOT NULL DEFAULT 'uploaded',
  source_hash varchar(64) NOT NULL,
  package_bytes bytea,
  preview jsonb CHECK (preview IS NULL OR jsonb_typeof(preview) = 'object'),
  expires_at timestamptz NOT NULL,
  committed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT import_job_workspace_member_fk FOREIGN KEY (workspace_id, user_id)
    REFERENCES workspace_member(workspace_id, user_id) ON DELETE CASCADE
);
CREATE INDEX import_job_owner_state_idx ON import_job(workspace_id, user_id, state);
CREATE INDEX import_job_expiry_idx ON import_job(expires_at);

CREATE TABLE api_rate_bucket (
  token_id uuid NOT NULL REFERENCES api_token(id) ON DELETE CASCADE,
  window_start timestamptz NOT NULL,
  request_count integer NOT NULL DEFAULT 0 CHECK (request_count >= 0),
  CONSTRAINT api_rate_bucket_pk PRIMARY KEY (token_id, window_start)
);

-- Compatibility views: application code still uses the shared entity service.
CREATE VIEW people AS SELECT * FROM entity WHERE kind = 'person';
CREATE VIEW objects AS SELECT * FROM entity WHERE kind = 'object';
CREATE VIEW processes AS SELECT * FROM entity WHERE kind = 'process';

COMMIT;
