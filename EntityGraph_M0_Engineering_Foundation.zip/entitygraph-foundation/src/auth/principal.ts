import type { WorkspaceRole, TokenScope, RequestSource, UUID } from "@/contracts";

export interface Principal {
  workspaceId: UUID;
  actorType: "user" | "token";
  actorId: UUID;
  userId: UUID;
  role: WorkspaceRole;
  tokenScopes?: TokenScope[];
  requestId: string;
  source: RequestSource;
  /** MCP method/tool context is copied into the single service mutation audit row. */
  auditContext?: { protocolMethod: string; name?: string; uri?: string };
}

export interface AuthenticatedIdentity {
  userId: UUID;
  email: string;
}

export interface PrincipalResolver {
  resolveUiPrincipal(input: {
    userId: UUID;
    workspaceSlug: string;
    requestId: string;
    source: "trpc" | "ui";
  }): Promise<Principal | null>;
}
