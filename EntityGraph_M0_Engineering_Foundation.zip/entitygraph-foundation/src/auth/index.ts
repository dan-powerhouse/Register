import { betterAuth } from "better-auth";
import { drizzleAdapter } from "@better-auth/drizzle-adapter";
import { magicLink } from "better-auth/plugins";
import { db } from "@/db/client";
import { user, session, account, verification } from "@/db/auth-schema";
const authSchema = { user, session, account, verification };
import { emailDelivery } from "@/services/email";

const required = (name: string): string => {
  const value = process.env[name];
  if (!value) throw new Error(`${name} is required`);
  return value;
};

const googleConfigured = Boolean(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET);

export const auth = betterAuth({
  appName: "EntityGraph",
  database: drizzleAdapter(db, { provider: "pg", schema: authSchema }),
  baseURL: required("BETTER_AUTH_URL"),
  secret: required("BETTER_AUTH_SECRET"),
  advanced: { database: { generateId: "uuid" } },
  emailAndPassword: { enabled: false },
  ...(googleConfigured ? {
    socialProviders: {
      google: {
        clientId: process.env.GOOGLE_CLIENT_ID!,
        clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
      },
    },
  } : {}),
  plugins: [
    magicLink({
      expiresIn: 300,
      async sendMagicLink({ email, url }) {
        await emailDelivery.sendMagicLink({ email, url, expiresAt: new Date(Date.now() + 300_000) });
      },
    }),
  ],
});

export type AuthSession = typeof auth.$Infer.Session;
