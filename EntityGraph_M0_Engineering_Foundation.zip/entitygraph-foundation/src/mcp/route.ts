import { randomUUID } from "node:crypto";
import { createMcpHandler } from "@modelcontextprotocol/server";
import type { McpDependencies, SecurityEventWritePort } from "@/services/ports";
import { buildMcpServer } from "./server";

export interface McpRouteDependencies extends McpDependencies {
  securityEvents: SecurityEventWritePort;
  allowedHosts: string[];
  allowedOrigins: string[];
  maxBodyBytes?: number;
  requestsPerMinute?: number;
}

export function createMcpRoute(deps: McpRouteDependencies) {
  return async function handleMcpRequest(request: Request): Promise<Response> {
    const requestId = request.headers.get("x-request-id")?.slice(0, 128) || randomUUID();

    const hostFailure = validateHostAndOrigin(request, deps.allowedHosts, deps.allowedOrigins);
    if (hostFailure) {
      await deps.securityEvents.write({ requestId, eventType: "mcp.host_or_origin_rejected", outcome: "failure" });
      return new Response(hostFailure, { status: 403 });
    }

    const bounded = await enforceBodyLimit(request, deps.maxBodyBytes ?? 1_048_576);
    if (bounded instanceof Response) {
      await deps.securityEvents.write({ requestId, eventType: "mcp.payload_too_large", outcome: "failure" });
      return bounded;
    }

    const authorization = bounded.headers.get("authorization");
    const match = authorization?.match(/^Bearer\s+(.+)$/i);
    if (!match) {
      await deps.securityEvents.write({ requestId, eventType: "mcp.authentication_failed", outcome: "failure", metadata: { reason: "missing_bearer" } });
      return new Response("Unauthorized", { status: 401 });
    }

    const principal = await deps.authenticateToken.authenticate(match[1], requestId);
    if (!principal || principal.actorType !== "token") {
      await deps.securityEvents.write({ requestId, eventType: "mcp.authentication_failed", outcome: "failure", metadata: { reason: "invalid_token" } });
      return new Response("Unauthorized", { status: 401 });
    }

    const rate = await deps.rateLimiter.consume(principal.actorId, deps.requestsPerMinute ?? 60, 60);
    if (!rate.allowed) {
      await deps.securityEvents.write({
        requestId, eventType: "mcp.rate_limited", outcome: "failure", workspaceId: principal.workspaceId,
        userId: principal.userId, tokenId: principal.actorId,
      });
      return new Response("Too Many Requests", { status: 429, headers: { "Retry-After": String(rate.retryAfterSeconds ?? 60) } });
    }

    const requestScopedPrincipal = { ...principal, requestId, source: "mcp" as const };
    const handler = createMcpHandler(
      () => buildMcpServer({ principal: requestScopedPrincipal, requestId, services: deps.services }),
      { legacy: "reject", onerror: (error) => {
        // SDK errors are intentionally not logged with request headers or token material.
        console.error("MCP SDK request failed", { requestId, errorName: error.name });
      } },
    );

    // The SDK HTTP entry handles subscriptions/listen before protocol middleware,
    // so record this one SDK-owned request at the HTTP edge instead.
    if (bounded.headers.get("mcp-method") === "subscriptions/listen") {
      try {
        const response = await handler.fetch(bounded);
        await deps.services.auditWriter.writeRequestEvent({
          principal: requestScopedPrincipal,
          action: "mcp.protocol.subscriptions/listen",
          outcome: response.ok ? "success" : "failure",
          metadata: { requestId, protocolMethod: "subscriptions/listen" },
        });
        return response;
      } catch (error) {
        await deps.services.auditWriter.writeRequestEvent({
          principal: requestScopedPrincipal,
          action: "mcp.protocol.subscriptions/listen",
          outcome: "failure",
          metadata: { requestId, protocolMethod: "subscriptions/listen", errorCode: "INTERNAL_ERROR" },
        });
        throw error;
      }
    }

    return handler.fetch(bounded);
  };
}

function validateHostAndOrigin(request: Request, allowedHosts: string[], allowedOrigins: string[]): string | null {
  const hostHeader = request.headers.get("host");
  let host = "";
  try { host = hostHeader ? new URL(`http://${hostHeader}`).hostname.toLowerCase() : ""; } catch { host = ""; }
  const hosts = new Set(allowedHosts.map((value) => value.toLowerCase().trim()).filter(Boolean));
  if (!host || !hosts.has(host)) return "Forbidden host";
  const origin = request.headers.get("origin");
  if (origin && !new Set(allowedOrigins).has(origin)) return "Forbidden origin";
  return null;
}

async function enforceBodyLimit(request: Request, maxBytes: number): Promise<Request | Response> {
  if (!request.body || ["GET", "HEAD"].includes(request.method.toUpperCase())) return request;
  const declaredLength = Number(request.headers.get("content-length") ?? 0);
  if (declaredLength > maxBytes) return new Response("Payload Too Large", { status: 413 });
  const reader = request.body.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > maxBytes) {
      await reader.cancel();
      return new Response("Payload Too Large", { status: 413 });
    }
    chunks.push(value);
  }
  const body = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) { body.set(chunk, offset); offset += chunk.byteLength; }
  return new Request(request.url, {
    method: request.method,
    headers: request.headers,
    body,
    redirect: request.redirect,
  });
}
