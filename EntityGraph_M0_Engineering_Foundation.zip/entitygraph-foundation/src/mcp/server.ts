import { McpServer, ResourceTemplate } from "@modelcontextprotocol/server";
import { z } from "zod";
import { createEntityInputSchema, entityIdInputSchema, updateEntityInputSchema } from "@/contracts/entity";
import { createRelationInputSchema, relationIdInputSchema, updateRelationInputSchema } from "@/contracts/relation";
import { entityListQuerySchema } from "@/contracts/search";
import { traverseInputSchema } from "@/contracts/traversal";
import type { Principal } from "@/auth/principal";
import type { AppServices, AuditWritePort } from "@/services/ports";
import { ServiceError, toSafeError } from "@/core/errors";

const MUTATING_TOOLS = new Set([
  "create_entity", "update_entity", "archive_entity", "create_relation", "update_relation", "delete_relation",
]);

function textResult(value: unknown) {
  return { content: [{ type: "text" as const, text: JSON.stringify(value) }] };
}

function errorResult(error: unknown, requestId: string) {
  const safe = toSafeError(error, requestId);
  return { isError: true as const, content: [{ type: "text" as const, text: JSON.stringify(safe) }] };
}

export interface McpRequestContext {
  principal: Principal;
  requestId: string;
  services: AppServices;
}

export function buildMcpServer(context: McpRequestContext) {
  const { principal: p, services, requestId } = context;
  const server = new McpServer(
    { name: "EntityGraph", version: "0.1.0", description: "Workspace-scoped entity and relationship knowledge service" },
    {
      capabilities: { tools: {}, resources: {} },
      cacheHints: { "tools/list": { ttlMs: 30_000, cacheScope: "private" } },
    },
  );

  const mutationPrincipal = (toolName: string): Principal => ({
    ...p,
    auditContext: { protocolMethod: "tools/call", name: toolName },
  });

  // Exactly nine tools — preserve this list as a v1 contract.
  server.registerTool("search_entities", {
    description: "Search entities in the authenticated workspace. Filters are combined with AND; tagsAny is OR.",
    inputSchema: entityListQuerySchema,
  }, async (input) => {
    try { return textResult(await services.search.search(p, input)); }
    catch (error) { return errorResult(error, requestId); }
  });

  server.registerTool("get_entity", {
    description: "Get one entity and its incoming/outgoing relations by entity UUID.",
    inputSchema: entityIdInputSchema,
  }, async ({ id }) => {
    try {
      const entity = await services.entity.getById(p, id);
      const relations = await services.relation.listForEntity(p, id);
      return textResult({ entity, relations });
    } catch (error) { return errorResult(error, requestId); }
  });

  server.registerTool("create_entity", {
    description: "Create a workspace entity using its registered type template.",
    inputSchema: createEntityInputSchema,
  }, async (input) => {
    try { return textResult({ entity: await services.entity.create(mutationPrincipal("create_entity"), input) }); }
    catch (error) { return errorResult(error, requestId); }
  });

  server.registerTool("update_entity", {
    description: "Patch an entity. Requires expectedVersion; on conflict re-read with get_entity and decide how to proceed.",
    inputSchema: updateEntityInputSchema,
  }, async (input) => {
    try { return textResult({ entity: await services.entity.update(mutationPrincipal("update_entity"), input) }); }
    catch (error) { return errorResult(error, requestId); }
  });

  server.registerTool("archive_entity", {
    description: "Archive an entity (terminal in v1). Requires expectedVersion.",
    inputSchema: z.object({ id: z.string().uuid(), expectedVersion: z.number().int().min(1) }).strict(),
  }, async ({ id, expectedVersion }) => {
    try { return textResult({ entity: await services.entity.archive(mutationPrincipal("archive_entity"), id, expectedVersion) }); }
    catch (error) { return errorResult(error, requestId); }
  });

  server.registerTool("create_relation", {
    description: "Create a relation between two same-workspace entities using a registered compatible predicate.",
    inputSchema: createRelationInputSchema,
  }, async (input) => {
    try { return textResult({ relation: await services.relation.create(mutationPrincipal("create_relation"), input) }); }
    catch (error) { return errorResult(error, requestId); }
  });

  server.registerTool("update_relation", {
    description: "Update relation attributes or validity. Requires expectedVersion.",
    inputSchema: updateRelationInputSchema,
  }, async (input) => {
    try { return textResult({ relation: await services.relation.update(mutationPrincipal("update_relation"), input) }); }
    catch (error) { return errorResult(error, requestId); }
  });

  server.registerTool("delete_relation", {
    description: "Delete a relation edge. This does not delete either entity.",
    inputSchema: relationIdInputSchema,
  }, async ({ id }) => {
    try { await services.relation.delete(mutationPrincipal("delete_relation"), id); return textResult({ success: true }); }
    catch (error) { return errorResult(error, requestId); }
  });

  server.registerTool("traverse", {
    description: "Traverse relations from a starting entity. Depth is limited to 3 and results to 500 nodes.",
    inputSchema: traverseInputSchema,
  }, async (input) => {
    try { return textResult(await services.traversal.traverse(p, input)); }
    catch (error) { return errorResult(error, requestId); }
  });

  // Three resources, matching the v0.2 contract.
  server.registerResource(
    "entity",
    new ResourceTemplate("entitygraph://entities/{id}", { list: undefined }),
    { title: "Entity and relations", description: "One entity with incoming and outgoing relations", mimeType: "application/json" },
    async (uri, variables) => {
      const id = String(variables.id);
      const entity = await services.entity.getById(p, id);
      const relations = await services.relation.listForEntity(p, id);
      return { contents: [{ uri: uri.href, mimeType: "application/json", text: JSON.stringify({ entity, relations }) }] };
    },
  );

  server.registerResource(
    "predicates",
    "entitygraph://predicates",
    { title: "Predicate registry", description: "Workspace relationship vocabulary and legal endpoint kinds", mimeType: "application/json" },
    async (uri) => ({
      contents: [{ uri: uri.href, mimeType: "application/json", text: JSON.stringify(await services.predicate.list(p)) }],
    }),
  );

  server.registerResource(
    "template",
    new ResourceTemplate("entitygraph://templates/{kind}/{type}", { list: undefined }),
    { title: "Type template", description: "Template definition for an entity kind and type", mimeType: "application/json" },
    async (uri, variables) => {
      const kind = String(variables.kind) as "person" | "object" | "process";
      const type = String(variables.type);
      return { contents: [{ uri: uri.href, mimeType: "application/json", text: JSON.stringify(await services.template.get(p, kind, type)) }] };
    },
  );

  installAuditAndCacheMiddleware(server, services.auditWriter, p, requestId);
  return server;
}

function installAuditAndCacheMiddleware(server: McpServer, audit: AuditWritePort, p: Principal, requestId: string) {
  // Cache hints are scoped to the authenticated caller. Tool definitions are never an authorization boundary.
  server.server.use("tools/list", async (request, ctx, next) => {
    try {
      const result = await next(request, ctx);
      await audit.writeRequestEvent({
        principal: p,
        action: "mcp.protocol.tools/list",
        outcome: "success",
        metadata: { requestId, protocolMethod: "tools/list" },
      });
      return result;
    } catch (error) {
      await auditFailure(audit, p, requestId, "mcp.protocol.tools/list", error);
      throw error;
    }
  });

  server.server.use("tools/call", async (request, ctx, next) => {
    const name = String((request.params as { name?: string } | undefined)?.name ?? "unknown");
    try {
      const result = await next(request, ctx);
      const isError = Boolean((result as { isError?: boolean }).isError);
      if (!MUTATING_TOOLS.has(name) || isError) {
        await audit.writeRequestEvent({
          principal: p,
          action: `mcp.tool.${name}`,
          outcome: isError ? "failure" : "success",
          metadata: { requestId, protocolMethod: "tools/call", toolName: name },
        });
      }
      // Successful mutating tools already write their single audit row inside the service transaction.
      return result;
    } catch (error) {
      await auditFailure(audit, p, requestId, `mcp.tool.${name}`, error, { toolName: name });
      throw error;
    }
  });

  const auditedProtocolMethods = [
    "ping",
    "resources/read",
    "resources/list",
    "resources/templates/list",
    "prompts/list",
    "prompts/get",
    "completion/complete",
    "server/discover",
  ] as const;

  for (const method of auditedProtocolMethods) {
    server.server.use(method, async (request, ctx, next) => {
      try {
        const result = await next(request, ctx);
        await audit.writeRequestEvent({
          principal: p,
          action: `mcp.protocol.${method}`,
          outcome: "success",
          metadata: {
            requestId,
            protocolMethod: method,
            ...(method === "resources/read" ? { resourceUri: (request.params as { uri?: string } | undefined)?.uri } : {}),
          },
        });
        return result;
      } catch (error) {
        await auditFailure(audit, p, requestId, `mcp.protocol.${method}`, error);
        throw error;
      }
    });
  }
}

async function auditFailure(audit: AuditWritePort, principal: Principal, requestId: string, action: string, error: unknown, extra: Record<string, unknown> = {}) {
  await audit.writeRequestEvent({
    principal,
    action,
    outcome: "failure",
    metadata: {
      requestId,
      ...extra,
      errorCode: error instanceof ServiceError ? error.code : "INTERNAL_ERROR",
    },
  });
}
