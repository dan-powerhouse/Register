import type { JsonObject } from "@/contracts";

export type ServiceErrorCode =
  | "VALIDATION_ERROR" | "UNAUTHENTICATED" | "FORBIDDEN" | "NOT_FOUND"
  | "CONFLICT" | "VERSION_CONFLICT" | "ARCHIVED_ENTITY" | "TEMPLATE_NOT_FOUND"
  | "TEMPLATE_IN_USE" | "INVALID_PREDICATE" | "RELATION_KIND_MISMATCH"
  | "RELATION_ALREADY_EXISTS" | "INVALID_VALIDITY_RANGE" | "LAST_OWNER"
  | "INVITATION_EXPIRED" | "TOKEN_REVOKED" | "RATE_LIMITED" | "PAYLOAD_TOO_LARGE"
  | "IMPORT_VALIDATION_FAILED" | "CURSOR_INVALID" | "INTERNAL_ERROR";

export class ServiceError extends Error {
  constructor(
    public readonly code: ServiceErrorCode,
    message: string,
    public readonly details?: JsonObject,
    public readonly retryable = false,
  ) {
    super(message);
    this.name = "ServiceError";
  }
}

export function toSafeError(error: unknown, requestId: string) {
  if (error instanceof ServiceError) {
    return { code: error.code, message: error.message, details: error.details, retryable: error.retryable, requestId };
  }
  return { code: "INTERNAL_ERROR" as const, message: "An unexpected error occurred", requestId };
}
