import { ServiceError } from "./errors";
import type { Principal } from "@/auth/principal";
import type { WorkspaceRole } from "@/contracts";

const roleRank: Record<WorkspaceRole, number> = { viewer: 0, editor: 1, admin: 2, owner: 3 };

export function requirePrincipal(principal: Principal | null | undefined): asserts principal is Principal {
  if (!principal) throw new ServiceError("UNAUTHENTICATED", "Authentication is required");
}

export function requireMinimumRole(principal: Principal, minimum: WorkspaceRole): void {
  if (roleRank[principal.role] < roleRank[minimum]) {
    throw new ServiceError("FORBIDDEN", `This operation requires ${minimum} role or higher`);
  }
}

export function requireRead(principal: Principal): void {
  if (principal.actorType === "token" && !principal.tokenScopes?.includes("read")) {
    throw new ServiceError("FORBIDDEN", "Token is missing read scope");
  }
}

export function requireWrite(principal: Principal): void {
  requireMinimumRole(principal, "editor");
  if (principal.actorType === "token" && !principal.tokenScopes?.includes("write")) {
    throw new ServiceError("FORBIDDEN", "Token is missing write scope");
  }
}

export function requireAdmin(principal: Principal): void {
  requireMinimumRole(principal, "admin");
  if (principal.actorType === "token" && !principal.tokenScopes?.includes("write")) {
    throw new ServiceError("FORBIDDEN", "Token is missing write scope");
  }
}

export function requireOwner(principal: Principal): void {
  if (principal.role !== "owner") throw new ServiceError("FORBIDDEN", "Only the workspace owner can perform this operation");
  if (principal.actorType === "token" && !principal.tokenScopes?.includes("write")) {
    throw new ServiceError("FORBIDDEN", "Token is missing write scope");
  }
}
