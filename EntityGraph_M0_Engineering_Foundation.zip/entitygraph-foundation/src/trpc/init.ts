import { initTRPC, TRPCError } from "@trpc/server";
import { ServiceError } from "@/core/errors";
import { requirePrincipal, requireRead, requireWrite, requireAdmin, requireOwner } from "@/core/authorization";
import type { TRPCContext } from "./context";

function toTRPCCode(code: ServiceError["code"]): ConstructorParameters<typeof TRPCError>[0]["code"] {
  switch (code) {
    case "UNAUTHENTICATED": case "TOKEN_REVOKED": return "UNAUTHORIZED";
    case "FORBIDDEN": case "LAST_OWNER": return "FORBIDDEN";
    case "NOT_FOUND": case "TEMPLATE_NOT_FOUND": return "NOT_FOUND";
    case "CONFLICT": case "VERSION_CONFLICT": case "ARCHIVED_ENTITY": case "TEMPLATE_IN_USE": case "RELATION_ALREADY_EXISTS": return "CONFLICT";
    case "RATE_LIMITED": return "TOO_MANY_REQUESTS";
    case "PAYLOAD_TOO_LARGE": return "PAYLOAD_TOO_LARGE";
    case "INTERNAL_ERROR": return "INTERNAL_SERVER_ERROR";
    default: return "BAD_REQUEST";
  }
}

const t = initTRPC.context<TRPCContext>().create({
  errorFormatter({ shape, error, ctx }) {
    const cause = error.cause;
    if (cause instanceof ServiceError) {
      return {
        ...shape,
        message: cause.message,
        data: {
          ...shape.data,
          serviceError: {
            code: cause.code,
            details: cause.details,
            retryable: cause.retryable,
            requestId: ctx?.requestId,
          },
        },
      };
    }
    return { ...shape, data: { ...shape.data, requestId: ctx?.requestId } };
  },
});

const serviceErrorMiddleware = t.middleware(async ({ next }) => {
  try {
    return await next();
  } catch (error) {
    if (error instanceof ServiceError) {
      throw new TRPCError({ code: toTRPCCode(error.code), message: error.message, cause: error });
    }
    throw error;
  }
});

export const router = t.router;
export const publicProcedure = t.procedure.use(serviceErrorMiddleware);

const hasUser = t.middleware(({ ctx, next }) => {
  if (!ctx.userId) throw new TRPCError({ code: "UNAUTHORIZED" });
  return next({ ctx: { ...ctx, userId: ctx.userId } });
});

const hasPrincipal = t.middleware(({ ctx, next }) => {
  requirePrincipal(ctx.principal);
  requireRead(ctx.principal);
  return next({ ctx: { ...ctx, principal: ctx.principal } });
});
const canWrite = t.middleware(({ ctx, next }) => {
  requirePrincipal(ctx.principal);
  requireWrite(ctx.principal);
  return next({ ctx: { ...ctx, principal: ctx.principal } });
});
const isAdmin = t.middleware(({ ctx, next }) => {
  requirePrincipal(ctx.principal);
  requireAdmin(ctx.principal);
  return next({ ctx: { ...ctx, principal: ctx.principal } });
});
const isOwner = t.middleware(({ ctx, next }) => {
  requirePrincipal(ctx.principal);
  requireOwner(ctx.principal);
  return next({ ctx: { ...ctx, principal: ctx.principal } });
});

export const authenticatedProcedure = publicProcedure.use(hasUser);
export const protectedProcedure = publicProcedure.use(hasPrincipal);
export const writeProcedure = publicProcedure.use(canWrite);
export const adminProcedure = publicProcedure.use(isAdmin);
export const ownerProcedure = publicProcedure.use(isOwner);
