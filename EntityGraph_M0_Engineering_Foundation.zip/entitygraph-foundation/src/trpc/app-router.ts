import { z } from "zod";
import { router, publicProcedure, authenticatedProcedure, protectedProcedure, writeProcedure, adminProcedure, ownerProcedure } from "./init";
import {
  archiveEntityInputSchema, bulkArchiveInputSchema, bulkTagInputSchema, createEntityInputSchema,
  entityIdInputSchema, updateEntityInputSchema,
} from "@/contracts/entity";
import { createRelationInputSchema, listRelationsInputSchema, relationIdInputSchema, updateRelationInputSchema } from "@/contracts/relation";
import { entityListQuerySchema } from "@/contracts/search";
import { templateListSchema, templateLookupSchema, upsertTemplateInputSchema } from "@/contracts/template";
import { predicateNameInputSchema, upsertPredicateInputSchema } from "@/contracts/predicate";
import { pathPatternInputSchema, traverseInputSchema } from "@/contracts/traversal";
import { auditEntityInputSchema, auditQuerySchema } from "@/contracts/audit";
import {
  acceptInvitationInputSchema, memberInviteInputSchema, memberRoleInputSchema, memberUserInputSchema,
  transferOwnershipInputSchema, workspaceCreateInputSchema, workspaceUpdateInputSchema,
} from "@/contracts/workspace";
import { tokenIssueInputSchema, tokenListInputSchema, tokenRevokeInputSchema } from "@/contracts/token";
import { entityKindSchema, uuidSchema } from "@/contracts/domain";
import type { AppServices } from "@/services/ports";
import type { TRPCContext } from "./context";
import { ServiceError } from "@/core/errors";

export function createAppRouter(_services: AppServices) {
  return router({
    workspace: router({
      create: authenticatedProcedure.input(workspaceCreateInputSchema).mutation(({ ctx, input }) => ctx.services.workspace.createForUser(ctx.userId, input)),
      listMine: authenticatedProcedure.query(({ ctx }) => ctx.services.workspace.listForUser(ctx.userId)),
      getCurrent: protectedProcedure.query(({ ctx }) => ctx.services.workspace.get(ctx.principal)),
      update: adminProcedure.input(workspaceUpdateInputSchema).mutation(({ ctx, input }) => ctx.services.workspace.update(ctx.principal, input)),
    }),
    member: router({
      list: adminProcedure.query(({ ctx }) => ctx.services.member.list(ctx.principal)),
      invite: adminProcedure.input(memberInviteInputSchema).mutation(({ ctx, input }) => ctx.services.member.invite(ctx.principal, input)),
      updateRole: adminProcedure.input(memberRoleInputSchema).mutation(({ ctx, input }) => ctx.services.member.updateRole(ctx.principal, input)),
      remove: adminProcedure.input(memberUserInputSchema).mutation(async ({ ctx, input }) => { await ctx.services.member.remove(ctx.principal, input.userId); return { success: true as const }; }),
      transferOwnership: ownerProcedure.input(transferOwnershipInputSchema).mutation(async ({ ctx, input }) => {
        await ctx.services.member.transferOwnership(ctx.principal, input.newOwnerUserId);
        return ctx.services.member.list(ctx.principal);
      }),
      acceptInvitation: authenticatedProcedure.input(acceptInvitationInputSchema).mutation(({ ctx, input }) => ctx.services.member.acceptInvitation(ctx.userId, input.token)),
    }),
    token: router({
      list: adminProcedure.input(tokenListInputSchema).query(({ ctx, input }) => ctx.services.token.list(ctx.principal, input.userId)),
      issue: adminProcedure.input(tokenIssueInputSchema).mutation(({ ctx, input }) => ctx.services.token.issue(ctx.principal, input)),
      revoke: adminProcedure.input(tokenRevokeInputSchema).mutation(async ({ ctx, input }) => { await ctx.services.token.revoke(ctx.principal, input.tokenId); return { success: true as const }; }),
    }),
    entity: router({
      search: protectedProcedure.input(entityListQuerySchema).query(({ ctx, input }) => ctx.services.search.search(ctx.principal, input)),
      get: protectedProcedure.input(entityIdInputSchema).query(async ({ ctx, input }) => ({
        entity: await ctx.services.entity.getById(ctx.principal, input.id),
        relations: await ctx.services.relation.listForEntity(ctx.principal, input.id),
      })),
      create: writeProcedure.input(createEntityInputSchema).mutation(({ ctx, input }) => ctx.services.entity.create(ctx.principal, input)),
      update: writeProcedure.input(updateEntityInputSchema).mutation(({ ctx, input }) => ctx.services.entity.update(ctx.principal, input)),
      archive: writeProcedure.input(archiveEntityInputSchema).mutation(({ ctx, input }) => ctx.services.entity.archive(ctx.principal, input.id, input.expectedVersion)),
      bulkTag: writeProcedure.input(bulkTagInputSchema).mutation(({ ctx, input }) => ctx.services.bulkEntity.updateTags(ctx.principal, input)),
      bulkArchive: writeProcedure.input(bulkArchiveInputSchema).mutation(({ ctx, input }) => ctx.services.bulkEntity.archive(ctx.principal, input)),
    }),
    relation: router({
      create: writeProcedure.input(createRelationInputSchema).mutation(({ ctx, input }) => ctx.services.relation.create(ctx.principal, input)),
      update: writeProcedure.input(updateRelationInputSchema).mutation(({ ctx, input }) => ctx.services.relation.update(ctx.principal, input)),
      delete: writeProcedure.input(relationIdInputSchema).mutation(async ({ ctx, input }) => { await ctx.services.relation.delete(ctx.principal, input.id); return { success: true as const }; }),
      listForEntity: protectedProcedure.input(listRelationsInputSchema).query(({ ctx, input }) => ctx.services.relation.listForEntity(ctx.principal, input.entityId)),
    }),
    template: router({
      list: protectedProcedure.input(templateListSchema).query(({ ctx, input }) => ctx.services.template.list(ctx.principal, input.kind)),
      get: protectedProcedure.input(templateLookupSchema).query(({ ctx, input }) => ctx.services.template.get(ctx.principal, input.kind, input.type)),
      upsert: adminProcedure.input(upsertTemplateInputSchema).mutation(({ ctx, input }) => ctx.services.template.upsert(ctx.principal, input)),
    }),
    predicate: router({
      list: protectedProcedure.query(({ ctx }) => ctx.services.predicate.list(ctx.principal)),
      get: protectedProcedure.input(predicateNameInputSchema).query(({ ctx, input }) => ctx.services.predicate.get(ctx.principal, input.name)),
      upsert: adminProcedure.input(upsertPredicateInputSchema).mutation(({ ctx, input }) => ctx.services.predicate.upsert(ctx.principal, input)),
      delete: adminProcedure.input(predicateNameInputSchema).mutation(async ({ ctx, input }) => { await ctx.services.predicate.delete(ctx.principal, input.name); return { success: true as const }; }),
    }),
    traversal: router({
      run: protectedProcedure.input(traverseInputSchema).query(({ ctx, input }) => ctx.services.traversal.traverse(ctx.principal, input)),
      pathPattern: protectedProcedure.input(pathPatternInputSchema).query(({ ctx, input }) => ctx.services.pathReports.run(ctx.principal, input)),
    }),
    dashboard: router({ getSummary: protectedProcedure.query(({ ctx }) => ctx.services.dashboard.getSummary(ctx.principal)) }),
    audit: router({
      forEntity: protectedProcedure.input(auditEntityInputSchema)
        .query(({ ctx, input }) => ctx.services.audit.listForEntity(ctx.principal, input.id, {
          source: input.source, actionPrefix: input.actionPrefix, limit: input.limit, cursor: input.cursor,
        })),
      recent: protectedProcedure.input(auditQuerySchema).query(({ ctx, input }) => {
        const hasAdministrativeFilter = Boolean(input.targetType || input.targetId || input.actorUserId || input.actionPrefix || input.source);
        if (hasAdministrativeFilter && !(["owner", "admin"].includes(ctx.principal.role))) {
          throw new ServiceError("FORBIDDEN", "Administrative audit filters require admin role");
        }
        return ctx.services.audit.listRecent(ctx.principal, input);
      }),
    }),
    savedView: router({
      list: protectedProcedure.input(z.object({ kind: entityKindSchema.optional() }).strict()).query(({ ctx, input }) => ctx.services.savedView.list(ctx.principal, input.kind)),
      create: protectedProcedure.input(z.object({
        name: z.string().trim().min(1).max(120), visibility: z.enum(["personal", "workspace"]), kind: entityKindSchema.null(), query: entityListQuerySchema,
      }).strict()).mutation(({ ctx, input }) => ctx.services.savedView.create(ctx.principal, input)),
      update: protectedProcedure.input(z.object({
        id: uuidSchema, expectedVersion: z.number().int().min(1), name: z.string().trim().min(1).max(120).optional(),
        visibility: z.enum(["personal", "workspace"]).optional(), query: entityListQuerySchema.optional(),
      }).strict()).mutation(({ ctx, input }) => ctx.services.savedView.update(ctx.principal, input)),
      delete: protectedProcedure.input(entityIdInputSchema).mutation(async ({ ctx, input }) => { await ctx.services.savedView.delete(ctx.principal, input.id); return { success: true as const }; }),
    }),
    import: router({
      preview: writeProcedure.input(z.object({ uploadId: uuidSchema }).strict()).mutation(({ ctx, input }) => ctx.services.import.preview(ctx.principal, input.uploadId)),
      commit: writeProcedure.input(z.object({ previewId: uuidSchema }).strict()).mutation(({ ctx, input }) => ctx.services.import.commit(ctx.principal, input.previewId)),
    }),
    export: router({
      create: protectedProcedure.input(z.object({ kinds: z.array(entityKindSchema).optional(), includeArchived: z.boolean().optional() }).strict())
        .mutation(({ ctx, input }) => ctx.services.export.create(ctx.principal, input)),
    }),
  });
}

export type AppRouter = ReturnType<typeof createAppRouter>;
export type AppRouterContext = TRPCContext;
