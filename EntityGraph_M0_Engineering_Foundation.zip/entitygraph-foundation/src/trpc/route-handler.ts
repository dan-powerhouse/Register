import { fetchRequestHandler } from "@trpc/server/adapters/fetch";
import { createAppRouter } from "./app-router";
import { createTRPCContext, type TRPCContextDependencies } from "./context";

export function createTRPCRouteHandler(deps: TRPCContextDependencies) {
  const appRouter = createAppRouter(deps.services);
  const createContext = createTRPCContext(deps);
  return (request: Request) => {
    const originFailure = validateBrowserMutationOrigin(request);
    if (originFailure) return Promise.resolve(originFailure);

    return fetchRequestHandler({
      endpoint: "/api/trpc",
      req: request,
      router: appRouter,
      createContext: () => createContext({ req: request }),
    });
  };
}

/** Cookie-authenticated tRPC mutations are browser-only in v1. Require and allow-list Origin. */
function validateBrowserMutationOrigin(request: Request): Response | null {
  const method = request.method.toUpperCase();
  const originHeader = request.headers.get("origin");
  if (method !== "POST" && !originHeader) return null;
  if (!originHeader || originHeader === "null") {
    return Response.json({ code: "FORBIDDEN", message: "A trusted Origin header is required" }, { status: 403 });
  }

  let origin: string;
  try {
    const parsed = new URL(originHeader);
    if (parsed.origin !== originHeader) throw new Error("Origin must not contain a path");
    origin = parsed.origin;
  } catch {
    return Response.json({ code: "FORBIDDEN", message: "Invalid Origin header" }, { status: 403 });
  }

  const configured = (process.env.APP_ALLOWED_ORIGINS ?? "")
    .split(",")
    .map((value) => value.trim())
    .filter(Boolean);
  const allowed = configured.length > 0 ? new Set(configured) : new Set([new URL(request.url).origin]);
  if (!allowed.has(origin)) {
    return Response.json({ code: "FORBIDDEN", message: "Origin is not allowed" }, { status: 403 });
  }
  return null;
}
