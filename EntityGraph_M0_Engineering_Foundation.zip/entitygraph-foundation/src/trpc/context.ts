import { randomUUID } from "node:crypto";
import type { NextRequest } from "next/server";
import type { AppServices } from "@/services/ports";
import type { AuthenticatedIdentity, Principal, PrincipalResolver } from "@/auth/principal";

export interface TRPCContext {
  user: AuthenticatedIdentity | null;
  userId: string | null;
  principal: Principal | null;
  requestId: string;
  services: AppServices;
}

export interface TRPCContextDependencies {
  services: AppServices;
  principalResolver: PrincipalResolver;
  getIdentity(request: Request | NextRequest): Promise<AuthenticatedIdentity | null>;
}

export function createTRPCContext(deps: TRPCContextDependencies) {
  return async ({ req }: { req: Request | NextRequest }): Promise<TRPCContext> => {
    const requestId = req.headers.get("x-request-id")?.slice(0, 128) || randomUUID();
    const user = await deps.getIdentity(req);
    const workspaceSlug = req.headers.get("x-entitygraph-workspace");
    const principal = user && workspaceSlug
      ? await deps.principalResolver.resolveUiPrincipal({
          userId: user.userId,
          workspaceSlug,
          requestId,
          source: "trpc",
        })
      : null;
    return { user, userId: user?.userId ?? null, principal, requestId, services: deps.services };
  };
}
