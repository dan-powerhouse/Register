import { z } from "zod";
import { entityKindSchema, isoDateTimeSchema, jsonValueSchema, uuidSchema } from "./domain";

export const templateFieldSchema = z.object({
  name: z.string().trim().regex(/^[a-z][a-z0-9_]*$/).max(80),
  dataType: z.enum(["text", "number", "date", "select", "multiselect", "entity_ref"]),
  required: z.boolean().optional().default(false),
  options: z.array(z.string().trim().min(1)).optional(),
  default: jsonValueSchema.optional(),
  entityRefKind: entityKindSchema.optional(),
}).strict().superRefine((field, ctx) => {
  if (["select", "multiselect"].includes(field.dataType)) {
    if (!field.options?.length) ctx.addIssue({ code: "custom", path: ["options"], message: "select/multiselect requires at least one option" });
    if (field.options && new Set(field.options).size !== field.options.length) ctx.addIssue({ code: "custom", path: ["options"], message: "Options must be unique" });
  } else if (field.options !== undefined) {
    ctx.addIssue({ code: "custom", path: ["options"], message: "options are only valid for select/multiselect" });
  }
  if (field.dataType !== "entity_ref" && field.entityRefKind !== undefined) {
    ctx.addIssue({ code: "custom", path: ["entityRefKind"], message: "entityRefKind is only valid for entity_ref" });
  }
});

export const typeTemplateSchema = z.object({
  workspaceId: uuidSchema,
  kind: entityKindSchema,
  type: z.string().trim().min(1).max(100),
  version: z.number().int().min(1),
  fields: z.array(templateFieldSchema),
  updatedBy: uuidSchema,
  updatedAt: isoDateTimeSchema,
}).strict().superRefine(({ fields }, ctx) => {
  const names = fields.map((f) => f.name);
  if (new Set(names).size !== names.length) ctx.addIssue({ code: "custom", path: ["fields"], message: "Template field names must be unique" });
});

export const upsertTemplateInputSchema = z.object({
  kind: entityKindSchema,
  type: z.string().trim().min(1).max(100),
  expectedVersion: z.number().int().min(1).optional(),
  fields: z.array(templateFieldSchema),
}).strict().superRefine(({ fields }, ctx) => {
  const names = fields.map((f) => f.name);
  if (new Set(names).size !== names.length) ctx.addIssue({ code: "custom", path: ["fields"], message: "Template field names must be unique" });
});

export const templateLookupSchema = z.object({ kind: entityKindSchema, type: z.string().trim().min(1) }).strict();
export const templateListSchema = z.object({ kind: entityKindSchema.optional() }).strict();
export type TemplateFieldDTO = z.infer<typeof templateFieldSchema>;
export type TypeTemplateDTO = z.infer<typeof typeTemplateSchema>;
export type UpsertTemplateInput = z.infer<typeof upsertTemplateInputSchema>;
