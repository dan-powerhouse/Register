import { z } from "zod";
import { entityKindSchema, entityStatusSchema, jsonValueSchema } from "./domain";

export const attributeFilterSchema = z.object({
  key: z.string().trim().min(1).max(128),
  operator: z.enum(["eq", "contains", "gt", "gte", "lt", "lte"]),
  value: jsonValueSchema,
}).strict();

export const entityListQuerySchema = z.object({
  q: z.string().trim().max(500).optional(),
  kind: entityKindSchema.optional(),
  type: z.string().trim().min(1).max(100).optional(),
  status: z.array(entityStatusSchema).optional(),
  tagsAny: z.array(z.string().trim().min(1).max(64)).max(100).optional(),
  attributeFilters: z.array(attributeFilterSchema).max(20).optional(),
  limit: z.number().int().min(1).max(100).optional().default(25),
  cursor: z.string().max(2048).optional(),
  sort: z.object({ field: z.enum(["title", "createdAt", "updatedAt"]), direction: z.enum(["asc", "desc"]) }).strict().optional(),
}).strict();

export type AttributeFilter = z.infer<typeof attributeFilterSchema>;
export type EntityListQuery = z.infer<typeof entityListQuerySchema>;
