import type { EntityKind, EntityStatus, WorkspaceRole, TokenScope, ActorType, RequestSource, JsonObject, JsonValue, Page, ISODateTime, UUID } from "./domain";
import type { EntityListQuery } from "./search";

export interface Workspace {
  id: UUID; name: string; slug: string; staleProcessDays: number; createdAt: ISODateTime; updatedAt: ISODateTime;
}
export interface WorkspaceMember {
  workspaceId: UUID; userId: UUID; role: WorkspaceRole; createdAt: ISODateTime; updatedAt: ISODateTime;
}
export interface Entity {
  id: UUID; workspaceId: UUID; kind: EntityKind; type: string; title: string; status: EntityStatus;
  attributes: JsonObject; notes: string | null; tags: string[]; createdBy: UUID; updatedBy: UUID;
  createdAt: ISODateTime; updatedAt: ISODateTime; version: number;
}
export interface Relation {
  id: UUID; workspaceId: UUID; fromId: UUID; toId: UUID; predicate: string; attributes: JsonObject;
  validFrom: ISODateTime | null; validTo: ISODateTime | null; createdBy: UUID; updatedBy: UUID;
  createdAt: ISODateTime; updatedAt: ISODateTime; version: number;
}
export type TemplateFieldType = "text" | "number" | "date" | "select" | "multiselect" | "entity_ref";
export interface TemplateField {
  name: string; dataType: TemplateFieldType; required?: boolean; options?: string[]; default?: JsonValue; entityRefKind?: EntityKind;
}
export interface TypeTemplate {
  workspaceId: UUID; kind: EntityKind; type: string; version: number; fields: TemplateField[]; updatedBy: UUID; updatedAt: ISODateTime;
}
export interface PredicateDefinition {
  workspaceId: UUID; name: string; fromKinds: EntityKind[]; toKinds: EntityKind[]; directed: boolean;
  symmetricHelper: string | null; description: string; version: number; createdBy: UUID; updatedBy: UUID;
  createdAt: ISODateTime; updatedAt: ISODateTime;
}
export interface ApiTokenSummary {
  id: UUID; workspaceId: UUID; userId: UUID; label: string; prefix: string; scopes: TokenScope[];
  createdBy: UUID; createdAt: ISODateTime; lastUsedAt: ISODateTime | null; expiresAt: ISODateTime | null; revokedAt: ISODateTime | null;
}
export interface AuditEntry {
  id: UUID; workspaceId: UUID; at: ISODateTime; actorType: ActorType; actorId: UUID | null; effectiveUserId: UUID | null;
  source: RequestSource; requestId: string; action: string; targetType: string | null; targetId: UUID | null;
  outcome: "success" | "failure"; before: JsonValue | null; after: JsonValue | null; metadata: JsonObject;
}
export interface SavedView {
  id: UUID; version: number; workspaceId: UUID; ownerUserId: UUID; name: string; visibility: "personal" | "workspace";
  kind: EntityKind | null; query: EntityListQuery; createdAt: ISODateTime; updatedAt: ISODateTime;
}
export interface ImportPreview {
  previewId: UUID; sourceHash: string; expiresAt: ISODateTime; entityRows: number; relationRows: number;
  validRows: number; errors: Array<{ file: string; row: number; field?: string; code: string; message: string }>;
  warnings: Array<{ file: string; row: number; message: string }>;
}
export interface DashboardSummary {
  countsByKind: Record<EntityKind, number>; recentActivity: AuditEntry[]; orphanCountsByKind: Record<EntityKind, number>;
  staleProcesses: Entity[]; staleProcessDays: number;
}
export interface TraversalResult {
  start: Entity; nodes: Array<{ entity: Entity; depth: number }>; relations: Relation[]; truncated: boolean;
}
export interface PathStep { predicate: string; direction: "outgoing" | "incoming" | "either"; }
export interface PathReport { entities: Entity[]; relations: Relation[]; }
export interface BulkMutationResult { updated: Entity[]; }
export interface BulkTagInput {
  items: Array<{ id: UUID; expectedVersion: number }>; mode: "add" | "remove" | "replace"; tags: string[];
}
export interface BulkArchiveInput { items: Array<{ id: UUID; expectedVersion: number }> }
export type { Page };
