import { z } from "zod";

export const uuidSchema = z.string().uuid();
export const isoDateTimeSchema = z.iso.datetime({ offset: true }).refine((v) => v.endsWith("Z"), "Timestamp must be UTC (Z)");
export const dateOnlySchema = z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine((v) => {
  const d = new Date(`${v}T00:00:00.000Z`);
  return !Number.isNaN(d.valueOf()) && d.toISOString().slice(0, 10) === v;
}, "Expected a real calendar date in YYYY-MM-DD form");

export const entityKindSchema = z.enum(["person", "object", "process"]);
export const entityStatusSchema = z.enum(["active", "inactive", "archived"]);
export const workspaceRoleSchema = z.enum(["owner", "admin", "editor", "viewer"]);
export const tokenScopeSchema = z.enum(["read", "write"]);
export const actorTypeSchema = z.enum(["user", "token", "system"]);
export const requestSourceSchema = z.enum(["ui", "trpc", "mcp", "import", "system"]);

export type UUID = z.infer<typeof uuidSchema>;
export type ISODateTime = z.infer<typeof isoDateTimeSchema>;
export type DateOnly = z.infer<typeof dateOnlySchema>;
export type EntityKind = z.infer<typeof entityKindSchema>;
export type EntityStatus = z.infer<typeof entityStatusSchema>;
export type WorkspaceRole = z.infer<typeof workspaceRoleSchema>;
export type TokenScope = z.infer<typeof tokenScopeSchema>;
export type ActorType = z.infer<typeof actorTypeSchema>;
export type RequestSource = z.infer<typeof requestSourceSchema>;

export type JsonPrimitive = string | number | boolean | null;
export type JsonValue = JsonPrimitive | JsonValue[] | { [key: string]: JsonValue };
export type JsonObject = Record<string, JsonValue>;

export const jsonValueSchema: z.ZodType<JsonValue> = z.lazy(() => z.union([
  z.string(),
  z.number().finite(),
  z.boolean(),
  z.null(),
  z.array(jsonValueSchema),
  z.record(z.string(), jsonValueSchema),
]));

export const jsonObjectSchema = z.record(z.string(), jsonValueSchema);

export const pageSchema = <T extends z.ZodType>(item: T) => z.object({
  items: z.array(item),
  nextCursor: z.string().nullable(),
});

export interface Page<T> {
  items: T[];
  nextCursor: string | null;
}
