import { z } from "zod";
import { uuidSchema } from "./domain";

export const traverseInputSchema = z.object({
  startId: uuidSchema,
  predicates: z.array(z.string().trim().min(1).max(100)).max(50).optional(),
  direction: z.enum(["outgoing", "incoming", "both"]).optional().default("both"),
  depth: z.union([z.literal(1), z.literal(2), z.literal(3)]),
  maxNodes: z.number().int().min(1).max(500).optional().default(500),
}).strict();

export const pathStepSchema = z.object({
  predicate: z.string().trim().min(1).max(100),
  direction: z.enum(["outgoing", "incoming", "either"]),
}).strict();

export const pathPatternInputSchema = z.object({
  startId: uuidSchema,
  steps: z.array(pathStepSchema).min(1).max(2),
  maxResults: z.number().int().min(1).max(500).optional().default(100),
}).strict();

export type TraverseInput = z.infer<typeof traverseInputSchema>;
export type PathPatternInput = z.infer<typeof pathPatternInputSchema>;
