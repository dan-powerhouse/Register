import { z } from "zod";
import { entityKindSchema, isoDateTimeSchema, uuidSchema } from "./domain";

export const predicateDefinitionSchema = z.object({
  workspaceId: uuidSchema,
  name: z.string().trim().min(1).max(100),
  fromKinds: z.array(entityKindSchema).min(1),
  toKinds: z.array(entityKindSchema).min(1),
  directed: z.boolean(),
  symmetricHelper: z.string().trim().min(1).max(100).nullable(),
  description: z.string().trim().min(1).max(1000),
  version: z.number().int().min(1),
  createdBy: uuidSchema,
  updatedBy: uuidSchema,
  createdAt: isoDateTimeSchema,
  updatedAt: isoDateTimeSchema,
}).strict();

export const upsertPredicateInputSchema = z.object({
  name: z.string().trim().min(1).max(100),
  expectedVersion: z.number().int().min(1).optional(),
  fromKinds: z.array(entityKindSchema).min(1),
  toKinds: z.array(entityKindSchema).min(1),
  directed: z.boolean(),
  symmetricHelper: z.string().trim().min(1).max(100).nullable().optional(),
  description: z.string().trim().min(1).max(1000),
}).strict().superRefine((v, ctx) => {
  if (new Set(v.fromKinds).size !== v.fromKinds.length) ctx.addIssue({ code: "custom", path: ["fromKinds"], message: "Duplicate kinds are not allowed" });
  if (new Set(v.toKinds).size !== v.toKinds.length) ctx.addIssue({ code: "custom", path: ["toKinds"], message: "Duplicate kinds are not allowed" });
});
export const predicateNameInputSchema = z.object({ name: z.string().trim().min(1).max(100) }).strict();
export type PredicateDefinitionDTO = z.infer<typeof predicateDefinitionSchema>;
export type UpsertPredicateInput = z.infer<typeof upsertPredicateInputSchema>;
