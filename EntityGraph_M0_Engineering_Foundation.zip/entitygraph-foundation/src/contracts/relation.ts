import { z } from "zod";
import { isoDateTimeSchema, jsonObjectSchema, uuidSchema } from "./domain";

const validityShape = {
  validFrom: isoDateTimeSchema.nullable().optional(),
  validTo: isoDateTimeSchema.nullable().optional(),
};

function validateValidity(
  value: { validFrom?: string | null; validTo?: string | null },
  ctx: z.RefinementCtx,
) {
  if (value.validFrom && value.validTo && Date.parse(value.validTo) <= Date.parse(value.validFrom)) {
    ctx.addIssue({ code: "custom", path: ["validTo"], message: "validTo must be later than validFrom" });
  }
}

export const relationSchema = z.object({
  id: uuidSchema,
  workspaceId: uuidSchema,
  fromId: uuidSchema,
  toId: uuidSchema,
  predicate: z.string().trim().min(1).max(100),
  attributes: jsonObjectSchema,
  validFrom: isoDateTimeSchema.nullable(),
  validTo: isoDateTimeSchema.nullable(),
  createdBy: uuidSchema,
  updatedBy: uuidSchema,
  createdAt: isoDateTimeSchema,
  updatedAt: isoDateTimeSchema,
  version: z.number().int().min(1),
}).strict();

export const createRelationInputSchema = z.object({
  fromId: uuidSchema,
  toId: uuidSchema,
  predicate: z.string().trim().min(1).max(100),
  attributes: jsonObjectSchema.optional().default({}),
  ...validityShape,
}).strict().superRefine((value, ctx) => {
  if (value.fromId === value.toId) {
    ctx.addIssue({ code: "custom", path: ["toId"], message: "Self-relations are not allowed" });
  }
  validateValidity(value, ctx);
});

export const updateRelationInputSchema = z.object({
  id: uuidSchema,
  expectedVersion: z.number().int().min(1),
  attributes: jsonObjectSchema.optional(),
  ...validityShape,
}).strict().superRefine(validateValidity);

export const relationIdInputSchema = z.object({ id: uuidSchema }).strict();
export const listRelationsInputSchema = z.object({ entityId: uuidSchema }).strict();

export type RelationDTO = z.infer<typeof relationSchema>;
export type CreateRelationInput = z.input<typeof createRelationInputSchema>;
export type UpdateRelationInput = z.infer<typeof updateRelationInputSchema>;
