import { z } from "zod";
import { isoDateTimeSchema, uuidSchema, workspaceRoleSchema } from "./domain";

export const workspaceSchema = z.object({
  id: uuidSchema,
  name: z.string().trim().min(1).max(120),
  slug: z.string().trim().min(2).max(80).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/),
  staleProcessDays: z.number().int().positive(),
  createdAt: isoDateTimeSchema,
  updatedAt: isoDateTimeSchema,
}).strict();

export const workspaceCreateInputSchema = z.object({ name: z.string().trim().min(1).max(120), slug: z.string().trim().min(2).max(80).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/) }).strict();
export const workspaceUpdateInputSchema = z.object({
  name: z.string().trim().min(1).max(120).optional(),
  slug: z.string().trim().min(2).max(80).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/).optional(),
  staleProcessDays: z.number().int().positive().max(3650).optional(),
}).strict();
export const workspaceIdInputSchema = z.object({ workspaceId: uuidSchema }).strict();
export const memberInviteInputSchema = z.object({ email: z.email().max(254), role: z.enum(["admin", "editor", "viewer"]) }).strict();
export const memberRoleInputSchema = z.object({ userId: uuidSchema, role: z.enum(["admin", "editor", "viewer"]) }).strict();
export const memberUserInputSchema = z.object({ userId: uuidSchema }).strict();
export const transferOwnershipInputSchema = z.object({ newOwnerUserId: uuidSchema }).strict();
export const acceptInvitationInputSchema = z.object({ token: z.string().min(32).max(512) }).strict();
export type WorkspaceDTO = z.infer<typeof workspaceSchema>;
export type WorkspaceRoleDTO = z.infer<typeof workspaceRoleSchema>;
