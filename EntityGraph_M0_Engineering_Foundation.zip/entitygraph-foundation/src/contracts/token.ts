import { z } from "zod";
import { isoDateTimeSchema, tokenScopeSchema, uuidSchema } from "./domain";

export const apiTokenSummarySchema = z.object({
  id: uuidSchema,
  workspaceId: uuidSchema,
  userId: uuidSchema,
  label: z.string(),
  prefix: z.string(),
  scopes: z.array(tokenScopeSchema).min(1),
  createdBy: uuidSchema,
  createdAt: isoDateTimeSchema,
  lastUsedAt: isoDateTimeSchema.nullable(),
  expiresAt: isoDateTimeSchema.nullable(),
  revokedAt: isoDateTimeSchema.nullable(),
}).strict();

export const tokenIssueInputSchema = z.object({
  userId: uuidSchema,
  label: z.string().trim().min(1).max(100),
  scopes: z.array(tokenScopeSchema).min(1),
  expiresAt: isoDateTimeSchema.nullable().optional(),
}).strict().superRefine((v, ctx) => {
  if (!v.scopes.includes("read")) ctx.addIssue({ code: "custom", path: ["scopes"], message: "Every token must include read scope" });
  if (new Set(v.scopes).size !== v.scopes.length) ctx.addIssue({ code: "custom", path: ["scopes"], message: "Scopes must be unique" });
});
export const tokenListInputSchema = z.object({ userId: uuidSchema.optional() }).strict();
export const tokenRevokeInputSchema = z.object({ tokenId: uuidSchema }).strict();
export type ApiTokenSummaryDTO = z.infer<typeof apiTokenSummarySchema>;
export type TokenIssueInput = z.infer<typeof tokenIssueInputSchema>;
