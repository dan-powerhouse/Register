import { z } from "zod";
import { actorTypeSchema, isoDateTimeSchema, jsonObjectSchema, requestSourceSchema, uuidSchema } from "./domain";

export const auditEntrySchema = z.object({
  id: uuidSchema,
  workspaceId: uuidSchema,
  at: isoDateTimeSchema,
  actorType: actorTypeSchema,
  actorId: uuidSchema.nullable(),
  effectiveUserId: uuidSchema.nullable(),
  source: requestSourceSchema,
  requestId: z.string().min(1).max(128),
  action: z.string().min(1).max(160),
  targetType: z.string().max(80).nullable(),
  targetId: uuidSchema.nullable(),
  outcome: z.enum(["success", "failure"]),
  before: z.unknown().nullable(),
  after: z.unknown().nullable(),
  metadata: jsonObjectSchema,
}).strict();

export const auditQuerySchema = z.object({
  targetType: z.string().trim().min(1).max(80).optional(),
  targetId: uuidSchema.optional(),
  actorUserId: uuidSchema.optional(),
  source: requestSourceSchema.optional(),
  actionPrefix: z.string().trim().min(1).max(160).optional(),
  limit: z.number().int().min(1).max(100).optional().default(25),
  cursor: z.string().max(2048).optional(),
}).strict();

export const entityAuditQuerySchema = auditQuerySchema.omit({ targetId: true, targetType: true, actorUserId: true });
export const auditEntityInputSchema = z.object({ id: uuidSchema, ...entityAuditQuerySchema.shape }).strict();

export type AuditEntryDTO = z.infer<typeof auditEntrySchema>;
export type AuditQuery = z.infer<typeof auditQuerySchema>;
