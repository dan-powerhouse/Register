import { z } from "zod";
import {
  entityKindSchema,
  entityStatusSchema,
  isoDateTimeSchema,
  jsonObjectSchema,
  uuidSchema,
} from "./domain";

const normalizedTag = z.string().trim().min(1).max(64).transform((v) => v.toLocaleLowerCase("en-US"));
const tagsSchema = z.array(normalizedTag).max(100).transform((v) => [...new Set(v)].sort());

export const entitySchema = z.object({
  id: uuidSchema,
  workspaceId: uuidSchema,
  kind: entityKindSchema,
  type: z.string().trim().min(1).max(100),
  title: z.string().trim().min(1).max(300),
  status: entityStatusSchema,
  attributes: jsonObjectSchema,
  notes: z.string().nullable(),
  tags: z.array(z.string()),
  createdBy: uuidSchema,
  updatedBy: uuidSchema,
  createdAt: isoDateTimeSchema,
  updatedAt: isoDateTimeSchema,
  version: z.number().int().min(1),
});

export const createEntityInputSchema = z.object({
  kind: entityKindSchema,
  type: z.string().trim().min(1).max(100),
  title: z.string().trim().min(1).max(300),
  status: z.enum(["active", "inactive"]).optional().default("active"),
  attributes: jsonObjectSchema.optional().default({}),
  notes: z.string().nullable().optional().default(null),
  tags: tagsSchema.optional().default([]),
}).strict();

export const updateEntityInputSchema = z.object({
  id: uuidSchema,
  expectedVersion: z.number().int().min(1),
  type: z.string().trim().min(1).max(100).optional(),
  title: z.string().trim().min(1).max(300).optional(),
  status: z.enum(["active", "inactive"]).optional(),
  attributes: jsonObjectSchema.optional(),
  notes: z.string().nullable().optional(),
  tags: tagsSchema.optional(),
}).strict();

export const archiveEntityInputSchema = z.object({ id: uuidSchema, expectedVersion: z.number().int().min(1) }).strict();
export const entityIdInputSchema = z.object({ id: uuidSchema }).strict();
export const bulkTagInputSchema = z.object({
  items: z.array(z.object({ id: uuidSchema, expectedVersion: z.number().int().min(1) }).strict()).min(1).max(100),
  mode: z.enum(["add", "remove", "replace"]),
  tags: tagsSchema,
}).strict();
export const bulkArchiveInputSchema = z.object({
  items: z.array(z.object({ id: uuidSchema, expectedVersion: z.number().int().min(1) }).strict()).min(1).max(100),
}).strict();

export type EntityDTO = z.infer<typeof entitySchema>;
export type CreateEntityInput = z.input<typeof createEntityInputSchema>;
export type UpdateEntityInput = z.infer<typeof updateEntityInputSchema>;
export type BulkTagInput = z.input<typeof bulkTagInputSchema>;
export type BulkArchiveInput = z.infer<typeof bulkArchiveInputSchema>;
