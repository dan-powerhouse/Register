# EntityGraph implementation foundation

This repository is the first code foundation for EntityGraph, derived from the included `docs/ENTITYGRAPH_CONTRACTS_v0.2.md` and `docs/EntityGraph_Web_App_Plan.md`.

It is a **starter implementation, not a finished or production-ready application**. It establishes shared TypeScript/Zod contracts, a Drizzle PostgreSQL model, the first canonical SQL migration, service ports, trusted-principal authorization helpers, tRPC procedures, MCP tools/resources and route wiring. Concrete repositories/services, the product UI workflows, email delivery and the import/export ZIP implementation remain outstanding. A minimal root page is included only as a developer placeholder.

## Architecture

```text
Next.js UI -> tRPC adapter ----┐
                               +-> Core service ports -> PostgreSQL 16
MCP HTTP -> MCP adapter -------┘
```

Adapters authenticate and validate transport input. Core services/repositories own workspace authorization, business validation, transactions, optimistic concurrency and successful mutation audit writes. UI, tRPC, MCP and import adapters must not write domain tables directly.

## Requirements

- Node.js 22+
- PostgreSQL 16+
- A configured email delivery provider
- Dependency versions resolved and committed in a lockfile before deployment

## Setup

1. Start local PostgreSQL 16 with `docker compose up -d db`.
2. Copy `.env.example` to `.env.local` and set `DATABASE_URL`, `BETTER_AUTH_SECRET`, `BETTER_AUTH_URL`, OAuth credentials (when enabled), `APP_ALLOWED_ORIGINS`, and MCP Host/Origin allowlists. The example DB credentials match `compose.yaml` and are for local development only.
3. Install dependencies and commit the package-manager lockfile.
4. Generate the Better Auth schema with the configured magic-link/Google plugin set: `npm run db:auth:generate`. Review the generated schema; preserve the `user` table name and UUID `user.id`, and keep named exports for `user`, `session`, `account`, and `verification` consumed by `src/db/client.ts`.
5. Generate and apply the Better Auth Drizzle migration: `npm run db:auth:migration:generate`, review the SQL, then `npm run db:auth:migrate`.
6. Apply the EntityGraph migration: `npm run db:migrate`. This applies `src/db/migrations/0001_entitygraph.sql` once and records it in `entitygraph_migration_log`.
7. Implement the service ports in `src/services/ports.ts` with transaction-aware Drizzle repositories. Do not write domain tables from UI, tRPC, MCP, or jobs directly.
8. Implement the DB-backed `PrincipalResolver`, `McpTokenAuthenticator`, `SharedRateLimiter`, security-event writer, and app composition root; call `configureEntityGraphRuntime()` from a server-only bootstrap module.
9. Run `npm run typecheck` and `npm test`; add PostgreSQL 16 integration tests and MCP conformance tests before deployment.

The `db:auth:*` commands follow Better Auth's current Drizzle workflow: generate its schema with the Better Auth CLI, then use Drizzle Kit to generate and apply migrations. EntityGraph's application migration is a reviewed SQL migration applied separately. See the official [Better Auth CLI documentation](https://better-auth.com/docs/concepts/cli) and [Drizzle adapter documentation](https://better-auth.com/docs/adapters/drizzle).

## Routes provided

- `/` — minimal developer placeholder page (not the product UI).
- `GET/POST /api/auth/[...all]` — Better Auth handlers.
- `GET/POST /api/trpc/[trpc]` — tRPC API.
- `GET/POST /api/mcp` — stateless MCP HTTP endpoint.
- `POST /api/imports/upload` — authenticated bounded multipart package upload.
- `GET /api/exports/{exportId}` — authenticated workspace-bound export download.

The web request selects its workspace with `x-entitygraph-workspace: <slug>`. The MCP token already identifies exactly one workspace; tool inputs cannot override it.

## Important implementation details

- `src/db/migrations/0001_entitygraph.sql` is the canonical initial EntityGraph migration. It expects Better Auth's `"user"` table to exist first.
- `src/db/schema.ts` mirrors the application tables for Drizzle queries and future migration generation. Review generated diffs against the canonical SQL; the SQL also installs triggers and kind-filtered views.
- Do not use `drizzle-kit push` against production. Use reviewed migrations only.
- Cookie-authenticated tRPC POST requests require an exact allow-listed `Origin` (`APP_ALLOWED_ORIGINS`) as the v1 CSRF boundary.
- The MCP adapter uses the official v2 `createMcpHandler` in `legacy: "reject"` mode. The SDK `ServerOptions.cacheHints` configures `tools/list` with `ttlMs: 30000` and `cacheScope: "private"`; the SDK stamps required defaults on other cacheable operations. Authentication and rate limiting happen for each HTTP request; the principal is request-scoped.
- MCP read/protocol auditing is handled by MCP method middleware; the SDK-owned `subscriptions/listen` request is audited at the HTTP edge because the SDK handles it before method middleware. Successful mutation audit rows must be written by the service in the same transaction. The adapter does not add a second success audit row for a mutation.
- The type-template and predicate registries start empty. Seed only after domain vocabulary and attribute rules are approved.
- Import/export routes only handle bounded transport and delegate to service ports. ZIP parsing, validation, storage, atomic commit, streaming storage and cleanup remain unimplemented.

## Source and implementation map

- `docs/ENTITYGRAPH_CONTRACTS_v0.2.md` — behavioral source of truth.
- `docs/EntityGraph_Web_App_Plan.md` — original product/architecture plan.
- `docs/ENTITYGRAPH_CONTRACT_REVIEW.md` — contract gap review.
- `docs/IMPLEMENTATION_TRACEABILITY.md` — maps contract sections to scaffold files and remaining work.
- `src/contracts/` — Zod v4 schemas and inferred TypeScript DTOs.
- `src/db/` — Better Auth schema contract, Drizzle schema, PostgreSQL migration. `compose.yaml` provides local PostgreSQL 16 for development.
- `src/core/` — service errors and authorization helpers.
- `src/services/ports.ts` — service interfaces used by adapters.
- `src/trpc/` — request context and typed router factory.
- `src/mcp/` — strict-modern MCP server factory, tools/resources, route wrapper.
- `src/app/` — root placeholder page, layout, base styling and Next.js route-handler integration points.
- `DECISIONS_AND_GAPS.md` — unresolved implementation and deployment work.

## Quality gates before production

Do not call the system production-ready until all of the following are true:

- Service implementations satisfy the transaction, authorization and audit contracts.
- Workspace isolation, owner invariants, optimistic locking, predicate/template impact checks and bulk atomicity have PostgreSQL integration tests.
- MCP Inspector and a real modern 2026-07-28 client test discovery, all nine tools, all three resources, one-event audit semantics, limits and revoked-token behavior.
- Invitation and magic-link emails are delivered by a configured provider.
- CSV package parsing/export, preview/commit, single-use and expiry rules, cleanup job, and file-size/row caps are implemented.
- Product UI screens, keyboard search, list filters, detail history, path panels and admin workflows are implemented.
- Backup restore drill, retention/privacy policy, deployment configuration, health checks and observability are reviewed.

## Validation status

Dependency installation was attempted in the creation environment but timed out. Therefore the scaffold has **not** been successfully typechecked, built or run against PostgreSQL/MCP Inspector here. Run `npm install`, commit the generated lockfile, then run `npm run typecheck` and `npm test` before treating it as a buildable baseline.

## Engineering quality gates (M0)

M0 adds the required development controls. Read `docs/ENGINEERING_GATES.md` and `CONTRIBUTING.md` before contributing.

- `npm run check` runs formatting, ESLint, architecture-boundary checks, TypeScript, and unit tests with the 100% authorization-helper coverage gate.
- `npm run test:integration` runs real PostgreSQL 16 migration and constraint tests. Start the disposable test database with `docker compose -f compose.test.yaml up -d --wait` and set `TEST_DATABASE_URL` to the `entitygraph_test` database on port `5433`.
- `npm run check:all` runs the full local quality suite, PostgreSQL integration tests, and production build.
- GitHub Actions run quality and PostgreSQL integration checks on every PR to `main`; separate workflows perform dependency review, Gitleaks secret scanning, and CodeQL analysis.
- `CONTRIBUTING.md`, `.github/pull_request_template.md`, issue templates, and `SECURITY.md` define the review and reporting process.

**Bootstrap limitation:** the artifact environment could not reach the npm registry, so a valid `package-lock.json` could not be generated here. Run `npm install`, inspect and commit the generated lockfile, then CI will use `npm ci`. The workflows intentionally fail with a clear message while the lockfile is absent. The artifact environment also has no Docker/PostgreSQL daemon, so integration tests were authored but not executed here.
