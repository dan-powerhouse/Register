# EntityGraph foundation — decisions and remaining work

## Decisions made to make the scaffold concrete

1. **Auth IDs:** Better Auth is configured for UUID IDs. Its `user` table is the identity source for workspace membership and actor references. This resolves the potential text-vs-UUID mismatch at the contract boundary.
2. **Auth table lifecycle:** Better Auth owns user/session/account/verification tables. Generate and migrate those first; EntityGraph app migrations reference `"user"(id)`.
3. **MCP mode:** Modern-only, `legacy: "reject"`, protocol revision 2026-07-28. No legacy 2025 fallback.
4. **Empty registries:** no implicit predicate or type-template seed data.
5. **Search vector:** PostgreSQL stored generated `tsvector` over title, notes, and string values in JSONB attributes, with `simple` config.
6. **Transaction boundary:** successful mutations and their audit rows must use the same Drizzle transaction. An MCP adapter must not add a second success audit row for a mutation.

## Work still required before implementation is complete

### Core behavior
- Implement every service in `src/services/ports.ts` with Drizzle repositories and transaction-scoped audit insertion.
- Add keyset/cursor encoding and verification bound to workspace + normalized query.
- Implement dynamic template-value validation including entity-reference checks and defaults.
- Implement predicate-kind compatibility, relation duplicate prevention, template/predicate impact checks, optimistic locking, and all-or-nothing bulk updates.
- Implement the workspace bootstrap, invitation delivery/acceptance, one-owner invariant, ownership transfer, and token issuance/revocation lifecycle.
- Add DB-specific constraint handling that maps unique/FK/check violations to stable `ServiceError` codes.

### MCP
- Confirm the configured SDK v2 `ServerOptions.cacheHints` against the generated lockfile and add a conformance test for `tools/list` (`ttlMs: 30000`, `cacheScope: private`).
- Add integration tests proving one audit event per authenticated RPC (including SDK-owned `subscriptions/listen`); mutation service audit must be the sole success event for write tools.
- Implement shared PostgreSQL token rate limiting and test request-body/Host/Origin protections end-to-end in the deployed route. The tRPC POST Origin gate is present; production allowlist configuration is still required.
- Run MCP Inspector and a real client pinned to `2026-07-28`.

### Product/UI
- Implement Next.js screens, forms, global search, table/filter state, relation editor, history view, dashboard, paths panel, admin, token one-time reveal, and destructive-action confirmation.
- Add `saved_view`, CSV ZIP import/export, dry-run preview, atomic commit, cleanup job, and authenticated download/upload routes (M4).
- Select and configure email provider for magic-link and invitation delivery.

### Operations and policy
- Define audit retention, privacy-erasure behavior, and archived-record retention before production.
- Configure secrets, TLS, production database roles, backup and restore drill, health checks, monitoring, and deployment runbook.

## Notes

- This scaffold contains interfaces and adapters, not the implementation of all core services. Adapter methods intentionally call service ports and should fail fast when the composition root does not provide concrete services.
- There is no automatic `createdBy` or role derivation from caller-supplied data. The authenticated `Principal` is the only trusted identity input.

## Additional scaffold limitations (not yet implemented)

- The Next.js API routes and adapter factories are present, but `configureEntityGraphRuntime()` has no production composition root until repository/service implementations are supplied.
- `PrincipalResolver`, token verification, last-used throttling, workspace membership revalidation, and the shared PostgreSQL rolling-window rate limiter are ports only.
- The generated Better Auth schema is a starter model; regenerate and validate it after finalizing the installed Better Auth version and plugin configuration.
- The SQL migration and Drizzle model must be kept in parity. SQL-only trigger/view behavior is intentionally retained in the canonical migration.
- No contract-defined product UI workflows, import ZIP parser, export ZIP builder, object storage, expiry cleanup job, concrete email provider, or production deployment configuration is included. A minimal `/` developer placeholder is included only to make the Next.js app shell concrete.
- Dependency installation timed out in the artifact creation environment, so typecheck/build/tests have not been run. Do not treat this scaffold as verified until a lockfile is generated and all gates in the README pass.
