## Summary

<!-- What changed and why? Link the issue or implementation contract. -->

## Contract and architecture impact

- [ ] I identified the relevant contract section(s).
- [ ] This change preserves existing API, service, database, and MCP contracts, or includes an explicit versioned change.
- [ ] No UI/tRPC/MCP adapter accesses PostgreSQL or repositories directly.
- [ ] All domain writes remain inside the shared service/transaction boundary.
- [ ] Workspace scope and trusted Principal authorization are enforced server-side.

## Verification

- [ ] `npm run format:check`
- [ ] `npm run lint`
- [ ] `npm run architecture:check`
- [ ] `npm run typecheck`
- [ ] `npm run test:coverage`
- [ ] `npm run test:integration` (when database behavior/migrations change)
- [ ] `npm run build`
- [ ] `npm run security:audit`

## Data and security review

- [ ] Database changes include a reviewed migration and rollback/forward-recovery notes.
- [ ] Authorization, workspace isolation, token scopes, and audit behavior were reviewed where relevant.
- [ ] No secrets, credentials, personal data, or production data are committed.
- [ ] Error responses do not expose SQL, stack traces, tokens, or internal configuration.

## Risks and rollout

<!-- Include migration/rollout notes, operational impact, and known limitations. -->

## Evidence

<!-- Add test output, screenshots, MCP Inspector evidence, or query plans as applicable. -->
