---
name: Contract or architecture change
about: Propose a change to an EntityGraph contract or architecture
labels: architecture
---

## Problem to solve

## Affected contract sections

## Proposed behavior

## Compatibility impact

- [ ] Backward compatible
- [ ] Requires migration
- [ ] Requires API/MCP versioning
- [ ] Requires data backfill

## Security and workspace-isolation impact

## Acceptance criteria
