---
name: Bug report
about: Report a reproducible defect
labels: bug
---

## Expected behavior

## Actual behavior

## Reproduction steps

## Environment

- Node.js version:
- PostgreSQL version:
- Browser/client:
- Commit or release:

## Relevant contract

<!-- Link the affected contract section if known. Do not include secrets or production data. -->

## Logs or evidence

<!-- Redact tokens, emails, identifiers, and sensitive data. -->
