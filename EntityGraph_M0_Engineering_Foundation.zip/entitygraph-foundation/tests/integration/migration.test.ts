import { readFile } from "node:fs/promises";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { Client } from "pg";
import { loadEnvConfig } from "@next/env";

loadEnvConfig(process.cwd());

const databaseUrl = process.env.TEST_DATABASE_URL;
if (!databaseUrl) {
  throw new Error(
    "TEST_DATABASE_URL is required. Start compose.test.yaml and set the test database URL.",
  );
}

const parsedDatabaseUrl = new URL(databaseUrl);
const databaseName = decodeURIComponent(parsedDatabaseUrl.pathname.replace(/^\//, ""));
if (!databaseName.endsWith("_test")) {
  throw new Error(
    `Refusing to run destructive integration tests against database '${databaseName}'. The database name must end with _test.`,
  );
}

const client = new Client({ connectionString: databaseUrl });
const schemaName = `eg_test_${randomUUID().replaceAll("-", "")}`;
let clientConnected = false;

async function createFixture() {
  const userA = randomUUID();
  const userB = randomUUID();
  const workspaceA = randomUUID();
  const workspaceB = randomUUID();
  const personId = randomUUID();
  const objectId = randomUUID();
  const secondObjectId = randomUUID();
  const foreignObjectId = randomUUID();

  await client.query('INSERT INTO "user" (id) VALUES ($1), ($2)', [userA, userB]);
  await client.query(
    "INSERT INTO workspace (id, name, slug) VALUES ($1, 'Workspace A', $2), ($3, 'Workspace B', $4)",
    [workspaceA, `workspace-a-${workspaceA.slice(0, 8)}`, workspaceB, `workspace-b-${workspaceB.slice(0, 8)}`],
  );
  await client.query(
    `INSERT INTO workspace_member (workspace_id, user_id, role)
     VALUES ($1, $2, 'owner'), ($1, $3, 'editor'), ($4, $3, 'owner')`,
    [workspaceA, userA, userB, workspaceB],
  );
  await client.query(
    `INSERT INTO type_templates (workspace_id, kind, type, fields, updated_by)
     VALUES ($1, 'person', 'person', '[]'::jsonb, $2),
            ($1, 'object', 'asset', '[]'::jsonb, $2),
            ($3, 'object', 'asset', '[]'::jsonb, $4)`,
    [workspaceA, userA, workspaceB, userB],
  );
  await client.query(
    `INSERT INTO predicate_registry (workspace_id, name, from_kinds, to_kinds, description, created_by, updated_by)
     VALUES ($1, 'owns', ARRAY['person'], ARRAY['object'], 'Ownership', $2, $2)`,
    [workspaceA, userA],
  );
  await client.query(
    `INSERT INTO entity (id, workspace_id, kind, type, title, attributes, notes, created_by, updated_by)
     VALUES ($1, $2, 'person', 'person', 'Ada', '{}'::jsonb, NULL, $3, $3),
            ($4, $2, 'object', 'asset', 'Laptop', '{"manufacturer":"Acme"}'::jsonb, 'Laser optics', $3, $3),
            ($5, $2, 'object', 'asset', 'Monitor', '{}'::jsonb, NULL, $3, $3),
            ($6, $7, 'object', 'asset', 'Foreign laptop', '{}'::jsonb, NULL, $8, $8)`,
    [personId, workspaceA, userA, objectId, secondObjectId, foreignObjectId, workspaceB, userB],
  );

  return { userA, userB, workspaceA, workspaceB, personId, objectId, secondObjectId, foreignObjectId };
}

beforeAll(async () => {
  await client.connect();
  clientConnected = true;
  await client.query(`CREATE SCHEMA "${schemaName}"`);
  await client.query(`SET search_path TO "${schemaName}"`);
  await client.query('CREATE TABLE "user" (id uuid PRIMARY KEY)');
  const migrationPath = path.resolve("src/db/migrations/0001_entitygraph.sql");
  const migrationSql = await readFile(migrationPath, "utf8");
  await client.query(migrationSql);
}, 30_000);

afterAll(async () => {
  if (!clientConnected) return;
  try {
    await client.query("ROLLBACK").catch(() => undefined);
    await client.query("RESET search_path");
    await client.query(`DROP SCHEMA IF EXISTS "${schemaName}" CASCADE`);
  } finally {
    await client.end();
  }
}, 30_000);

describe.sequential("PostgreSQL 16 migration and integrity contracts", () => {
  it("rejects cross-workspace relations through composite foreign keys", async () => {
    const fixture = await createFixture();
    await expect(
      client.query(
        `INSERT INTO relation (workspace_id, from_id, to_id, predicate, created_by, updated_by)
         VALUES ($1, $2, $3, 'owns', $4, $4)`,
        [fixture.workspaceA, fixture.personId, fixture.foreignObjectId, fixture.userA],
      ),
    ).rejects.toMatchObject({ code: "23503" });
  });

  it("rejects entity kind changes in the database", async () => {
    const fixture = await createFixture();
    await expect(
      client.query("UPDATE entity SET kind = 'object' WHERE id = $1", [fixture.personId]),
    ).rejects.toThrow("entity.kind is immutable");
  });

  it("makes audit rows append-only", async () => {
    const fixture = await createFixture();
    const auditId = randomUUID();
    await client.query(
      `INSERT INTO audit_log (
         id, workspace_id, actor_type, actor_id, effective_user_id, source,
         request_id, action, outcome
       ) VALUES ($1, $2, 'user', $3, $3, 'trpc', 'integration-test', 'entity.created', 'success')`,
      [auditId, fixture.workspaceA, fixture.userA],
    );
    await expect(client.query("UPDATE audit_log SET action = 'tampered' WHERE id = $1", [auditId])).rejects.toThrow(
      "audit_log is append-only",
    );
    await expect(client.query("DELETE FROM audit_log WHERE id = $1", [auditId])).rejects.toThrow(
      "audit_log is append-only",
    );
  });

  it("enforces exactly one owner per workspace", async () => {
    const fixture = await createFixture();
    await expect(
      client.query(
        "INSERT INTO workspace_member (workspace_id, user_id, role) VALUES ($1, $2, 'owner')",
        [fixture.workspaceA, fixture.userB],
      ),
    ).rejects.toMatchObject({ code: "23505" });
  });

  it("requires an entity to reference a registered template", async () => {
    const fixture = await createFixture();
    await expect(
      client.query(
        `INSERT INTO entity (workspace_id, kind, type, title, created_by, updated_by)
         VALUES ($1, 'object', 'unregistered-type', 'Unknown', $2, $2)`,
        [fixture.workspaceA, fixture.userA],
      ),
    ).rejects.toMatchObject({ code: "23503" });
  });

  it("builds a generated full-text vector from title, notes, and JSON string attributes", async () => {
    const fixture = await createFixture();
    const result = await client.query(
      `SELECT search_vector @@ plainto_tsquery('simple', 'Acme optics') AS matches
       FROM entity WHERE id = $1`,
      [fixture.objectId],
    );
    expect(result.rows[0]?.matches).toBe(true);
  });

  it("rejects duplicate relation triples and invalid validity ranges", async () => {
    const fixture = await createFixture();
    const relationValues = [fixture.workspaceA, fixture.personId, fixture.objectId, fixture.userA];
    await client.query(
      `INSERT INTO relation (workspace_id, from_id, to_id, predicate, created_by, updated_by)
       VALUES ($1, $2, $3, 'owns', $4, $4)`,
      relationValues,
    );
    await expect(
      client.query(
        `INSERT INTO relation (workspace_id, from_id, to_id, predicate, created_by, updated_by)
         VALUES ($1, $2, $3, 'owns', $4, $4)`,
        relationValues,
      ),
    ).rejects.toMatchObject({ code: "23505" });
    await expect(
      client.query(
        `INSERT INTO relation (workspace_id, from_id, to_id, predicate, valid_from, valid_to, created_by, updated_by)
         VALUES ($1, $2, $3, 'owns', '2026-02-02T00:00:00Z', '2026-02-01T00:00:00Z', $4, $4)`,
        [fixture.workspaceA, fixture.personId, fixture.secondObjectId, fixture.userA],
      ),
    ).rejects.toMatchObject({ code: "23514" });
    await expect(
      client.query(
        `INSERT INTO relation (workspace_id, from_id, to_id, predicate, created_by, updated_by)
         VALUES ($1, $2, $2, 'owns', $4, $4)`,
        relationValues,
      ),
    ).rejects.toMatchObject({ code: "23514" });
  });
});
