import { describe, expect, it } from "vitest";
import {
  requireAdmin,
  requireMinimumRole,
  requireOwner,
  requirePrincipal,
  requireRead,
  requireWrite,
} from "../src/core/authorization";
import { ServiceError } from "../src/core/errors";
import type { Principal } from "../src/auth/principal";

const workspaceId = "b7e9b1e1-0d7a-4f7a-9e8f-2c0f3b6f54d1";
const actorId = "c2e9b1e1-0d7a-4f7a-9e8f-2c0f3b6f54d2";
const userId = "a3e9b1e1-0d7a-4f7a-9e8f-2c0f3b6f54d3";

const principal = (
  role: Principal["role"],
  scopes?: Principal["tokenScopes"],
): Principal => ({
  workspaceId,
  actorType: scopes ? "token" : "user",
  actorId,
  userId,
  role,
  tokenScopes: scopes,
  requestId: "test-request",
  source: scopes ? "mcp" : "trpc",
});

describe("workspace authorization", () => {
  it("requires a trusted principal", () => {
    expect(() => requirePrincipal(principal("viewer"))).not.toThrow();
    expect(() => requirePrincipal(null)).toThrowError(ServiceError);
    expect(() => requirePrincipal(undefined)).toThrowError(ServiceError);
  });

  it("enforces the complete workspace role ordering", () => {
    const roles: Principal["role"][] = ["viewer", "editor", "admin", "owner"];
    for (const [minimumIndex, minimum] of roles.entries()) {
      for (const [roleIndex, role] of roles.entries()) {
        if (roleIndex >= minimumIndex) {
          expect(() => requireMinimumRole(principal(role), minimum)).not.toThrow();
        } else {
          expect(() => requireMinimumRole(principal(role), minimum)).toThrow(ServiceError);
        }
      }
    }
  });

  it("requires read scope for tokens but not for human sessions", () => {
    expect(() => requireRead(principal("viewer"))).not.toThrow();
    expect(() => requireRead(principal("viewer", ["read"]))).not.toThrow();
    expect(() => requireRead(principal("admin", ["write"]))).toThrow(ServiceError);
    expect(() => requireRead(principal("admin", []))).toThrow(ServiceError);
  });

  it("requires editor role and write scope for token writes", () => {
    expect(() => requireWrite(principal("editor"))).not.toThrow();
    expect(() => requireWrite(principal("owner"))).not.toThrow();
    expect(() => requireWrite(principal("viewer"))).toThrow(ServiceError);
    expect(() => requireWrite(principal("editor", ["read", "write"]))).not.toThrow();
    expect(() => requireWrite(principal("editor", ["read"]))).toThrow(ServiceError);
    expect(() => requireWrite(principal("viewer", ["read", "write"]))).toThrow(ServiceError);
  });

  it("requires admin role and write scope for token administration", () => {
    expect(() => requireAdmin(principal("admin"))).not.toThrow();
    expect(() => requireAdmin(principal("owner"))).not.toThrow();
    expect(() => requireAdmin(principal("editor"))).toThrow(ServiceError);
    expect(() => requireAdmin(principal("admin", ["read", "write"]))).not.toThrow();
    expect(() => requireAdmin(principal("admin", ["read"]))).toThrow(ServiceError);
  });

  it("requires owner role and write scope for ownership operations", () => {
    expect(() => requireOwner(principal("owner"))).not.toThrow();
    expect(() => requireOwner(principal("admin"))).toThrow(ServiceError);
    expect(() => requireOwner(principal("owner", ["read", "write"]))).not.toThrow();
    expect(() => requireOwner(principal("owner", ["read"]))).toThrow(ServiceError);
  });
});
