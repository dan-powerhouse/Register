import { describe, expect, it } from "vitest";
import { createEntityInputSchema } from "../src/contracts/entity";
import { createRelationInputSchema } from "../src/contracts/relation";
import { dateOnlySchema } from "../src/contracts/domain";
import { upsertTemplateInputSchema } from "../src/contracts/template";
import { updateEntityInputSchema } from "../src/contracts/entity";
import { tokenIssueInputSchema } from "../src/contracts/token";
import { pathPatternInputSchema } from "../src/contracts/traversal";

const id = "b7e9b1e1-0d7a-4f7a-9e8f-2c0f3b6f54d1";

describe("EntityGraph shared contracts", () => {
  it("normalizes tags to lowercase, unique, deterministic values", () => {
    const value = createEntityInputSchema.parse({ kind: "object", type: "laptop", title: " Laptop ", tags: ["Work", "work", "Personal"] });
    expect(value.title).toBe("Laptop");
    expect(value.tags).toEqual(["personal", "work"]);
  });

  it("rejects self-relations before service execution", () => {
    const result = createRelationInputSchema.safeParse({ fromId: id, toId: id, predicate: "owns" });
    expect(result.success).toBe(false);
  });

  it("rejects invalid calendar dates", () => {
    expect(dateOnlySchema.safeParse("2026-02-30").success).toBe(false);
    expect(dateOnlySchema.safeParse("2024-02-29").success).toBe(true);
  });

  it("rejects duplicate template field names", () => {
    const result = upsertTemplateInputSchema.safeParse({
      kind: "object",
      type: "laptop",
      fields: [
        { name: "serial_number", dataType: "text" },
        { name: "serial_number", dataType: "text" },
      ],
    });
    expect(result.success).toBe(false);
  });

  it("does not allow clients to change entity kind or set archived through PATCH", () => {
    expect(updateEntityInputSchema.safeParse({ id, expectedVersion: 1, kind: "person" }).success).toBe(false);
    expect(updateEntityInputSchema.safeParse({ id, expectedVersion: 1, status: "archived" }).success).toBe(false);
  });

  it("requires read scope on every API token", () => {
    expect(tokenIssueInputSchema.safeParse({ userId: id, label: "writer", scopes: ["write"] }).success).toBe(false);
    expect(tokenIssueInputSchema.safeParse({ userId: id, label: "reader", scopes: ["read"] }).success).toBe(true);
  });

  it("limits ordered path reports to two steps", () => {
    const step = { predicate: "owns", direction: "outgoing" as const };
    expect(pathPatternInputSchema.safeParse({ startId: id, steps: [step, step] }).success).toBe(true);
    expect(pathPatternInputSchema.safeParse({ startId: id, steps: [step, step, step] }).success).toBe(false);
  });
});
